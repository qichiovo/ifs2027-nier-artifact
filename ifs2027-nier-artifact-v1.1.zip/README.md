# Local Accuracy Is Not a Contract for Abstract Transformers: reproducibility package (v1.1)

Wenrui Liang, Huijie Xu, Zhibo Jin, Zhiyu Zhu, Hongyang Chen, Biaoliang Chen, Jianlong Zhou

Code, trained models, raw results, and the scripts that regenerate the numbers, tables and
figures of the paper (submitted manuscript). Released at
https://github.com/qichiovo/ifs2027-nier-artifact/releases/tag/v1.1, the address in the paper's
data availability statement. Nothing in this archive requires network access.

## Layout

Everything is under `historical_experiment_artifact/`, in the layout the scripts expect:

| Path | Contents |
|---|---|
| `experiments/learned_admission/` | the trained models of both grids (N = 30 in `results/core/`, N = 50 in `confirmation_n50/`), retraining runs with every round, data partitions, oracle tables, checkpoints, per-run records, and the code that produced them |
| `experiments/trained_postfix_envelope_20261006/`, `experiments/envelope_alignment_20261006/` | the audit of all checkpoints, and the envelope and scale-sweep records |
| `experiments/nonmonotone_interval_gate.py`, `nonmonotone_scaling.py`, `metrics.json` | the exhaustive checks of the planted patterns and the scale sweep |
| `experiments/step2_loop_20261011/` | the second loop (Appendix D): its analysis plan, fixed before training (`ANALYSIS_PLAN_ZH.md`, in Chinese; hashes in `plan_lock.json`), code, checkpoints, records, evaluation |
| `experiments/section3_mechanisms_20261014/` | the analysis behind Section 3: scripts, results, detail tables (in Chinese), and the control with shuffled counterexample order |
| `revisions/ifs2027_nier_20261007/` | the manuscript: LaTeX sources, the generated numbers and tables, their generators (`scripts/`), and the figure scripts with their inputs |

`manifest.json` lists every file with its SHA-256 and whether its text metadata was redacted.

## Rebuild the paper's numbers, tables and PDF

From `historical_experiment_artifact/revisions/ifs2027_nier_20261007/` (Python 3.14 with
NumPy, PyTorch CPU and matplotlib; a TeX distribution with pdflatex and bibtex):

```
python -X utf8 -B scripts/generate.py            # numbers.tex, values.json, Tables 3-5 rows, and more
python -X utf8 -B scripts/generate_loop2.py      # second loop: Table 6 and its numbers
python -X utf8 -B scripts/generate_mechanisms.py # numbers of the Section 3 analysis
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
```

The generators write into `generated/`; the files shipped there are their outputs. The
figures are `figures_unified_20261011/figures/figure_1.pdf` and `figure_4.pdf`
(`render_figure1.py`, `render_figures_3_4.py`) and `figures_round3_20261011/figures/figure_2.pdf`
and `figure_3.pdf` (`recolor_figure2.py`, `render_figure3.py`); each script's README in its
folder says what it reads.

## Check the Section 3 analysis

From `historical_experiment_artifact/experiments/section3_mechanisms_20261014/`:

```
python -X utf8 -B reproduce.py        # Tables 2, 3, 6 and the counts of Appendix D from the raw records
python -X utf8 -B mechanisms.py       # path omissions, error directions, retraining (results/)
python -X utf8 -B extras.py
python -X utf8 -B shuffle_control.py  # reruns the 20 retraining runs: first in the original order, which must
                                      # reproduce every recorded final model, then shuffled (about 4 minutes)
```

The per-run records of the shuffled reruns are not included (about 110 MB); `shuffle_control.py`
regenerates them, and `results/shuffle/summary.json` and `runs.csv` hold their outcomes.
`checkpoints.py` compares an earlier archive with the original repository and does not apply to
this copy.

## Notes on the records

Paths are relative to `historical_experiment_artifact/`. The records name the trained models
`A` or `original` and the retrained models `B`, `repair` or `repaired_final`.

- **Paths, steps and calls.** A path, as the paper counts it, consists of the inputs to which
  iteration applies a model, from bottom to the final, stable input, each counted once: the
  entries of `joined.trace` in a job's `result.json`. `joined.steps` and `direct.steps` count
  strict state changes; the audit records add `calls`, which equals `steps + 1` in all 173 of
  them, and the job records name the same quantity `transformer_calls_including_stability`.
- **Accuracy of retrained models.** The records store accuracy on the original test split for
  retrained models too, but 18 of the 20 retraining runs added original test inputs to their
  training data (`original_test_ids_added_to_training`), and the retraining records carry
  `evaluation_scope`: "finite-carrier adaptation and certification; test accuracy is not
  held-out generalization". The paper reports no held-out accuracy for retrained models.
- **Runs and oracle accounting.** Each job folder has an `attempts.json`; all 65 training jobs,
  all 20 retraining jobs and the smoke test completed on their first attempt. Each job's
  `result.json` lists oracle requests by purpose (`oracle.requests`) and the distinct inputs
  requested (`oracle.unique_ids_by_category`, `oracle.unique_counts`); the jobs read a shared
  cache of oracle values, and `oracle.actual_F_evaluations_this_worker` gives the evaluations a
  job performed itself. Timings are stored in `training.seconds`, `check_seconds`,
  `inference_timing` and `wall_seconds`.
- **The audit.** `experiments/trained_postfix_envelope_20261006/results/` holds 173 records, one
  for every `model.pt` under `experiments/learned_admission/`: 65 trained models (`original`;
  45 at N = 30, 20 at N = 50), 20 retrained models (`repaired_final`), 87 retraining rounds
  (`round`), and one smoke test (`smoke`; configuration `w32_c80_s0` at N = 30, with weights
  identical to the grid model `A/w32_c80_s0`, in no cohort). Every record has
  `neural_iteration_with_F_disabled` true, `neural_iteration_F_calls` 0 and
  `reloaded_predictions_match` true.
- **Timings.** Initial optimization takes 61.5 s in total (`training.seconds` over the 65
  training jobs), and the retraining jobs 39.7 s (`wall_seconds`, with their checks and
  controls, over the 20 jobs); envelope construction in the audit takes 0.287 s
  (`envelope.build_wall_seconds`, 85 models). These measure different things and do not form
  an end-to-end speed comparison; `revisions/ifs2027_nier_20261007/generated/costs.json` holds
  the unrounded sums.
- **Envelope formula.** An earlier implementation computed E_old(a) = a ⊔ H_T(a), where the
  paper defines E(a) = H_T(a) ⊔ F(a). For the planted patterns E = F and E_old = a ⊔ F(a), which
  explains why mean widths changed while joined trajectories did not. All envelope results in
  the paper use the paper's formula; `experiments/envelope_alignment_20261006/` keeps the
  records of both, the corrected reruns and the checked tables.
- **Scale sweep.** At each scale point the test script evaluates twelve candidates, and the
  parity of a candidate's seed selects which of the two planted patterns it is. The recorded
  wall time covers all twelve evaluations; `audit.json` of each `scaling_n*_paper` result
  records the twelve seeds and the two distinct candidate tables.

## Limits

- Text metadata (local paths, the interpreter's location, Git fields, repository names) is
  redacted in the copies; `manifest.json` marks every redacted file. Numbers, tables of outputs,
  checkpoints and figures are unchanged.
- `experiments/learned_admission/run.py` differs from the original in one metadata line, so its
  code-hash check refuses to start new training in this copy; the saved records were produced with
  the original files. The second loop's `lock_plan.py` refuses to run twice by design.
- The versions used are in the `environment.json` files: Python 3.14.7, PyTorch 2.14.1+cpu,
  NumPy 2.5.2, one CPU thread.
