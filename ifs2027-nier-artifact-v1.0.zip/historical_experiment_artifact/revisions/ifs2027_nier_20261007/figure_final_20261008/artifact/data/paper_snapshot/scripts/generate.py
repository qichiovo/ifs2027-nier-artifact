"""Generate every experimental number/table/plot from preserved result JSON.

Run from any directory: python -B path/to/scripts/generate.py
No training, checkpoint selection, or mutation of experimental records occurs.
"""
from pathlib import Path
import csv
import hashlib
import json
import statistics as st
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT = Path(__file__).resolve().parents[1]
PAPER = OUT.parents[1]
EXP = PAPER / 'experiments'
AUDIT = EXP / 'trained_postfix_envelope_20261006'
ALIGN = EXP / 'envelope_alignment_20261006/results'
SOURCES = {}
VALUES = {}

def read(p):
    p = Path(p)
    SOURCES[p.relative_to(PAPER).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text(encoding='utf-8'))

def write(p, text):
    p = OUT / p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding='utf-8', newline='\n')

def js(p, d):
    write(p, json.dumps(d, indent=2, ensure_ascii=False) + '\n')

def val(k, x, fmt=None):
    VALUES[k] = {'raw': x, 'latex': format(x, fmt) if fmt else str(x)}

def rows(p, xs):
    write('generated/' + p, '\n'.join(' & '.join(map(str, x)) + r' \\' for x in xs) + '\n')

def frac(a, b):
    return f'{a}/{b}'

def interval(x):
    if x is None:
        return r'\bot'
    if isinstance(x, dict):
        x = [x['lo'], x['hi']]
    return f'[{x[0]},{x[1]}]'

def main():
    all_models = [read(p) for p in sorted((AUDIT / 'results').glob('*/result.json'))]
    assert all(x['status'] == 'complete' for x in all_models)
    original = [x for x in all_models if x['stage'] == 'original']
    repaired = [x for x in all_models if x['stage'] == 'repaired_final']
    final = original + repaired
    index = {(x['N'], x['model_id']): x for x in original}
    matched = [index[x['N'], x['model_id']] for x in repaired]
    cert = lambda xs: sum(x['joined_certificate']['accepted'] for x in xs)
    lawful = lambda xs: sum(not x['raw_rules']['has_rule_violation'] for x in xs)
    val('RawCount', len(original)); val('RepairCount', len(repaired)); val('FinalCount', len(final))
    val('RawAccept', cert(original)); val('RawReject', len(original)-cert(original))
    val('RepairAccept', cert(repaired)); val('RepairReject', len(repaired)-cert(repaired))
    val('MatchedAccept', cert(matched)); val('MatchedLawful', lawful(matched))
    val('MatchedCoveragePass', sum(x['raw_rules']['soundness_violations']==0 for x in matched))
    val('RepairCoveragePass', sum(x['raw_rules']['soundness_violations']==0 for x in repaired))
    val('AcceptedOmissionBad', sum(x['joined_certificate']['accepted'] and x['raw_rules']['soundness_violations']>0 for x in final))
    val('AcceptedMonoOnlyBad', sum(x['joined_certificate']['accepted'] and x['raw_rules']['soundness_violations']==0 and x['raw_rules']['monotonicity_violations']>0 for x in final))
    val('RawLawful', lawful(original)); val('RawLawBad', len(original)-lawful(original))
    val('RepairLawful', lawful(repaired)); val('NewLawful', lawful(repaired)-lawful(matched))
    val('RepairAttempted', sum(x['raw_rules']['has_rule_violation'] for x in matched))
    val('AuditCheckpoints', len(all_models))
    val('AcceptedLawBad', sum(x['joined_certificate']['accepted'] and x['raw_rules']['has_rule_violation'] for x in final))
    val('WiderCount', sum(x['envelope']['strictly_wider_input_count'] > 0 for x in final))
    val('FalseAccept', sum(x['joined_certificate']['accepted'] and not x['joined_certificate']['covers_reachable'] for x in final))
    val('FalseReject', sum(not x['joined_certificate']['accepted'] and x['joined_certificate']['covers_reachable'] for x in final))
    val('FinalWider', sum(x['envelope']['final_wider_than_exact'] for x in final))
    assert all(x['neural_iteration_with_F_disabled'] and x['neural_iteration_F_calls'] == 0 for x in all_models)
    assert all(not x['envelope']['soundness_violations'] and not x['envelope']['monotonicity_violations'] for x in all_models)
    assert all(x['joined']['status'] == 'converged' and x['direct']['status'] == 'converged' for x in all_models)

    cohort_rows, envelope_rows, costs, originals_source, repairs_source = [], [], [], [], []
    split_rows = []
    for N, prefix, root in [(30,'Core',EXP/'learned_admission/results/core'), (50,'Confirm',EXP/'learned_admission/confirmation_n50/results')]:
        aa = [x for x in original if x['N'] == N]
        bb = [x for x in repaired if x['N'] == N]
        mm = [x for x in matched if x['N'] == N]
        split = read(root/'splits/seed_0.json')
        for seed in range(1,5):
            s = read(root/f'splits/seed_{seed}.json')
            assert s['counts'] == split['counts']
        val(prefix+'N',N); val(prefix+'K',aa[0]['K']); val(prefix+'Carrier',aa[0]['inputs'])
        val(prefix+'Pairs',aa[0]['ordered_pairs']); val(prefix+'Raw',len(aa)); val(prefix+'Repair',len(bb))
        val(prefix+'Accept',cert(aa)); val(prefix+'Lawful',lawful(aa)); val(prefix+'RepairLawful',lawful(bb))
        val(prefix+'RepairAccept',cert(bb)); val(prefix+'MatchedAccept',cert(mm))
        val(prefix+'Test',split['counts']['test']); val(prefix+'Val',split['counts']['validation'])
        val(prefix+'TrainCounts', ', '.join(map(str, split['counts']['training'].values())))
        for cov, count in split['counts']['training'].items():
            split_rows.append([N, str(int(float(cov)*100))+r'\%',count, f'{100*count/aa[0]["inputs"]:.4f}'+r'\%',split['counts']['validation'],split['counts']['test']])
        for label, xs in [('Trained',aa),('Matched before',mm),('Repaired',bb)]:
            cohort_rows.append([N,label,len(xs),frac(lawful(xs),len(xs)),frac(cert(xs),len(xs)),frac(len(xs)-cert(xs),len(xs)),sum(x['joined_certificate']['accepted'] and x['raw_rules']['has_rule_violation'] for x in xs)])
        for label,xs in [('Trained',aa),('Repaired',bb)]:
            ds=[x['envelope']['mean_width_increase'] for x in xs]
            counts=[x['envelope']['strictly_wider_input_count'] for x in xs]
            envelope_rows.append([N,label,frac(sum(c>0 for c in counts),len(xs)),f'{min(counts)}--{max(counts)}',f'{st.median(ds):.4f}',f'{min(ds):.4f}--{max(ds):.4f}',f'$[0,{xs[0]["K"]}]$'])
        ar=[read(root/'A'/x['model_id']/'result.json') for x in aa]
        br=[read(root/'B'/x['model_id']/'result.json') for x in bb]
        originals_source += ar; repairs_source += br
        val(prefix+'Rounds', sum(len(x['rounds']) for x in br))
        val(prefix+'FWidth',aa[0]['envelope']['mean_F_width'],'.4f')
        val(prefix+'MaxTest',max(x['accuracy']['test']['exact_rate'] for x in aa)*100,'.4f')
        costs.append({'N':N,'carrier':aa[0]['inputs'], 'original_training_seconds':sum(x['training']['seconds'] for x in ar),
                      'repair_job_wall_seconds':sum(x['wall_seconds'] for x in br),
                      'repair_rounds':sum(len(x['rounds']) for x in br),
                      'oracle_requests_A':{k:sum(x['oracle']['requests'].get(k,0) for x in ar) for k in ar[0]['oracle']['requests']},
                      'oracle_requests_B':{k:sum(x['oracle']['requests'].get(k,0) for x in br) for k in br[0]['oracle']['requests']},
                      'envelope_cached_build_seconds':sum(x['envelope']['build_wall_seconds'] for x in aa+bb),
                      'terminal_joined_F_calls':sum(x['joined_certificate']['F_calls'] for x in aa+bb)})
        val(prefix+'TrainSeconds',costs[-1]['original_training_seconds'],'.4f')
        val(prefix+'RepairSeconds',costs[-1]['repair_job_wall_seconds'],'.4f')
    rows('cohorts.tex',cohort_rows); rows('envelope.tex',envelope_rows); rows('splits.tex',split_rows)
    js('generated/costs.json',costs)
    val('Rounds',sum(len(x['rounds']) for x in repairs_source))
    val('TotalUniqueOracle',sum(c['carrier'] for c in costs))
    val('FailedJobs',sum(x['status']!='completed' for x in originals_source+repairs_source))
    val('InvalidDecoded',sum(x['invalid_decoded_outputs'] for x in originals_source+repairs_source))
    val('IndependentInvalid',sum(x['invalid_independent_argmax_outputs'] for x in originals_source+repairs_source))
    val('TrainingSeconds',sum(c['original_training_seconds'] for c in costs),'.4f')
    val('RepairSeconds',sum(c['repair_job_wall_seconds'] for c in costs),'.4f')
    val('EnvelopeSeconds',sum(c['envelope_cached_build_seconds'] for c in costs),'.4f')
    val('RepairNewInputs',sum(r['added_n'] for x in repairs_source for r in x['rounds']))
    val('RepairRegressSound',sum(m['joined_certificate']['accepted'] and not b['joined_certificate']['accepted'] for m,b in zip(matched,repaired)))
    val('RepairRegressOmission',sum(b['raw_rules']['soundness_violations']>m['raw_rules']['soundness_violations'] for m,b in zip(matched,repaired)))
    val('RepairRegressMono',sum(b['raw_rules']['monotonicity_violations']>m['raw_rules']['monotonicity_violations'] for m,b in zip(matched,repaired)))
    for threshold,name in [(0.95,'NinetyFive'),(.98,'NinetyEight'),(.99,'NinetyNine')]:
        xs=[x for x in original if x['accuracy']['test']['exact_rate']>=threshold]
        val('Threshold'+name,threshold*100,'.0f'); val('Above'+name,len(xs))
        val('AboveBad'+name,sum(x['raw_rules']['has_rule_violation'] for x in xs))
    for seed,pref in [(1,'High'),(0,'Safe')]:
        x=index[50,f'w64_c80_s{seed}']
        for name,value in [('Test',x['accuracy']['test']['exact_rate']*100),('CarrierAccuracy',x['accuracy']['carrier']['exact_rate']*100)]: val(pref+name,value,'.4f')
        for name,value in [('Correct',x['accuracy']['test']['exact_count']),('TestSize',x['accuracy']['test']['n']),('Omissions',x['raw_rules']['soundness_violations']),('Mono',x['raw_rules']['monotonicity_violations']),('FinalHi',x['joined']['final'][1]),('FHi',x['joined_certificate']['F_final'][1]),('WiderInputs',x['envelope']['strictly_wider_input_count'])]:val(pref+name,value)
        val(pref+'Final',interval(x['joined']['final']));val(pref+'Ffinal',interval(x['joined_certificate']['F_final']))
    high=index[50,'w64_c80_s1']
    val('HighTrace',r'\to'.join([r'\bot']+[interval(t['next']) for t in high['joined']['trace'][:3]])+r'\to\cdots\to'+interval(high['joined']['final']))
    val('HighFalseBound',high['K']-1)
    w=high['envelope']['examples'][0]
    val('HighWitnessInput',interval(w['input']));val('HighWitnessF',interval(w['F']));val('HighWitnessE',interval(w['envelope']))

    conf=read(EXP/'learned_admission/config.json')
    read(EXP/'learned_admission/confirmation_n50/config.json')
    for k,name in [('epochs','Epochs'),('patience','Patience'),('batch_size','Batch'),('repair_width','RepairWidth'),('repair_rounds','MaxRounds'),('repair_new_inputs','RoundInputs'),('repair_epochs','RoundEpochs'),('repair_patience','RoundPatience')]:val(name,conf[k])
    val('LearningRate',conf['learning_rate'],'.4f');val('Seeds',', '.join(map(str,conf['seeds'])))
    val('Widths',', '.join(map(str,conf['widths'])))
    val('Coverages',r', '.join(str(int(x*100))+r'\%' for x in conf['coverages']))
    env=read(EXP/'learned_admission/results/core/environment.json')
    val('PythonVersion',env['python'].split()[0]);val('TorchVersion',env['packages']['torch'])
    import re
    val('CPU',re.search(r'"Name":\s*"([^"]+)"',env['hardware']).group(1).strip())
    val('Threads',env['threads'])
    val('VisibleMemoryGiB',int(re.search(r'"TotalVisibleMemorySize":\s*(\d+)',env['hardware']).group(1))/1024**2,'.4f')

    a=read(ALIGN/'main_n14_k9_paper/audit.json'); b=read(ALIGN/'main_n14_k9_paper/original_battery.json')
    val('PlantN',a['N']);val('PlantK',a['K']);val('PlantCarrier',a['inputs']);val('PlantPairs',b['metrics']['power']['ordered_pairs'])
    val('PlantPatterns',a['unique_candidate_tables']);val('PlantFWidth',a['analyses']['exact']['mean_width'],'.4f');val('PlantTopWidth',a['analyses']['top']['mean_width'],'.4f')
    pattern_rows=[]
    for seed,name in [(0,'Even'),(1,'Odd')]:
        rr=b['reports']['learned'][seed]; q=a['analyses'][f'raw_seed_{seed}']
        match=round(rr['one_step_exact_rate']*rr['inputs'])
        val(name+'Match',match);val(name+'Omissions',rr['overapproximation_violations']);val(name+'Mono',rr['monotonicity_violations'])
        val(name+'Final',interval(q['joined']['fixpoint']));val(name+'MeanWidth',q['mean_width'],'.4f')
        pattern_rows.append([name.lower(),frac(match,rr['inputs']),frac(rr['overapproximation_violations'],rr['inputs']),frac(rr['monotonicity_violations'],rr['ordered_pairs']),f'${interval(q["joined"]["fixpoint"])}$', 'sound' if q['joined']['sound'] else 'unsound', 'cycle' if q['direct']['status']!='converged' else f'${interval(q["direct"]["fixpoint"])}$'])
    rows('patterns.tex',pattern_rows)
    scale=[]
    for N in [14,30,50,100,150]:
        K=(3*N+4)//5
        q=read(ALIGN/f'scaling_n{N}_k{K}_paper/audit.json'); d=read(ALIGN/f'scaling_n{N}_k{K}_paper/original_battery.json')
        scale.append([N,K,q['inputs'],d['ordered_pairs'],f'{q["analyses"]["exact"]["mean_width"]:.4f}',f'{q["analyses"]["exact"]["mean_width"]/(N+1):.4f}',f'{q["timing_original_battery"]["wall_seconds"]:.4f}'])
    rows('scaling.tex',scale);js('generated/scaling.json',scale)
    val('ScaleMaxN',scale[-1][0]);val('ScaleMaxInputs',scale[-1][2]);val('ScaleMaxPairs',scale[-1][3])
    val('ScaleMaxWall',q['timing_original_battery']['wall_seconds'],'.4f')
    u=read(ALIGN/'scaling_n100_k60_paper/original_battery.json')['utility']
    val('UtilityN',u['N']);val('UtilityK',u['K']);val('UtilityTotal',u['true_assertion_count'])
    val('TopUtility',u['rows'][2]['assertions_proved']);val('TopFalseAlarms',u['rows'][2]['false_alarms'])

    # New, transparent executable check of the requested incompleteness example.
    bound,stride=10,2
    reachable={0}
    for _ in range(bound+2):
        nxt=reachable|{x+stride for x in reachable if x<bound}
        if nxt==reachable:break
        reachable=nxt
    I=(min(reachable),max(reachable))
    image={0}|{x+stride for x in range(I[0],I[1]+1) if x<bound}
    FI=(min(image),max(image))
    assert I==(0,10) and FI==(0,11) and not (FI[0]>=I[0] and FI[1]<=I[1])
    js('generated/incompleteness_example.json',{'guard_bound':bound,'stride':stride,'reachable':sorted(reachable),'sound_interval':I,'F_interval':FI,'certificate_accept':False})
    val('Stride',stride);val('StrideBound',bound);val('StrideSound',interval(I));val('StrideF',interval(FI))

    # All seeds remain visible in an artifact table; these are descriptive cohorts.
    csvrows=[]
    for x in final:
        csvrows.append({'N':x['N'],'stage':x['stage'],'id':x['model_id'],'test_exact':x['accuracy']['test']['exact_rate'],
                        'carrier_exact':x['accuracy']['carrier']['exact_rate'],'omissions':x['raw_rules']['soundness_violations'],
                        'monotonicity_pairs':x['raw_rules']['monotonicity_violations'],'global_pass':not x['raw_rules']['has_rule_violation'],
                        'certificate_accept':x['joined_certificate']['accepted'],'final':str(x['joined']['final']),
                        'envelope_wider_inputs':x['envelope']['strictly_wider_input_count'],
                        'envelope_mean_width_excess':x['envelope']['mean_width_increase'], 'source':f'experiments/trained_postfix_envelope_20261006/results/{x["id"]}/result.json'})
    with (OUT/'generated/all_models.csv').open('w',encoding='utf-8',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(csvrows[0]));wr.writeheader();wr.writerows(csvrows)
    configrows=[]
    for N in [30,50]:
        for width in sorted({int(x['model_id'].split('_')[0][1:]) for x in original if x['N']==N}):
            for coverage in sorted({int(x['model_id'].split('_')[1][1:]) for x in original if x['N']==N}):
                xs=[x for x in original if x['N']==N and x['model_id'].startswith(f'w{width}_c{coverage}_')]
                acc=[100*x['accuracy']['test']['exact_rate'] for x in xs]
                configrows.append([N,width,coverage, f'{st.median(acc):.4f}',f'{min(acc):.4f}--{max(acc):.4f}',frac(lawful(xs),len(xs)),frac(cert(xs),len(xs))])
    rows('configurations.tex',configrows)
    js('generated/final_models.json',csvrows)

    plt.rcParams.update({'font.family':'serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,ax=plt.subplots(1,2,figsize=(6.1,2.55),layout='constrained')
    for N,marker in [(30,'o'),(50,'^')]:
        for safe,color in [(False,'#b84a37'),(True,'#176a8a')]:
            xs=[x for x in original if x['N']==N and x['joined_certificate']['accepted']==safe]
            lab=f'N={N}, '+('sound final' if safe else 'unsound final')
            for a,key in zip(ax,['soundness_violations','monotonicity_violations']):
                a.scatter([100*x['accuracy']['test']['exact_rate'] for x in xs],[x['raw_rules'][key] for x in xs],s=23,marker=marker,c=color,label=lab,alpha=.8,edgecolors='white',linewidths=.3)
    for a in ax:a.set_xlabel('Held-out test exact match (%)');a.set_yscale('symlog',linthresh=1);a.grid(alpha=.15)
    ax[0].set_ylabel('Omission inputs');ax[1].set_ylabel('Monotonicity violation pairs')
    handles,labels=ax[0].get_legend_handles_labels()
    fig.legend(handles,labels,fontsize=7,loc='outside upper center',ncol=2)
    fig.savefig(OUT/'figures/accuracy.pdf');plt.close(fig)
    fig,ax=plt.subplots(1,2,figsize=(6.1,2.45),layout='constrained')
    for a,N in zip(ax,[30,50]):
        for x in repaired:
            if x['N']!=N:continue
            seq=[index[N,x['model_id']]]+sorted([t for t in all_models if t['N']==N and t['model_id']==x['model_id'] and t['stage']=='round'],key=lambda t:int(t['id'].rsplit('_',1)[1]))
            ys=[t['raw_rules']['soundness_violations'] for t in seq]
            a.plot(range(len(ys)),ys,marker='.',markersize=4,linewidth=.8,alpha=.8)
        a.set_title(f'N={N}');a.set_xlabel('Retraining round (0 = trained)');a.set_ylabel('Omission inputs');a.set_xticks(range(6));a.grid(alpha=.15)
    fig.savefig(OUT/'figures/repair.pdf');plt.close(fig)
    js('generated/values.json',VALUES)
    write('generated/numbers.tex','% Generated by scripts/generate.py; do not edit.\n'+ '\n'.join(r'\expandafter\def\csname D'+k+r'\endcsname{'+v['latex']+'}' for k,v in VALUES.items())+'\n')
    js('provenance/result_sources.json',SOURCES)
    print(json.dumps({'raw':len(original),'repaired':len(repaired),'macros':len(VALUES),'source_json':len(SOURCES),'rounds':VALUES['Rounds']['raw']},ensure_ascii=True))

if __name__=='__main__':main()
