"""Standalone data figures from checked saved records; no fitted or synthetic data."""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pymupdf

from check_data import ROOT, check
sys.path.insert(0, str(Path(__file__).parent / 'qa_tools'))
from audit_panel_alignment import require_matplotlib_panel_alignment

WIDTH_CM = 12.2
RED = '#D55E00'     # omission / unsound only
BLUE = '#004488'    # semantic coverage / sound; darker than omission red in grayscale
GRAY = '#C9CDD2'
INK = '#262626'
COLORS = {'equal': GRAY, 'extra': BLUE, 'omission': RED}


def setup():
    plt.rcParams.update({
        'font.family': 'serif', 'font.serif': ['Computer Modern Roman'],
        'text.usetex': True,
        'text.latex.preamble': r'\usepackage{amsmath,amssymb}'
             r'\DeclareMathSizes{8}{8}{7.2}{7.2}\DeclareMathSizes{9}{9}{7.2}{7.2}',
        'font.size': 8, 'axes.labelsize': 8, 'axes.titlesize': 9,
        'xtick.labelsize': 8, 'ytick.labelsize': 8, 'legend.fontsize': 8,
        'axes.spines.top': False, 'axes.spines.right': False,
        'axes.linewidth': .55, 'xtick.major.width': .5, 'ytick.major.width': .5,
        'xtick.major.size': 2.5, 'ytick.major.size': 2.5,
        'pdf.fonttype': 42, 'svg.fonttype': 'none',
        'text.color': INK, 'axes.labelcolor': INK, 'xtick.color': INK, 'ytick.color': INK,
    })


def interval(a):
    return r'\bot' if a is None else f'[{a[0]},{a[1]}]'


def preview(pdf):
    with pymupdf.open(pdf) as doc:
        doc[0].get_pixmap(dpi=300).save(pdf.with_suffix('.png'))


def save(fig, name):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=ROOT / f'qa/{name}.alignment.json',
                                      tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
    # Preserve the exact printed width; never use bbox_inches='tight'.
    pdf = ROOT / f'figures/{name}.pdf'
    fig.savefig(pdf)
    preview(pdf)
    plt.close(fig)


def figure_one(d):
    fig = plt.figure(figsize=(WIDTH_CM / 2.54, 8.0 / 2.54))
    grid = fig.add_gridspec(2, 2, left=.092, right=.982, bottom=.14, top=.76,
                           hspace=.55, wspace=.27, height_ratios=[4.1, 1])
    for col, panel in enumerate(d['panels']):
        r = panel['record']; n = r['N']; k = r['K']
        ax = fig.add_subplot(grid[0, col])
        strip = fig.add_subplot(grid[1, col])
        inputs = panel['inputs']; classes = panel['classes']
        xy = np.array(inputs[1:])
        ax.scatter(xy[:, 0], xy[:, 1], c=[COLORS[c] for c in classes[1:]],
                   s=4.1, marker='s', linewidths=0, zorder=1)
        omit = np.array(panel['omission_inputs'])
        ax.scatter(omit[:, 0], omit[:, 1], c=RED, s=19, marker='D',
                   edgecolors=INK, linewidths=.55, zorder=5)
        states = [t['state'] for t in r['joined']['trace'] if t['state'] is not None]
        path = np.array(states)
        ax.plot(path[:, 0], path[:, 1], '-o', color=INK, markersize=2,
                linewidth=.6, zorder=4, clip_on=False)
        final = r['joined']['final']
        # A ring identifies the final input; an open square marks the reachable target.
        ax.scatter(*final, s=63, marker='o', facecolors='none', edgecolors=INK,
                   linewidths=1.0, zorder=7)
        ax.scatter(0, k, s=60, marker='s', facecolors='none', edgecolors=INK,
                   linewidths=.75, zorder=6)
        ax.set_xlim(-2, n + 1); ax.set_ylim(-2, n + 1)
        ticks = np.linspace(0, n, 6, dtype=int)
        ax.set_xticks(ticks); ax.set_yticks(ticks)
        ax.set_xlabel(r'Lower bound $l$', labelpad=2)
        ax.set_ylabel(r'Upper bound $u$', labelpad=2)
        ax.set_aspect('auto')
        acc = r['accuracy']['carrier']['exact_rate'] * 100
        ax.text(.5, 1.25, r'\textbf{' + panel['letter'] + r'}\quad ' + f'{acc:.1f}' + r'\% exact',
                transform=ax.transAxes,ha='center',va='center',fontsize=8)
        outcome = 'stops at' if not r['joined_certificate']['accepted'] else 'reaches'
        condition = 'unsound' if not r['joined_certificate']['accepted'] else 'sound'
        ax.text(.5,1.09,r'$\to$ '+outcome+' $'+interval(final)+'$, '+condition,
                transform=ax.transAxes,ha='center',va='center',fontsize=8)
        if not r['joined_certificate']['accepted']:
            ffinal=r['joined_certificate']['F_final']
            tfinal=panel['predictions'][inputs.index(final)]
            text=(r'$T('+interval(final)+')='+interval(tfinal)+'$\n'
                  r'$F('+interval(final)+')='+interval(ffinal)+'$')
            ax.annotate(text,xy=final,xytext=(.29,.10),textcoords='axes fraction',
                        ha='left',va='bottom',fontsize=8,
                        arrowprops={'arrowstyle':'->','lw':.6,'color':INK,'connectionstyle':'arc3,rad=-.18'})
        # The supplementary strip separates input classes from overlaid path dots.
        edge_ids = [i for i, a in enumerate(inputs) if a is not None and a[0] == 0]
        for i in edge_ids:
            u = inputs[i][1]
            strip.add_patch(Rectangle((u-.5, -.20), 1, .43, facecolor=COLORS[classes[i]], lw=0))
        bottom_x = -4
        strip.add_patch(Rectangle((bottom_x-.55, -.20), 1.1, .43,
                                 facecolor=COLORS[classes[0]], edgecolor=INK, lw=.5))
        ups = [bottom_x] + [s[1] for s in states]
        strip.plot(ups, np.full(len(ups), .52), '-o', color=INK, lw=.55, markersize=1.9)
        for a, b in zip(ups, ups[1:]):
            if b-a > 1 and a >= 0:
                strip.annotate('', (b, .52), (a, .52),
                    arrowprops={'arrowstyle': '-', 'connectionstyle': 'arc3,rad=-.6', 'lw': .6})
        for i in edge_ids:
            if classes[i] == 'omission':
                strip.scatter(inputs[i][1], .01, marker='D', s=15, color=RED,
                              edgecolors=INK, linewidths=.45, zorder=8)
        strip.scatter(final[1], .52, s=35, facecolors='none', edgecolors=INK, lw=.8, zorder=9)
        strip.scatter(k, .52, marker='s', s=34, facecolors='none', edgecolors=INK, lw=.7, zorder=8)
        strip.set_xlim(-6, n+1); strip.set_ylim(-.28, 1.1)
        strip.set_xticks([bottom_x] + list(ticks), [r'$\bot$'] + list(map(str, ticks)))
        strip.set_yticks([]); strip.spines[['left','bottom']].set_visible(False)
        strip.set_xlabel(r'Edge inputs $[0,u]$', labelpad=2)
    handles = [Line2D([],[],marker='s',color=GRAY,ls='',markersize=4,label=r'$T=F$'),
               Line2D([],[],marker='s',color=BLUE,ls='',markersize=4,label=r'$F\sqsubset T$'),
               Line2D([],[],marker='D',color=RED,markeredgecolor=INK,ls='',markersize=4,label=r'$F\not\sqsubseteq T$'),
               Line2D([],[],marker='o',color=INK,markersize=2,lw=.6,label='Path'),
               Line2D([],[],marker='o',markerfacecolor='none',color=INK,ls='',markersize=5,label='Final'),
               Line2D([],[],marker='s',markerfacecolor='none',color=INK,ls='',markersize=5,label='Target')]
    fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,1.0),ncol=len(handles),
               frameon=False,handletextpad=.28,columnspacing=.65,handlelength=1.05,fontsize=8)
    save(fig,'figure_1_witnesses')


def figure_three(d):
    # Structural reuse of the original Figure 1: identical data, scales and group shapes.
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH_CM/2.54, 6.7/2.54))
    fig.subplots_adjust(left=.115, right=.975, bottom=.205, top=.755, wspace=.42)
    raw = d['raw']; ns = sorted({r['N'] for r in raw})
    keys = ['soundness_violations', 'monotonicity_violations']
    for n, marker in zip(ns, ['o', '^']):
        for safe, color in [(False, RED), (True, BLUE)]:
            xs = [r for r in raw if r['N'] == n and r['joined_certificate']['accepted'] == safe]
            label = f'$N={n}$, ' + ('sound final' if safe else 'unsound final')
            for ax, key in zip(axes, keys):
                ax.scatter([100*r['accuracy']['test']['exact_rate'] for r in xs],
                           [r['raw_rules'][key] for r in xs], s=23, marker=marker,
                           c=color, label=label, alpha=.8, edgecolors='white', linewidths=.3)
    threshold = d['values']['ThresholdNinetyFive']
    for ax, key in zip(axes, keys):
        ax.set_xlabel(r'Held-out test exact match (\%)')
        ax.set_xticks(json.loads((ROOT/'artifact/data/figure_layout.json').read_text())['scatter_xticks'])
        ax.set_yscale('symlog', linthresh=1)
        ax.grid(alpha=.15)
        ax.axvline(threshold, color=INK, ls='--', lw=.7)
        ax.text(threshold,1.035,f'{threshold:.0f}'+r'\%',transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
        for p in d['panels']:
            r = p['record']; y = r['raw_rules'][key]; x = 100*r['accuracy']['test']['exact_rate']
            offset = ((3, 17) if key == keys[0] else (-10, 8)) if p['letter'] == 'a' else (3, -8 if key == keys[0] else -15)
            ax.annotate(r'\textbf{' + p['letter'] + '}', (x, y), xytext=offset,
                        textcoords='offset points', ha='center', fontsize=8,
                        arrowprops={'arrowstyle': '-', 'lw': .5, 'color': INK})
    axes[0].set_ylabel('Omission inputs')
    axes[1].set_ylabel('Monotonicity violation pairs')
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, fontsize=8, loc='upper center', ncol=2, frameon=False,
               columnspacing=1.2, handletextpad=.3)
    save(fig, 'figure_3_accuracy')


def figure_repair(d):
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH_CM/2.54, 6.0/2.54))
    fig.subplots_adjust(left=.11,right=.975,bottom=.20,top=.72,wspace=.35)
    groups=sorted({p['N'] for p in d['processes']})
    coverages=sorted({int(p['model_id'].split('_')[1][1:]) for p in d['processes']})
    assert len(coverages)==2
    styles=dict(zip(coverages,[('#9A9A9A','-'),('#424242','--')]))
    endpoints=[]
    for ax,n in zip(axes,groups):
        for p in [p for p in d['processes'] if p['N']==n]:
            process=json.loads((ROOT/f"artifact/data/N{n}/repair/{p['model_id']}/result.json").read_text())
            rounds=process['rounds']
            xs=[0]+[r['round'] for r in rounds]
            ys=[p['before']['raw_rules']['soundness_violations']]+[r['soundness_violations'] for r in rounds]
            assert ys[-1]==p['after']['raw_rules']['soundness_violations']
            cov=int(p['model_id'].split('_')[1][1:]);color,ls=styles[cov]
            ax.plot(xs,ys,color=color,ls=ls,lw=.85,marker='.',markersize=2)
            accepted=p['after']['joined_certificate']['accepted']
            ax.plot(xs[-1],ys[-1],marker='o',ls='',markersize=4.5,
                    markerfacecolor=BLUE if accepted else 'white',
                    markeredgecolor=BLUE if accepted else INK,markeredgewidth=.7,zorder=5)
            endpoints.append({'N':n,'model_id':p['model_id'],'last_round':xs[-1],
                              'omissions':ys[-1],'filled':accepted,'coverage':cov})
        ax.set_title(f'$N={n}$',pad=6)
        ax.set_xlabel('Retraining round (0 = trained)')
        ax.set_ylabel('Omission inputs')
        ax.set_xticks(range(d['values']['MaxRounds']+1))
        ax.grid(alpha=.15)
    filled=sum(x['filled'] for x in endpoints)
    assert filled==d['values']['RepairAccept']
    assert len(endpoints)==d['values']['RepairCount']
    handles=[Line2D([],[],color=styles[c][0],ls=styles[c][1],lw=1,label=f'{c}'+r'\% training coverage') for c in coverages]
    handles += [Line2D([],[],color=BLUE,marker='o',ls='',markersize=4.5,label='Accepted final'),
                Line2D([],[],color=INK,marker='o',markerfacecolor='white',ls='',markersize=4.5,label='Rejected final')]
    fig.legend(handles=handles,loc='upper center',ncol=2,frameon=False,columnspacing=1.1,handletextpad=.5)
    (ROOT/'qa/repair_endpoints.json').write_text(json.dumps({'filled':filled,'total':len(endpoints),'endpoints':endpoints},indent=2))
    save(fig,'figure_4_repair')


if __name__ == '__main__':
    d = check()
    setup()
    for fn in [figure_one, figure_three, figure_repair]:
        print('Rendering',fn.__name__,flush=True)
        fn(d)
