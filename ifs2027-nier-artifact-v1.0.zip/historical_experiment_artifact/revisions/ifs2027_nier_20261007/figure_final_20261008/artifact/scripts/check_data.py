"""Read preserved evidence; fail before plotting if manuscript numbers disagree."""
from pathlib import Path
import hashlib
import json
import math
import re

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'artifact/data'


def read(path):
    return json.loads((DATA / path).read_text(encoding='utf-8'))


def contains(a, b):
    return b is None or (a is not None and a[0] <= b[0] and b[1] <= a[1])


def join(a, b):
    if a is None:
        return b
    if b is None:
        return a
    return [min(a[0], b[0]), max(a[1], b[1])]


def check():
    sources = read('sources.json')
    for name, meta in sources.items():
        assert hashlib.sha256((ROOT / name.replace('\\', '/')).read_bytes()).hexdigest() == meta['sha256'], name
    values = read('paper_snapshot/generated/values.json')
    v = {k: a['raw'] for k, a in values.items()}
    records = [json.loads(p.read_text()) for p in sorted((DATA / 'audit').glob('*/result.json'))]
    for r in records:
        assert r['status'] == 'complete'
        assert r['joined_certificate']['accepted'] == r['joined_certificate']['covers_reachable']
        assert r['raw_rules']['has_rule_violation'] == (r['raw_rules']['soundness_violations'] > 0 or r['raw_rules']['monotonicity_violations'] > 0)
    raw = [r for r in records if r['stage'] == 'original']
    repaired = [r for r in records if r['stage'] == 'repaired_final']
    ix = {(r['N'], r['model_id']): r for r in raw}
    matched = [ix[r['N'], r['model_id']] for r in repaired]
    accepted = lambda r: r['joined_certificate']['accepted']
    coverage = lambda r: r['raw_rules']['soundness_violations'] == 0
    both = lambda r: not r['raw_rules']['has_rule_violation']
    measured = {'RawCount': len(raw), 'RepairCount': len(repaired)}
    for name, fn in [('Accept', accepted), ('CoveragePass', coverage), ('Lawful', both)]:
        measured['Matched' + name] = sum(map(fn, matched))
        measured['Repair' + name] = sum(map(fn, repaired))
    pairs = list(zip(matched, repaired))
    for name, key in [('Omission', 'soundness_violations'), ('Mono', 'monotonicity_violations')]:
        measured['RepairRegress' + name] = sum(b['raw_rules'][key] > a['raw_rules'][key] for a, b in pairs)
    measured['RepairRegressSound'] = sum(accepted(a) and not accepted(b) for a, b in pairs)
    measured['ThresholdNinetyFive'] = v['ThresholdNinetyFive']
    truths = {n: read(f'N{n}/truth.json') for n in sorted({r['N'] for r in raw})}
    for n, truth in truths.items():
        prefix = 'Core' if n == min(truths) else 'Confirm'
        assert n == v[prefix + 'N'] and truth['K'] == v[prefix + 'K']
        assert len(truth['inputs']) == v[prefix + 'Carrier']
        assert truth['inputs'][0] is None
        assert len(truth['inputs']) == 1 + (n + 1) * (n + 2) // 2
    panels = []
    # Select exactly the two prespecified high-accuracy witnesses by their saved metrics.
    high = [r for r in raw if r['accuracy']['test']['exact_rate'] * 100 >= v['ThresholdNinetyFive']]
    assert len(high) == v['AboveNinetyFive']
    for letter, r in zip('ab', sorted(high, key=accepted)):
        pref = 'Safe' if accepted(r) else 'High'
        truth = truths[r['N']]
        table = read(f"audit/{r['id']}/tables.json")
        inputs, oracle, pred = truth['inputs'], truth['outputs'], table['predictions']
        assert len(inputs) == len(oracle) == len(pred) == r['inputs']
        classes = ['equal' if t == f else 'extra' if contains(t, f) else 'omission'
                   for f, t in zip(oracle, pred)]
        omission_ids = [i for i, c in enumerate(classes) if c == 'omission']
        measured[pref + 'Omissions'] = len(omission_ids)
        measured[pref + 'Final'] = r['joined']['final']
        assert len(omission_ids) == r['raw_rules']['soundness_violations']
        assert classes.count('equal') == r['accuracy']['carrier']['exact_count']
        assert r['accuracy']['carrier']['n'] == len(inputs)
        assert math.isclose(r['accuracy']['carrier']['exact_rate'], classes.count('equal') / len(inputs))
        assert math.isclose(r['accuracy']['carrier']['exact_rate'] * 100, v[pref + 'CarrierAccuracy'])
        assert pred[0] == oracle[0]
        split = read(f"N{r['N']}/splits/seed_{r['model_id'].rsplit('s', 1)[1]}.json")
        assert len(split['test']) == r['accuracy']['test']['n']
        assert sum(pred[i] == oracle[i] for i in split['test']) == r['accuracy']['test']['exact_count']
        assert math.isclose(r['accuracy']['test']['exact_rate'] * 100, v[pref + 'Test'])
        assert r['accuracy']['test']['exact_count'] == v[pref + 'Correct']
        assert r['accuracy']['test']['n'] == v[pref + 'TestSize']
        assert r['joined']['final'][1] == v[pref + 'FinalHi']
        assert r['joined_certificate']['F_final'][1] == v[pref + 'FHi']
        previous = None
        visited = []
        for step in r['joined']['trace']:
            assert step['state'] == previous
            i = inputs.index(step['state'])
            assert step['prediction'] == pred[i]
            assert step['next'] == join(step['state'], pred[i])
            visited.append(i)
            previous = step['next']
        assert previous == r['joined']['final']
        final_i = inputs.index(previous)
        assert oracle[final_i] == r['joined_certificate']['F_final']
        assert contains(previous, oracle[final_i]) == accepted(r)
        panels.append({'letter': letter, 'prefix': pref, 'record': r, 'inputs': inputs,
                       'oracle': oracle, 'predictions': pred, 'classes': classes,
                       'omission_inputs': [inputs[i] for i in omission_ids],
                       'visited_omission_inputs': [inputs[i] for i in omission_ids if i in visited]})
    assert panels[1]['visited_omission_inputs'] == []
    assert panels[0]['record']['joined']['final'] in panels[0]['visited_omission_inputs']
    for key in ['n', 'exact_count', 'exact_rate']:
        assert panels[0]['record']['accuracy']['carrier'][key] == panels[1]['record']['accuracy']['carrier'][key]
    # Validate every repaired-final record against the original saved repair process.
    process_rows = []
    for before, after in pairs:
        config = read(f"N{after['N']}/config.lock.json")
        width, coverage_id, seed = [int(x[1:]) for x in after['model_id'].split('_')]
        assert width == config['repair_width']
        assert coverage_id / 100 in config['repair_coverages'] and seed in config['seeds']
        assert v['ThresholdNinetyFive'] / 100 in config['thresholds']
        process = read(f"N{after['N']}/repair/{after['model_id']}/result.json")
        assert process['status'] == 'completed'
        for key in ['soundness_violations', 'monotonicity_violations']:
            assert after['raw_rules'][key] == process[key]
            if process['rounds']:
                assert process['rounds'][-1][key] == process[key]
        assert process['joined']['final'] == after['joined']['final']
        assert process['joined']['covers_reachable'] == after['joined_certificate']['covers_reachable']
        process_rows.append({'N': after['N'], 'model_id': after['model_id'], 'before': before,
                             'after': after, 'last_round': process['rounds'][-1]['round'] if process['rounds'] else 0})
    for key, value in measured.items():
        expected = v[key]
        if key.endswith('Final'):
            expected = [int(x) for x in re.findall(r'\d+', expected)]
        assert value == expected, (key, value, expected)
    for key, expected in read('request_expectations.json').items():
        assert measured[key] == expected, ('request', key, measured[key], expected)
    # Figure 1 must preserve all points, coordinate values, and original grid shapes.
    old_points = read('paper_snapshot/generated/final_models.json')
    for r in raw:
        old = next(q for q in old_points if q['stage'] == 'original' and q['N'] == r['N'] and q['id'] == r['model_id'])
        assert old['test_exact'] == r['accuracy']['test']['exact_rate']
        assert old['omissions'] == r['raw_rules']['soundness_violations']
        assert old['monotonicity_pairs'] == r['raw_rules']['monotonicity_violations']
        assert old['certificate_accept'] == r['joined_certificate']['accepted']
    report = {'status': 'PASS', 'sources_verified': len(sources), 'measured': measured,
              'witnesses': [{k: p[k] for k in ['letter', 'omission_inputs', 'visited_omission_inputs']} for p in panels],
              'original_models': len(raw), 'repair_processes': len(process_rows),
              'note': 'All checks precede rendering. No training, model inference, or repair is run.'}
    (ROOT / 'qa/data_check.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    return {'values': v, 'panels': panels, 'raw': raw, 'processes': process_rows, 'truths': truths}


if __name__ == '__main__':
    check()
    print((ROOT / 'qa/data_check.json').read_text())
