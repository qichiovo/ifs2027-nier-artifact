"""Physical-size, glyph, source, alignment and collision preflight."""
import json
import subprocess
import sys
from pathlib import Path
import pymupdf
from check_data import ROOT


def main():
    qa=ROOT/'qa'; scripts=Path(__file__).parent/'qa_tools'
    records=[]
    for pdf in sorted((ROOT/'figures').glob('*.pdf')):
        name=pdf.stem
        with pymupdf.open(pdf) as doc:
            assert len(doc)==1
            page=doc[0]
            assert abs(page.rect.width/72*2.54-12.2)<.002
            assert not page.get_images(), ('Non-vector figure',name)
            spans=[s for b in page.get_text('dict')['blocks'] for line in b.get('lines',[]) for s in line['spans']]
            assert min(s['size'] for s in spans)>=7
            dimensions={'width_cm':page.rect.width/72*2.54,'height_cm':page.rect.height/72*2.54,
                        'min_text_pt':min(s['size'] for s in spans),'fonts':sorted({s['font'] for s in spans}),
                        'raster_images':len(page.get_images())}
            page.get_pixmap(dpi=180,colorspace=pymupdf.csGRAY).save(qa/f'{name}.grayscale.png')
        for tool,args in [('audit_pdf_text.py',['--min-pt','7','--json']),
                          ('audit_figure_collisions.py',['--json-out',str(qa/f'{name}.collisions.json'),
                                                        '--overlay-pdf',str(qa/f'{name}.collisions.pdf')])]:
            run=subprocess.run([sys.executable,'-X','utf8','-B',str(scripts/tool),str(pdf),*args],capture_output=True,timeout=60)
            (qa/f'{name}.{tool}.log').write_bytes(run.stdout+run.stderr)
            records.append({'figure':name,'tool':tool,'exit':run.returncode,'dimensions':dimensions})
    run=subprocess.run([sys.executable,'-X','utf8','-B',str(scripts/'validate_figure.py'),
                        str(Path(__file__).with_name('plot_data.py')),'--json'],capture_output=True,timeout=60)
    (qa/'source_validation.json').write_bytes(run.stdout)
    (qa/'export_audit.json').write_text(json.dumps(records,indent=2))
    print(json.dumps([{'figure':r['figure'],'tool':r['tool'],'exit':r['exit']} for r in records],indent=2))
    if any(r['exit'] for r in records):raise SystemExit(1)


if __name__=='__main__':main()
