"""Compile the TikZ schematic with a bounded subprocess and retain the log."""
from pathlib import Path
import subprocess
import shutil
import json
import pymupdf
from check_data import ROOT, check


def compile_tex(source, name):
    target = ROOT/'build'/name
    target.mkdir(parents=True,exist_ok=True)
    command = ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
               '-output-directory=' + str(target), '-jobname=' + name, str(source)]
    run = subprocess.run(command, cwd=source.parent, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, timeout=120)
    (target/'console.log').write_bytes(run.stdout)
    if run.returncode:
        raise RuntimeError(run.stdout.decode(errors='replace')[-5000:])
    pdf=ROOT/'figures'/f'{name}.pdf'
    shutil.copy2(target/f'{name}.pdf',pdf)
    with pymupdf.open(pdf) as doc:
        assert len(doc)==1
        doc[0].get_pixmap(dpi=300).save(pdf.with_suffix('.png'))
    (ROOT/'qa'/f'{name}.build.json').write_text(json.dumps({'command':command,'returncode':run.returncode},indent=2))
    print('Built',name,flush=True)


if __name__=='__main__':
    check()
    compile_tex(Path(__file__).with_name('figure_2.tex'),'figure_2_admission')
