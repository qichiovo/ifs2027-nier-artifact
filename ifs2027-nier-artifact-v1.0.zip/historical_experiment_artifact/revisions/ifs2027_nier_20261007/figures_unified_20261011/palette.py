"""One colour scheme for every figure of the paper. Each colour has exactly one meaning."""

LIGHT_GRAY = '#DDDEE1'   # exact prediction / background / input domain
DEEP_GREEN = '#429466'   # sound / covered / guaranteed
PALE_GREEN = '#9AD4B3'   # wider but still covers (Figure 1 cells only)
PURPLE = '#6B4A99'       # omission / unsound / missed range
MECHANISM = '#555555'    # paths, oracle dots, arrows
CHECK = '#465A73'        # check steps and their descriptions (Figure 2 only)

# Neutrals without a meaning of their own.
FRAME = '#888888'        # thin frames, tick marks, leaders, guides
INK = '#262626'          # text and axes drawn by Matplotlib (TeX text in Figure 2 is black)
COVERAGE_LINES = ('#9A9A9A', '#424242')    # Figure 4: 20 % solid, 80 % dashed

FIGURE_1 = dict(exact=LIGHT_GRAY, wider=PALE_GREEN, omission=PURPLE, good=DEEP_GREEN, bad=PURPLE)

# The meaningful colours each figure may contain, and must contain.
ROLES = {
    'light gray': LIGHT_GRAY, 'deep green': DEEP_GREEN, 'pale green': PALE_GREEN,
    'purple': PURPLE, 'mechanism': MECHANISM, 'check blue': CHECK,
}
EXPECTED = {
    'figure_1': {'light gray', 'deep green', 'pale green', 'purple', 'mechanism'},
    'figure_2': {'light gray', 'deep green', 'mechanism'},
    'figure_3': {'deep green', 'purple'},
    'figure_4': {'deep green'},
}
