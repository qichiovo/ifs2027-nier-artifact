"""Draw Figure 1 as a three-step story, in the paper's unified palette (2026-10-11).

This is figure1_story_20261008/render.py with three changes: every colour comes from
palette.py, the iteration paths use the mechanism grey, and the frame of panel 3 has
rounded corners.

1  Every interval input of the two models, mirrored about their l = 0 columns.
2  The l = 0 columns enlarged, with each model's joined iteration.
3  The single prediction at which model a stops.

Everything drawn is read from saved predictions, oracle outputs, data splits and
iteration traces in ../figure1_story_20261008/data, pinned by its manifest.json.
No model is run.
"""
from pathlib import Path
import hashlib
import json
import math
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection, PatchCollection
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Rectangle
import pymupdf
from palette import FIGURE_1 as PALETTE, FRAME, INK, MECHANISM

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent / 'figure1_story_20261008' / 'data'     # the saved records, read only
NAME = 'figure_1'

W, H = 12.2, 5.50            # centimetres; one data unit is one centimetre
EDGE = GUIDE = FRAME         # frames, tick marks, leaders, dotted guides, hatching
TITLE, LABEL = 9.3, 8.5

BOX_RADIUS = 0.10            # corner radius of the frame of panel 3

TOP = 0.76                   # canvas top to the top of the triangles and strips
XC = 3.35                    # centre of the mirrored triangles
CELL = 2.54 / 72             # one input cell is one point square
SPINE = 0.12                 # drawn width of each l = 0 column in panel 1
BOX = (0.30, 6.35, 3.36, 5.00)        # panel 3: left, right, top and bottom (from canvas top)
STRIP_X = {'a': 7.20, 'b': 9.64}
STRIP_W = 0.80
STRIP_BOTTOM = 4.34          # from canvas top
MODELS = [('a', 'N50__A__w64_c80_s1', 'High'), ('b', 'N50__A__w64_c80_s0', 'Safe')]


def contains(outer, inner):
    return inner is None or (outer is not None and outer[0] <= inner[0] and inner[1] <= outer[1])


def join(a, b):
    return b if a is None else a if b is None else [min(a[0], b[0]), max(a[1], b[1])]


def iv(a):
    return f'[{a[0]},{a[1]}]'


def load(rel):
    return json.loads((DATA / rel).read_text(encoding='utf-8'))


def runs(column):
    """Merge neighbouring rows of one kind into (first u, row count, kind), to avoid seams."""
    merged = []
    for u, kind in sorted(column.items()):
        if merged and merged[-1][2] == kind and merged[-1][0] + merged[-1][1] == u:
            merged[-1][1] += 1
        else:
            merged.append([u, 1, kind])
    return merged


def read_models():
    """Load the two saved models and recheck every fact the figure states."""
    for rel, digest in load('manifest.json').items():
        assert hashlib.sha256((DATA / rel).read_bytes()).hexdigest() == digest, rel
    truth = load('N50/truth.json')
    inputs, oracle = truth['inputs'], truth['outputs']
    values = {key: value['raw'] for key, value in load('paper_snapshot/generated/values.json').items()}
    assert inputs[0] is None and len(inputs) == 1 + (truth['N'] + 1) * (truth['N'] + 2) // 2
    models = []
    for letter, ident, prefix in MODELS:
        record = load(f'audit/{ident}/result.json')
        pred = load(f'audit/{ident}/tables.json')['predictions']
        assert len(inputs) == len(oracle) == len(pred) == record['inputs']
        assert (record['N'], record['K']) == (truth['N'], truth['K'])
        kinds = ['exact' if t == f else 'wider' if contains(t, f) else 'omission'
                 for f, t in zip(oracle, pred)]
        assert kinds[0] == 'exact'                      # bottom is predicted exactly
        carrier, test = record['accuracy']['carrier'], record['accuracy']['test']
        assert carrier['n'] == len(inputs) and carrier['exact_count'] == kinds.count('exact')
        assert kinds.count('omission') == record['raw_rules']['soundness_violations'] == values[prefix + 'Omissions']
        split = load(f'N50/splits/seed_{ident[-1]}.json')['test']
        score = sum(pred[i] == oracle[i] for i in split)
        assert (score, len(split)) == (test['exact_count'], test['n'])
        assert math.isclose(100 * score / len(split), values[prefix + 'Test'])
        assert math.isclose(100 * carrier['exact_rate'], values[prefix + 'CarrierAccuracy'])

        visited, state = [], None
        for step in record['joined']['trace']:          # replay the recorded joined iteration
            assert step['state'] == state
            index = inputs.index(state)
            visited.append(index)
            assert step['prediction'] == pred[index] and step['next'] == join(state, pred[index])
            state = step['next']
        final = record['joined']['final']
        assert state == final and iv(final) == values[prefix + 'Final']
        last = inputs.index(final)
        certificate = record['joined_certificate']
        assert oracle[last] == certificate['F_final'] and iv(oracle[last]) == values[prefix + 'Ffinal']
        assert contains(final, oracle[last]) == certificate['accepted']
        assert contains(final, [0, record['K']]) == certificate['covers_reachable'] == certificate['accepted']
        assert all(s is None or s[0] == 0 for s in (inputs[i] for i in visited))   # the path stays on [0,u]

        omissions = [i for i, kind in enumerate(kinds) if kind == 'omission']
        marked = {tuple(inputs[i]): kind for i, kind in enumerate(kinds) if kind != 'exact'}
        models.append(dict(
            letter=letter, id=ident, N=record['N'], K=record['K'], kinds=kinds,
            counts={kind: kinds.count(kind) for kind in ('exact', 'wider', 'omission')},
            carrier=carrier, test=test, marked=marked,
            column={u: kind for (l, u), kind in marked.items() if l == 0},
            omissions=[inputs[i] for i in omissions],
            on_path=[inputs[i] for i in omissions if i in visited],
            off_path=[inputs[i] for i in omissions if i not in visited],
            visited=[inputs[i] for i in visited], final=final, T_final=pred[last],
            F_final=oracle[last], accepted=certificate['accepted']))
    a, b = models
    assert (a['N'], a['K']) == (values['ConfirmN'], values['ConfirmK'])
    assert a['carrier']['exact_count'] == b['carrier']['exact_count']       # the same accuracy
    assert not a['accepted'] and a['on_path'] == [a['final']]              # a stops on its one visited omission
    assert a['T_final'] == a['final'] and a['F_final'] == [0, a['final'][1] + 1]
    assert b['accepted'] and not b['on_path'] and b['final'] == [0, b['K']]
    run = sorted(b['off_path'])
    assert len({u for _, u in run}) == 1 and [l for l, _ in run] == list(range(run[0][0], run[-1][0] + 1))
    return models


def setup():
    sizes = ''.join(rf'\DeclareMathSizes{{{s}}}{{{s}}}{{7.2}}{{7.2}}' for s in ('8.5', '9', '9.3', '9.5'))
    plt.rcParams.update({
        'font.family': 'serif', 'font.serif': ['Computer Modern Roman'], 'font.size': LABEL,
        'text.usetex': True, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
        'text.latex.preamble': r'\usepackage{fix-cm,amsmath,amssymb}' + sizes,
    })


def draw(models, pal):
    a, b = models
    n, k = a['N'], a['K']
    fig, ax = plt.subplots(figsize=(W / 2.54, H / 2.54))
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, W), ylim=(0, H))
    ax.axis('off')
    texts = []

    def text(x, y, label, size=LABEL, ha='center', color=INK):
        artist = ax.text(x, y, label, fontsize=size, ha=ha, va='center', color=color, zorder=6)
        texts.append(artist)
        return artist

    def extent(artist):
        bb = artist.get_window_extent(fig.canvas.get_renderer())
        (x0, y0), (x1, y1) = ax.transData.inverted().transform([(bb.x0, bb.y0), (bb.x1, bb.y1)])
        return x0, y0, x1, y1

    def line(points, color=GUIDE, lw=.5, ls='-', zorder=5):
        ax.plot([p[0] for p in points], [p[1] for p in points], color=color, lw=lw, ls=ls,
                solid_capstyle='butt', dash_capstyle='butt', zorder=zorder)

    # ---- 1: every interval input [l,u]; l grows outwards from the centre, u upwards.
    c = CELL
    top1 = H - TOP
    bot1 = top1 - (n + 1) * c
    for side, model in ((-1, a), (1, b)):
        edge = XC + side * SPINE
        # One rectangle per row u, holding l = 1..u; the hairline edge hides seams between rows.
        rows = [Rectangle((min(edge, edge + side * u * c), bot1 + u * c), u * c, c) for u in range(1, n + 1)]
        ax.add_collection(PatchCollection(rows, facecolor=pal['exact'], edgecolor=pal['exact'],
                                          linewidth=.2, zorder=1))
        cells = {'wider': [], 'omission': []}
        for (l, u), kind in model['marked'].items():
            if l:
                x0 = edge + (l - 1) * c if side > 0 else edge - l * c
                cells[kind].append(Rectangle((x0, bot1 + u * c), c, c))
        for kind, patches in cells.items():
            ax.add_collection(PatchCollection(patches, facecolor=pal[kind], edgecolor=pal[kind],
                                              linewidth=.25, zorder=2))
        # The l = 0 column is drawn wider than one cell so that its rows stay visible.
        x0 = min(XC, edge)
        ax.add_patch(Rectangle((x0, bot1), SPINE, (n + 1) * c, facecolor=pal['exact'],
                               edgecolor='none', zorder=1))
        for u, count, kind in runs(model['column']):
            ax.add_patch(Rectangle((x0, bot1 + u * c), SPINE, count * c, facecolor=pal[kind],
                                   edgecolor=pal[kind], linewidth=.25, zorder=2))
    ax.add_patch(Rectangle((XC - SPINE, bot1), 2 * SPINE, (n + 1) * c, fill=False, edgecolor=INK,
                           linewidth=.6, zorder=4))
    line([(XC, bot1), (XC, top1)], color=INK, lw=.35, zorder=4)

    wing = n * c
    text(XC, H - .21, r'\textbf{1\quad All interval inputs} $[l,u]$', size=TITLE)
    text(XC - SPINE - wing / 2, H - .55, r'\textbf{a}', size=9)
    text(XC, H - .55, rf'$u={n}$')
    text(XC + SPINE + wing / 2, H - .55, r'\textbf{b}', size=9)
    y_axis = bot1 - .21
    text(XC, y_axis, '0')
    for side in (-1, 1):
        ax.add_patch(FancyArrowPatch((XC + side * .28, y_axis), (XC + side * .92, y_axis),
                                     arrowstyle='->', mutation_scale=6, lw=.6, color=INK,
                                     shrinkA=0, shrinkB=0, zorder=5))
        text(XC + side * 1.15, y_axis, '$l$')
    rate = 100 * a['carrier']['exact_rate']
    text(XC, y_axis - .33, rf'Both: {rate:.1f}\% exact')
    on_label = text(XC - 1.75, bot1 + .34, 'on path')
    off_label = text(XC + 2.20, bot1 + 1.27, 'off path')

    # ---- 3: the one prediction at which model a stops.
    bx0, bx1 = BOX[0], BOX[1]
    by1, by0 = H - BOX[2], H - BOX[3]
    ax.add_patch(FancyBboxPatch((bx0, by0), bx1 - bx0, by1 - by0,
                                boxstyle=f'round,pad=0,rounding_size={BOX_RADIUS}',
                                fill=False, edgecolor=EDGE, linewidth=.6, zorder=1))
    final, t_out, f_out = a['final'], a['T_final'], a['F_final']
    assert final[0] == t_out[0] == f_out[0] == 0
    text(bx0 + .22, by1 - .25, rf'\textbf{{3\quad Critical step (a) at}} $I={iv(final)}$', size=TITLE, ha='left')
    unit, bar_h, xb = .135, .13, bx0 + 1.85
    y_t, y_f, y_note = by1 - .62, by1 - .99, by0 + .25
    held = final[1] + 1                                  # values of F(I) that I already holds
    text(bx0 + .22, y_t, '$T(I)$', ha='left')
    text(bx0 + .22, y_f, '$F(I)$', ha='left')
    text(bx1 - .22, y_t, f'${iv(t_out)}$', ha='right')
    text(bx1 - .22, y_f, f'${iv(f_out)}$', ha='right')
    ax.add_patch(Rectangle((xb, y_t - bar_h / 2), (t_out[1] + 1) * unit, bar_h,
                           facecolor=pal['exact'], edgecolor='none', zorder=2))
    ax.add_patch(Rectangle((xb, y_f - bar_h / 2), held * unit, bar_h,
                           facecolor=pal['exact'], edgecolor='none', zorder=2))
    ax.add_patch(Rectangle((xb + held * unit, y_f - bar_h / 2), (f_out[1] + 1 - held) * unit, bar_h,
                           facecolor=pal['omission'], edgecolor='none', zorder=2))
    line([(xb + held * unit, y_f + bar_h / 2), (xb + held * unit, y_t - bar_h / 2)], ls=(0, (1, 1.6)))
    text(bx0 + .22, y_note, r'$F(I)\not\sqsubseteq I$: rejected', ha='left')

    y_legend = H - 5.28
    for x, kind, label in [(bx0 + .02, 'exact', 'Exact'), (bx0 + 1.72, 'wider', 'Wider, covers'), (bx0 + 4.28, 'omission', 'Omission')]:
        ax.add_patch(Rectangle((x, y_legend - .075), .15, .15, facecolor=pal[kind], edgecolor='none', zorder=2))
        text(x + .30, y_legend, label, ha='left')

    # ---- 2: the inputs [0,u] enlarged, one row per u, with each joined iteration.
    s_top, s_bot = H - TOP, H - STRIP_BOTTOM
    row = (s_top - s_bot) / (n + 1)

    def level(u):
        return s_bot + (u + .5) * row

    text((STRIP_X['a'] + STRIP_X['b'] + STRIP_W) / 2, H - .21, r'\textbf{2\quad Iteration on} $[0,u]$', size=TITLE)
    ticks, ends = {}, {}
    for model in models:
        x0, sound = STRIP_X[model['letter']], model['accepted']
        reached = model['final'][1]
        ax.add_patch(Rectangle((x0, s_bot), STRIP_W, s_top - s_bot, facecolor=pal['exact'],
                               edgecolor='none', zorder=1))
        if not sound:                                    # reachable rows the iteration never covers
            y0, y1 = s_bot + (reached + 1) * row, s_bot + (k + 1) * row
            hatch = []
            for i in range(-int(STRIP_W / .11) - 1, int((y1 - y0) / .11) + 2):
                t = i * .11
                lo, hi = max(0, -t), min(STRIP_W, (y1 - y0) - t)
                if hi - lo > .01:
                    hatch.append([(x0 + lo, y0 + lo + t), (x0 + hi, y0 + hi + t)])
            ax.add_collection(LineCollection(hatch, colors=GUIDE, linewidths=.35, zorder=2))
            ax.add_patch(Rectangle((x0, y0), STRIP_W, y1 - y0, fill=False, edgecolor=pal['omission'],
                                   linewidth=.7, zorder=4))
            missed = text(x0 - .53, (y0 + y1) / 2, 'missed', ha='right', color=pal['bad'])
            missed_at = (x0, (y0 + y1) / 2)
        for u, count, kind in runs(model['column']):
            ax.add_patch(Rectangle((x0, s_bot + u * row), STRIP_W, count * row, facecolor=pal[kind],
                                   edgecolor='none', zorder=3))
        ax.add_patch(Rectangle((x0, s_bot), STRIP_W, s_top - s_bot, fill=False, edgecolor=EDGE,
                               linewidth=.5, zorder=3.5))
        for u in sorted({0, a['final'][1], k, n}):
            line([(x0 + STRIP_W, level(u)), (x0 + STRIP_W + .07, level(u))], color=EDGE)
            label = rf'\textbf{{{u}}}' + (' target' if sound else '') if u == k else str(u)
            ticks[model['letter'], u] = text(x0 + STRIP_W + .17, level(u), label, ha='left')
        px, y_bot = x0 - .21, s_bot - .28
        line([(px, y_bot), (px, level(reached))], color=MECHANISM, lw=1.0, zorder=4)
        ax.add_patch(Circle((px, y_bot), .055, facecolor=MECHANISM, edgecolor='none', zorder=5))
        ax.add_patch(Circle((px, level(reached)), .085, facecolor='white',
                            edgecolor=pal['good' if sound else 'bad'], linewidth=1.1, zorder=5))
        ends[model['letter']] = (px, level(reached))
        text(px - .25, y_bot, r'$\bot$')
        text(x0 + STRIP_W / 2, H - .55, rf"\textbf{{{model['letter']}}}", size=9)
        text(x0 + STRIP_W / 2, H - 4.93, 'Sound' if sound else 'Unsound', size=9.5,
             color=pal['good' if sound else 'bad'])

    # ---- Leaders and guides that start from measured labels.
    fig.canvas.draw()
    gap = .08
    x_on = extent(on_label)[2] + gap
    line([(x_on, bot1 + .34), (XC - SPINE - .03, bot1 + (final[1] + .5) * c)])
    run = sorted(b['off_path'])
    x_run = XC + SPINE + (run[0][0] - 1 + run[-1][0]) / 2 * c
    line([(extent(off_label)[0] - gap, bot1 + 1.27), (x_run, bot1 + (run[0][1] + 1) * c + .02)])
    line([(extent(missed)[2] + gap, missed_at[1]), missed_at], color=pal['bad'], lw=.7)
    cx, cy = ends['a']
    sx, sy = bx1, by1 - .55
    reach = math.hypot(cx - sx, cy - sy)
    line([(sx, sy), (cx - (cx - sx) / reach * .11, cy - (cy - sy) / reach * .11)])
    bx, by = ends['b']
    dotted = dict(ls=(0, (1.2, 1.8)), zorder=4.5)
    line([(extent(ticks['a', k])[2] + gap, level(k)), (bx - .13, level(k))], **dotted)
    line([(bx + .13, level(k)), (STRIP_X['b'] + STRIP_W + .07, level(k))], **dotted)

    # ---- Layout checks on the rendered text.
    fig.canvas.draw()
    boxes = [(artist.get_text(), extent(artist)) for artist in texts]
    for label, (x0, y0, x1, y1) in boxes:
        assert x0 >= .02 and x1 <= W - .02 and y0 >= .02 and y1 <= H - .02, ('outside canvas', label)
    closest = (9.0, None)
    for i, (label, (x0, y0, x1, y1)) in enumerate(boxes):
        for other, (p0, q0, p1, q1) in boxes[i + 1:]:
            dx, dy = max(p0 - x1, x0 - p1), max(q0 - y1, y0 - q1)
            assert dx > 0 or dy > 0, ('text overlap', label, other)
            closest = min(closest, (round(max(dx, dy), 4), f'{label} | {other}'))
    assert closest[0] > .03, closest
    return fig, dict(closest_text_gap_cm=closest[0], closest_text_pair=closest[1], text_count=len(texts))


def export(fig, stem):
    pdf = ROOT / 'figures' / f'{stem}.pdf'
    fig.savefig(pdf, facecolor='white')
    fig.savefig(pdf.with_suffix('.svg'), facecolor='white')
    fig.savefig(pdf.with_suffix('.png'), dpi=300, facecolor='white')
    plt.close(fig)
    with pymupdf.open(pdf) as doc:
        page = doc[0]
        spans = [s for block in page.get_text('dict')['blocks']
                 for row in block.get('lines', []) for s in row['spans']]
        smallest = min(s['size'] for s in spans)
        assert smallest >= 7, smallest
        assert not page.get_images()
        assert abs(page.rect.width / 72 * 2.54 - W) < .002
        page.get_pixmap(dpi=300, colorspace=pymupdf.csGRAY).save(ROOT / 'qa' / f'{stem}.grayscale.png')
        return {'width_cm': page.rect.width / 72 * 2.54, 'height_cm': page.rect.height / 72 * 2.54,
                'minimum_actual_glyph_pt': smallest, 'fonts': sorted({s['font'] for s in spans}),
                'raster_images_in_pdf': len(page.get_images())}


def render():
    for folder in ['figures', 'qa']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    models = read_models()
    setup()
    report = {'data': 'Eight saved files in ../figure1_story_20261008/data, pinned by its manifest.json; '
                      'all checks in read_models() passed.',
              'models': [{key: model[key] for key in ('letter', 'id', 'N', 'K', 'counts', 'carrier', 'test',
                                                      'omissions', 'on_path', 'off_path', 'visited',
                                                      'final', 'T_final', 'F_final', 'accepted')}
                         | {'l0_column': {str(u): kind for u, kind in sorted(model['column'].items())}}
                         for model in models],
              'exports': {}}
    fig, layout = draw(models, PALETTE)
    report['exports'][NAME] = {**PALETTE, 'path': MECHANISM, 'frame': FRAME, 'ink': INK,
                               'box_radius_cm': BOX_RADIUS, **layout, **export(fig, NAME)}
    report.update({'matplotlib': matplotlib.__version__, 'python': sys.version, 'pymupdf': pymupdf.VersionBind})
    (ROOT / 'qa' / 'export.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    for stem, facts in report['exports'].items():
        print(stem, json.dumps({key: facts[key] for key in ('height_cm', 'minimum_actual_glyph_pt',
                                                             'closest_text_gap_cm', 'closest_text_pair')}))


if __name__ == '__main__':
    render()
