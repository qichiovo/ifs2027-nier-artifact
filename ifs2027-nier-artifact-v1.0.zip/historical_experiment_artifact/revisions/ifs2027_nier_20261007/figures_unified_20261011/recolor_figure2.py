"""Bring the supplied Figure 2 into the paper's unified palette.

The figure is the user's own PDF (made with pdfTeX), read unchanged from
../figures_green_purple_20261011/source/fig2_user.pdf. Four things change, all by
rewriting operators in its single content stream:

  blue  -> mechanism grey   checkpoints, route-card frames and their stems
  green -> deep green       what each guarantee covers
  grey  -> light grey       the iteration band (background)
  the outlined triangle of the lower glyph becomes a light-grey filled triangle,
  so that both glyphs show the input domain and green marks the covered part.

No shape moves and no text changes; the script checks that afterwards.
"""
from pathlib import Path
import hashlib
import json
import re
import pymupdf
from palette import DEEP_GREEN, LIGHT_GRAY, MECHANISM

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'figures_green_purple_20261011' / 'source' / 'fig2_user.pdf'
SOURCE_SHA256 = '289b3934cf89459b251a991fb52e0a9e67595a0048a822f31365a1e17f80ece2'
TARGET = ROOT / 'figures' / 'figure_2.pdf'
TEXT_WIDTH_CM = 12.2

REPLACE = {'#0B4A8B': MECHANISM, '#2E7D4F': DEEP_GREEN, '#EEEEEE': LIGHT_GRAY}
COLOUR_OP = re.compile(rb'(?<![\w.])([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+(rg|RG)\b')
# The lower glyph: a closed three-point path, set in grey and stroked.
GLYPH_OUTLINE = re.compile(
    rb'0\.53333 0\.53333 0\.53333 rg 0\.53333 0\.53333 0\.53333 RG'
    rb'(\s+[\d.]+ w\s+[-\d.]+ [-\d.]+ m\s+[-\d.]+ [-\d.]+ l\s+[-\d.]+ [-\d.]+ l\s+h\s+)S\b')


def hex_of(rgb):
    return '#%02X%02X%02X' % tuple(round(255 * float(v)) for v in rgb)


def operands(colour):
    return ' '.join('%.5f' % (int(colour[i:i + 2], 16) / 255) for i in (1, 3, 5)).encode()


def shapes(page):
    return [(d['type'], [round(v, 2) for v in d['rect']], len(d['items']),
             None if d.get('fill') is None else hex_of(d['fill']),
             None if d.get('color') is None else hex_of(d['color']))
            for d in page.get_drawings()]


def text_spans(page):
    return [(s['text'], s['font'], round(s['size'], 2), [round(v, 2) for v in s['bbox']], s['color'])
            for block in page.get_text('dict')['blocks']
            for line in block.get('lines', []) for s in line['spans']]


def main():
    for folder in ['figures', 'qa']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_SHA256, 'the supplied PDF changed'
    doc = pymupdf.open(SOURCE)
    assert len(doc) == 1
    page = doc[0]
    before_shapes, before_text = shapes(page), text_spans(page)
    assert not page.get_images()
    (xref,) = page.get_contents()
    stream = doc.xref_stream(xref)

    # 1. The lower glyph: fill the triangle with the light grey instead of stroking its outline.
    grey = operands(LIGHT_GRAY)
    stream, glyphs = GLYPH_OUTLINE.subn(grey + b' rg ' + grey + b' RG' + rb'\1' + b'f', stream)
    assert glyphs == 1, glyphs

    # 2. Colours.
    replaced = {old: 0 for old in REPLACE}

    def swap(match):
        old = hex_of(match.group(1, 2, 3))
        if old not in REPLACE:
            return match.group(0)
        replaced[old] += 1
        return operands(REPLACE[old]) + b' ' + match.group(4)

    stream = COLOUR_OP.sub(swap, stream)
    assert all(replaced.values()), replaced
    doc.update_stream(xref, stream)
    doc.save(TARGET, deflate=True)
    doc.close()

    with pymupdf.open(TARGET) as out:
        page = out[0]
        after_shapes, after_text = shapes(page), text_spans(page)
        assert after_text == before_text, 'text changed'
        assert len(after_shapes) == len(before_shapes)
        changed = []
        for old, new in zip(before_shapes, after_shapes):
            kind, box, items, fill, stroke = old
            expected = (kind, box, items, REPLACE.get(fill, fill), REPLACE.get(stroke, stroke))
            if (kind, fill, stroke, items) == ('s', None, '#888888', 3):     # the lower glyph
                expected = ('f', box, items, LIGHT_GRAY, None)
                changed.append(box)
            assert new == expected, (old, new, expected)
        assert len(changed) == 1
        used = sorted({c for shape in after_shapes for c in shape[3:] if c})
        assert not set(REPLACE) & set(used), used
        sizes = sorted({span[2] for span in after_text})
        width_cm, height_cm = (v / 72 * 2.54 for v in (page.rect.width, page.rect.height))
        scale = TEXT_WIDTH_CM / width_cm
        page.get_pixmap(dpi=300).save(TARGET.with_suffix('.png'))
        page.get_pixmap(dpi=300, colorspace=pymupdf.csGRAY).save(ROOT / 'qa' / 'figure_2.grayscale.png')
        report = {
            'source': 'figures_green_purple_20261011/source/fig2_user.pdf', 'source_sha256': SOURCE_SHA256,
            'colour_operators_rewritten': replaced, 'replacements': REPLACE,
            'lower_glyph': 'outlined triangle -> triangle filled with ' + LIGHT_GRAY,
            'shape_colours_after': used, 'shapes': len(after_shapes), 'text_spans': len(after_text),
            'positions_and_text_unchanged': True,
            'native_size_cm': [round(width_cm, 3), round(height_cm, 3)],
            'scale_at_text_width': round(scale, 4),
            'size_in_paper_cm': [TEXT_WIDTH_CM, round(height_cm * scale, 3)],
            'glyph_sizes_native_pt': sizes,
            'glyph_sizes_in_paper_pt': [round(s * scale, 2) for s in sizes],
            'pymupdf': pymupdf.VersionBind,
        }
    (ROOT / 'qa' / 'figure_2.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({key: report[key] for key in (
        'colour_operators_rewritten', 'lower_glyph', 'shape_colours_after',
        'positions_and_text_unchanged', 'size_in_paper_cm')}, indent=2))


if __name__ == '__main__':
    main()
