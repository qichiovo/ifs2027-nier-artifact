"""Figures 3 and 4 in the paper's unified palette.

Same checked records, coordinates, scales and layout as figure_3_accuracy and
figure_4_repair in ../figure_final_20261008/artifact/scripts/plot_data.py. Only
colours differ: unsound results are purple, sound and accepted results deep green.
The two coverage levels of Figure 4 stay two neutral greys, solid and dashed.
No model is run.
"""
from pathlib import Path
from unittest import mock
import json
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pymupdf
from palette import COVERAGE_LINES, DEEP_GREEN, INK, PURPLE

ROOT = Path(__file__).resolve().parent
EARLIER = ROOT.parent / 'figure_final_20261008' / 'artifact' / 'scripts'
sys.path[1:1] = [str(EARLIER), str(EARLIER / 'qa_tools')]
import check_data                                   # the earlier round's record checks
from plot_data import WIDTH_CM, setup               # its page width and font setup
from audit_panel_alignment import require_matplotlib_panel_alignment

RECORDS = check_data.ROOT / 'artifact' / 'data'


def checked_records():
    """Run the earlier round's checks without rewriting its report file."""
    report_path = check_data.ROOT / 'qa' / 'data_check.json'
    real_write = Path.write_text
    kept = {}

    def write_text(self, data, *args, **kwargs):
        if self == report_path:
            kept['report'] = data
            return len(data)
        return real_write(self, data, *args, **kwargs)

    with mock.patch.object(Path, 'write_text', write_text):
        records = check_data.check()
    (ROOT / 'qa' / 'figures_3_4_data_check.json').write_text(kept['report'], encoding='utf-8')
    return records


def save(fig, name):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig, json_out=ROOT / 'qa' / f'{name}.alignment.json',
                                       tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
    pdf = ROOT / 'figures' / f'{name}.pdf'
    fig.savefig(pdf)                                 # exact printed width; never bbox_inches='tight'
    plt.close(fig)
    with pymupdf.open(pdf) as doc:
        page = doc[0]
        assert abs(page.rect.width / 72 * 2.54 - WIDTH_CM) < .002 and not page.get_images()
        page.get_pixmap(dpi=300).save(pdf.with_suffix('.png'))
        page.get_pixmap(dpi=300, colorspace=pymupdf.csGRAY).save(ROOT / 'qa' / f'{name}.grayscale.png')
        return [round(page.rect.width / 72 * 2.54, 3), round(page.rect.height / 72 * 2.54, 3)]


def figure_3(d):
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH_CM / 2.54, 6.7 / 2.54))
    fig.subplots_adjust(left=.115, right=.975, bottom=.205, top=.755, wspace=.42)
    raw = d['raw']
    keys = ['soundness_violations', 'monotonicity_violations']
    counts = {}
    for n, marker in zip(sorted({r['N'] for r in raw}), ['o', '^']):
        for safe, colour in [(False, PURPLE), (True, DEEP_GREEN)]:
            xs = [r for r in raw if r['N'] == n and r['joined_certificate']['accepted'] == safe]
            label = f'$N={n}$, ' + ('sound final' if safe else 'unsound final')
            counts[f"N={n} {'sound' if safe else 'unsound'}"] = len(xs)
            for ax, key in zip(axes, keys):
                # Opaque markers, so the printed colour is exactly the palette value.
                ax.scatter([100 * r['accuracy']['test']['exact_rate'] for r in xs],
                           [r['raw_rules'][key] for r in xs], s=23, marker=marker,
                           c=colour, label=label, edgecolors='white', linewidths=.3)
    threshold = d['values']['ThresholdNinetyFive']
    xticks = json.loads((RECORDS / 'figure_layout.json').read_text())['scatter_xticks']
    for ax, key in zip(axes, keys):
        ax.set_xlabel(r'Held-out test exact match (\%)')
        ax.set_xticks(xticks)
        ax.set_yscale('symlog', linthresh=1)
        ax.grid(alpha=.15)
        ax.axvline(threshold, color=INK, ls='--', lw=.7)
        ax.text(threshold, 1.035, f'{threshold:.0f}' + r'\%', transform=ax.get_xaxis_transform(),
                ha='center', fontsize=8)
        for p in d['panels']:
            r = p['record']
            x, y = 100 * r['accuracy']['test']['exact_rate'], r['raw_rules'][key]
            offset = (((3, 17) if key == keys[0] else (-10, 8)) if p['letter'] == 'a'
                      else (3, -8 if key == keys[0] else -15))
            ax.annotate(r'\textbf{' + p['letter'] + '}', (x, y), xytext=offset,
                        textcoords='offset points', ha='center', fontsize=8,
                        arrowprops={'arrowstyle': '-', 'lw': .5, 'color': INK})
    axes[0].set_ylabel('Omission inputs')
    axes[1].set_ylabel('Monotonicity violation pairs')
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, fontsize=8, loc='upper center', ncol=2, frameon=False,
               columnspacing=1.2, handletextpad=.3)
    assert sum(counts.values()) == d['values']['RawCount']
    return {'points': counts, 'size_cm': save(fig, 'figure_3')}


def figure_4(d):
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH_CM / 2.54, 6.0 / 2.54))
    fig.subplots_adjust(left=.11, right=.975, bottom=.20, top=.72, wspace=.35)
    coverages = sorted({int(p['model_id'].split('_')[1][1:]) for p in d['processes']})
    assert len(coverages) == 2
    styles = dict(zip(coverages, zip(COVERAGE_LINES, ['-', '--'])))
    endpoints = []
    for ax, n in zip(axes, sorted({p['N'] for p in d['processes']})):
        for p in [p for p in d['processes'] if p['N'] == n]:
            process = json.loads((RECORDS / f"N{n}/repair/{p['model_id']}/result.json").read_text())
            rounds = process['rounds']
            xs = [0] + [r['round'] for r in rounds]
            ys = [p['before']['raw_rules']['soundness_violations']] + [r['soundness_violations'] for r in rounds]
            assert ys[-1] == p['after']['raw_rules']['soundness_violations']
            coverage = int(p['model_id'].split('_')[1][1:])
            colour, dash = styles[coverage]
            ax.plot(xs, ys, color=colour, ls=dash, lw=.85, marker='.', markersize=2)
            accepted = p['after']['joined_certificate']['accepted']
            ax.plot(xs[-1], ys[-1], marker='o', ls='', markersize=4.5,
                    markerfacecolor=DEEP_GREEN if accepted else 'white',
                    markeredgecolor=DEEP_GREEN if accepted else INK, markeredgewidth=.7, zorder=5)
            endpoints.append({'N': n, 'model_id': p['model_id'], 'last_round': xs[-1],
                              'omissions': ys[-1], 'filled': accepted, 'coverage': coverage})
        ax.set_title(f'$N={n}$', pad=6)
        ax.set_xlabel('Retraining round (0 = trained)')
        ax.set_ylabel('Omission inputs')
        ax.set_xticks(range(d['values']['MaxRounds'] + 1))
        ax.grid(alpha=.15)
    filled = sum(e['filled'] for e in endpoints)
    assert filled == d['values']['RepairAccept'] and len(endpoints) == d['values']['RepairCount']
    handles = [Line2D([], [], color=styles[c][0], ls=styles[c][1], lw=1, label=f'{c}' + r'\% training coverage')
               for c in coverages]
    handles += [Line2D([], [], color=DEEP_GREEN, marker='o', ls='', markersize=4.5, label='Accepted final'),
                Line2D([], [], color=INK, marker='o', markerfacecolor='white', ls='', markersize=4.5,
                       label='Rejected final')]
    fig.legend(handles=handles, loc='upper center', ncol=2, frameon=False, columnspacing=1.1, handletextpad=.5)
    return {'filled_end_markers': filled, 'end_markers': len(endpoints), 'endpoints': endpoints,
            'coverage_styles': {str(c): list(styles[c]) for c in coverages}, 'size_cm': save(fig, 'figure_4')}


def main():
    for folder in ['figures', 'qa']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    records = checked_records()
    setup()
    report = {'figure_3': figure_3(records), 'figure_4': figure_4(records),
              'colours': {'unsound': PURPLE, 'sound_or_accepted': DEEP_GREEN, 'coverage_lines': COVERAGE_LINES},
              'matplotlib': matplotlib.__version__}
    (ROOT / 'qa' / 'figures_3_4.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({'figure_3': {k: report['figure_3'][k] for k in ('points', 'size_cm')},
                      'figure_4': {k: report['figure_4'][k] for k in
                                   ('filled_end_markers', 'end_markers', 'coverage_styles', 'size_cm')}}, indent=2))


if __name__ == '__main__':
    main()
