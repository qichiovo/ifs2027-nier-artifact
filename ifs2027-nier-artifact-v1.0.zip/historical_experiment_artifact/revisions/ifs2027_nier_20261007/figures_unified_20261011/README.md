# One palette for Figures 1–4 (2026-10-11)

> **Update, later on 2026-10-11.** `render_figure1.py` was edited in place: Figure 1 lost three labels (`stops at [0,20]`, `reaches [0,30]`, the lone `21`) and the leading `T(I)=I;` of its note line. `palette.py` gained `CHECK`, the dark blue of Figure 2. The earlier script and exports are in
> `../provenance/figures_round4_20261011/before/`; see `../figures_round4_20261011/README.md`.

Previews: [Figure 1](figures/figure_1.png) · [Figure 2](figures/figure_2.png) ·
[Figure 3](figures/figure_3.png) · [Figure 4](figures/figure_4.png)

The user asked for one colour scheme across all figures, each colour with exactly one
meaning. Made by Claude Code (Anthropic, Claude Opus 5.5). All four figures of the paper
are now drawn from `palette.py`. Earlier figure folders, captions and PDFs are unchanged.

## Palette

| Role | Hex | Figure 1 | Figure 2 | Figure 3 | Figure 4 |
|---|---|---|---|---|---|
| Light gray: exact, background, input domain | `#DDDEE1` | exact cells, bars | iteration band, lower glyph | not used | not used |
| Deep green: sound, covered, guaranteed | `#429466` | "Sound" and its end marker | covered part of both glyphs | sound finals | accepted end markers |
| Pale green: wider but still covers | `#9AD4B3` | covering cells and rows | not used | not used | not used |
| Purple: omission, unsound, missed range | `#6B4A99` | omissions, missed rows, "Unsound" | not used | unsound finals | not used |
| Mechanism (dark gray): paths, checkpoints, oracle dots, arrows | `#555555` | iteration paths, start dots | checkpoints, card frames, arrows, dots | not used | not used |

`build_paper.py` reads every fill, stroke and text colour out of the four figure PDFs and
fails unless each figure contains exactly the hued colours listed for it, at full opacity,
and no other hue. It passed: the hex values are identical in every figure that uses a role.

Neutrals that carry no meaning: frames, tick marks and leaders `#888888`; text and axes
`#262626` in the figures drawn here and black in Figure 2 (TeX); grid lines `#B0B0B0`;
and, in Figure 4 only, the two coverage lines `#9A9A9A` (20 %, solid) and `#424242`
(80 %, dashed).

Purple and deep green changed slightly from the previous round (`#7D5BA6`, `#3F8B60`):
purple is now darker and green lighter, so that the two classes of Figure 3 stay apart
in grayscale.

## What changed in each figure

- **Figure 1** (`render_figure1.py`): covering cells are pale green instead of the green
  used for "Sound"; the iteration paths and their start dots use the mechanism gray;
  frames and leaders use one frame gray. Data, layout, size and caption are unchanged.
- **Figure 2** (`recolor_figure2.py`): still the user's PDF, read unchanged from
  `../figures_green_purple_20261011/source/fig2_user.pdf`. Checkpoints, card frames and
  stems are the mechanism gray; the glyph green is the palette's deep green; the
  iteration band is the palette's light gray. One shape changed kind: the lower glyph
  was an outlined triangle and is now a triangle filled with the light gray, so that it
  shows the input domain with one covered cell. No shape moved and no text changed.
- **Figure 3** (`render_figures_3_4.py`): unsound finals purple, sound finals deep green.
  Markers are now opaque (they were 80 % opaque), so the printed colour is exactly the
  palette value. Points, scales, labels and layout are unchanged.
- **Figure 4** (same script): accepted end markers are filled deep green, rejected ones
  hollow; the two coverage levels keep their two grays, solid and dashed.

Figures 3 and 4 read the checked records of `../figure_final_20261008/artifact/data`
through that round's own checks. Its files are not rewritten.

## Captions

- Figure 2 (`caption_figure2.tex`): the sentence about the right-hand column and the
  triangles is replaced by the two sentences the user supplied, beginning "Each glyph is
  Figure 1's input domain." The definition of `m` moved into the last sentence.
- Figure 4 (`caption_figure4.tex`): "Filled blue final markers" became "Filled green
  final markers". Nothing else changed.
- Figures 1 and 3: unchanged; neither names a colour.

## Rebuild

From the manuscript directory:

```powershell
python -X utf8 -B figures_unified_20261011/render_figure1.py
python -X utf8 -B figures_unified_20261011/recolor_figure2.py
python -X utf8 -B figures_unified_20261011/render_figures_3_4.py
python -X utf8 -B figures_unified_20261011/build_paper.py
```

All four were run. The last writes `../paper_unified_palette.pdf` and receipts in
`../provenance/figures_unified_20261011/`.

## State of the manuscript

`../paper_unified_palette.pdf`: Figures 1–4 on pages 2, 5, 6 and 13; 9 main pages, 1
data-statement page, 1 reference page and 4 appendix pages, 15 in total. No overfull or
underfull boxes, no undefined references, fonts embedded. Figures 1, 3 and 4 pass the
glyph-size and collision audits. Figure 2 passes the collision audit; at text width its
type is still 6.0–6.7 pt with 4.5 pt subscripts, as in the previous round. The main text
is still one page over the 8-page target.

Six source lines changed: the include path of each of the four figures, and the caption
inputs of Figures 2 and 4. Pre-edit copies are in
`../provenance/figures_unified_20261011/before/`.

Not done: no source ZIP was packaged and nothing was committed to Git.
