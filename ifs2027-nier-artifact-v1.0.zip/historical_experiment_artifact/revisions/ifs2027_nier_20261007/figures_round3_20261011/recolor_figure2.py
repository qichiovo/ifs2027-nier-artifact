"""Figure 2: the supplied PDF with two colours replaced and nothing else changed.

Its blue (both checkpoints, the frames of both route cards, and the two stems
joining them) becomes the low-saturation dark blue CHECK; its green (the covered
part of both glyphs) becomes the paper's deep green. The iteration band, the
outlined lower glyph, arrows, dots, text and all positions are as supplied.

Until 2026-10-11 the first replacement was the palette's purple; the user then
asked for dark blue, so that purple keeps one meaning in the paper.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import pymupdf

ROOT = Path(__file__).resolve().parent
sys.path.insert(1, str(ROOT.parent / 'figures_unified_20261011'))
from palette import CHECK, DEEP_GREEN               # the paper's palette, one source for all figures

SOURCE = ROOT.parent / 'figures_green_purple_20261011' / 'source' / 'fig2_user.pdf'
SOURCE_SHA256 = '289b3934cf89459b251a991fb52e0a9e67595a0048a822f31365a1e17f80ece2'
TARGET = ROOT / 'figures' / 'figure_2.pdf'
TEXT_WIDTH_CM = 12.2
REPLACE = {'#0B4A8B': CHECK, '#2E7D4F': DEEP_GREEN}
COLOUR_OP = re.compile(rb'(?<![\w.])([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+(rg|RG)\b')


def hex_of(rgb):
    return '#%02X%02X%02X' % tuple(round(255 * float(v)) for v in rgb)


def shapes(page):
    return [(d['type'], [round(v, 2) for v in d['rect']], len(d['items']),
             None if d.get('fill') is None else hex_of(d['fill']),
             None if d.get('color') is None else hex_of(d['color']))
            for d in page.get_drawings()]


def text_spans(page):
    return [(s['text'], s['font'], round(s['size'], 2), [round(v, 2) for v in s['bbox']], s['color'])
            for block in page.get_text('dict')['blocks']
            for line in block.get('lines', []) for s in line['spans']]


def main():
    for folder in ['figures', 'qa']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_SHA256, 'the supplied PDF changed'
    doc = pymupdf.open(SOURCE)
    page = doc[0]
    before_shapes, before_text = shapes(page), text_spans(page)
    (xref,) = page.get_contents()
    replaced = {old: 0 for old in REPLACE}

    def swap(match):
        old = hex_of(match.group(1, 2, 3))
        if old not in REPLACE:
            return match.group(0)
        replaced[old] += 1
        new = REPLACE[old]
        return ' '.join('%.5f' % (int(new[i:i + 2], 16) / 255) for i in (1, 3, 5)).encode() + b' ' + match.group(4)

    doc.update_stream(xref, COLOUR_OP.sub(swap, doc.xref_stream(xref)))
    assert all(replaced.values()), replaced
    doc.save(TARGET, deflate=True)
    doc.close()

    with pymupdf.open(TARGET) as out:
        page = out[0]
        after_shapes = shapes(page)
        assert text_spans(page) == before_text, 'text changed'
        expected = [(kind, box, items, REPLACE.get(fill, fill), REPLACE.get(stroke, stroke))
                    for kind, box, items, fill, stroke in before_shapes]
        assert after_shapes == expected, 'a shape changed beyond its colour'
        # Same drawing as the previous version of this figure, colour values aside.
        previous = ROOT.parent / 'figures_green_purple_20261011' / 'figures' / 'figure_2.pdf'
        with pymupdf.open(previous) as old:
            assert [s[:3] for s in shapes(old[0])] == [s[:3] for s in after_shapes]
            assert text_spans(old[0]) == before_text
            old_colours = sorted({c for s in shapes(old[0]) for c in s[3:] if c})
        used = sorted({c for shape in after_shapes for c in shape[3:] if c})
        sizes = sorted({span[2] for span in before_text})
        width_cm, height_cm = (v / 72 * 2.54 for v in (page.rect.width, page.rect.height))
        scale = TEXT_WIDTH_CM / width_cm
        page.get_pixmap(dpi=300).save(TARGET.with_suffix('.png'))
        report = {
            'source': 'figures_green_purple_20261011/source/fig2_user.pdf', 'source_sha256': SOURCE_SHA256,
            'colour_operators_rewritten': replaced, 'replacements': REPLACE,
            'same_shapes_and_text_as_previous_version': True,
            'previous_version_colours': old_colours, 'colours_now': used,
            'size_in_paper_cm': [TEXT_WIDTH_CM, round(height_cm * scale, 3)],
            'glyph_sizes_in_paper_pt': [round(s * scale, 2) for s in sizes],
        }
    (ROOT / 'qa' / 'figure_2.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
