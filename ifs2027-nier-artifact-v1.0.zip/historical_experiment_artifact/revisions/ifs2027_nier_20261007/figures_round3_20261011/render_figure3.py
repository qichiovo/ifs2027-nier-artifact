"""Figure 3: held-out accuracy of every trained model above its law and result rows, with a pull-out of the most accurate.

Redrawn on 2026-10-12 after a sketch of the user. One column per trained model, in
order of held-out exact match. On top, that accuracy as a curve over dotted guides.
Below, three rows of cells: coverage, monotonicity, final invariant, each green or
purple. A last row marks the models of the larger grid. The six most accurate
columns are boxed and repeated enlarged on the right, where the two witnesses of
Figure 1 carry their letters, and a short legend gives their accuracy and final
invariant. Colours are the paper's palette, unchanged.

Every value comes from the checked records of ../figure_final_20261008, through
that round's own checks. No model is run.
"""
from pathlib import Path
from unittest import mock
import json
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import pymupdf

ROOT = Path(__file__).resolve().parent
EARLIER = ROOT.parent / 'figure_final_20261008' / 'artifact' / 'scripts'
sys.path[1:1] = [str(ROOT.parent / 'figures_unified_20261011'), str(EARLIER)]
from palette import DEEP_GREEN, FRAME, INK, PURPLE                 # the paper's palette
import check_data                                                 # the earlier round's record checks

NAME = 'figure_3'
W, H = 12.2, 4.20                # centimetres; one data unit is one centimetre; the size of the figure it replaces
LABEL = 8
LABEL_X = 2.38                   # right edge of the row and scale labels
X0, PITCH, CELL_W = 2.60, 0.092, 0.066
CURVE_95, CM_PER_POINT = 0.30, 0.030   # where 95 % lies, from the canvas top, and the scale of the accuracy panel
GUIDES = [50, 75, 95]
AXIS_X, AXIS_LABEL = 1.72, [('held-out', 1.04), ('exact match', 1.33)]   # left of the scale labels, between two guides
ROWS = [('coverage', 2.24), ('monotonicity', 2.54), ('final invariant', 2.84)]
CELL_H = 0.17
GRID_ROW = 3.13                  # the row that marks the larger grid
ZOOM = 6                         # so many of the most accurate columns are repeated enlarged
ZX0, ZPITCH, ZCELL_W, ZCELL_H = 9.14, 0.29, 0.225, 0.26
ZROWS, ZGRID = [2.18, 2.54, 2.90], 3.19
ZTOP, ZBOTTOM = 1.66, 3.31       # vertical extent of the pull-out
LETTER, LETTER_BASELINE = 9, 1.93
NOTE_X, NOTE_ROWS, NOTE_RANGE = (9.14, 9.50, 10.86), (0.80, 1.12), 1.44
WITNESSES = {'a': (50, 'w64_c80_s1'), 'b': (50, 'w64_c80_s0')}      # the models of Figure 1


def checked_records():
    """Run the earlier round's checks without rewriting its report file."""
    report_path = check_data.ROOT / 'qa' / 'data_check.json'
    real_write = Path.write_text
    kept = {}

    def write_text(self, data, *args, **kwargs):
        if self == report_path:
            kept['report'] = data
            return len(data)
        return real_write(self, data, *args, **kwargs)

    with mock.patch.object(Path, 'write_text', write_text):
        records = check_data.check()
    (ROOT / 'qa' / 'figure_3_data_check.json').write_text(kept['report'], encoding='utf-8')
    return records


def models(d):
    """One row per trained model, in the order drawn."""
    witness = {(p['record']['N'], p['record']['model_id']): p['letter'] for p in d['panels']}
    assert {letter: key for key, letter in witness.items()} == WITNESSES
    rows = [dict(N=r['N'], model_id=r['model_id'], accuracy=100 * r['accuracy']['test']['exact_rate'],
                 coverage=r['raw_rules']['soundness_violations'] == 0,
                 monotonicity=r['raw_rules']['monotonicity_violations'] == 0,
                 final=r['joined_certificate']['accepted'],
                 invariant=r['joined']['final'],
                 letter=witness.get((r['N'], r['model_id'])))
            for r in d['raw']]
    rows.sort(key=lambda m: (m['accuracy'], m['N'], m['model_id']))       # ties: grid, then model id
    v = d['values']
    large = max(m['N'] for m in rows)
    assert len(rows) == v['RawCount'] and large == v['ConfirmN']
    assert sum(m['final'] for m in rows) == v['RawAccept']
    assert sum(m['coverage'] and m['monotonicity'] for m in rows) == v['RawLawful']
    assert sum(m['N'] == large for m in rows) == v['ConfirmRaw']
    above = [m for m in rows if m['accuracy'] >= v['ThresholdNinetyFive']]
    assert len(above) == v['AboveNinetyFive'] and above == rows[-len(above):]
    assert [m['letter'] for m in above] == ['b', 'a'] and all(m['N'] == large for m in above)
    assert [m['final'] for m in above] == [True, False]                   # b is sound, a is not
    assert not any(m['coverage'] or m['monotonicity'] for m in above)     # neither passes a global law
    # The witnesses' final invariants against the reachable range [0, K] of their grid.
    a, b = (next(m for m in rows if m['letter'] == letter) for letter in 'ab')
    reachable = [0, v['ConfirmK']]
    assert b['invariant'] == reachable and a['invariant'][0] == 0 and a['invariant'][1] < reachable[1]
    return rows, large, reachable


def draw(rows, large, reachable):
    fig, ax = plt.subplots(figsize=(W / 2.54, H / 2.54))
    fig.subplots_adjust(left=0, right=1, bottom=0, top=1)
    ax.set(xlim=(0, W), ylim=(0, H))
    ax.axis('off')
    texts = []

    def text(x, y_top, label, ha='center', color=INK, size=LABEL, va='center'):
        artist = ax.text(x, H - y_top, label, fontsize=size, ha=ha, va=va, color=color, zorder=6)
        texts.append(artist)
        return artist

    def left(i):
        return X0 + i * PITCH

    def level(per_cent):
        return H - (CURVE_95 + (95 - per_cent) * CM_PER_POINT)

    n = len(rows)
    x_end = left(n - 1) + CELL_W
    assert level(max(m['accuracy'] for m in rows)) < H - .12
    assert level(min(m['accuracy'] for m in rows)) > H - (ROWS[0][1] - CELL_H / 2 - .12)

    # Accuracy: one point per model at its column centre, over dotted guides labelled on the left.
    for per_cent in GUIDES:
        ax.plot([left(0), x_end], [level(per_cent)] * 2, color=FRAME, lw=.4, ls=(0, (1, 2.2)), zorder=2)
        text(LABEL_X, H - level(per_cent), rf'{per_cent}\%', ha='right', color=FRAME)
    points = [(left(i) + CELL_W / 2, level(m['accuracy'])) for i, m in enumerate(rows)]
    ax.plot(*zip(*points), color=INK, lw=.8, solid_joinstyle='round', zorder=3)
    for label, y_top in AXIS_LABEL:
        text(AXIS_X, y_top, label, ha='right')

    # Law and result rows, and the row of the larger grid.
    for (label, y_top), key in zip(ROWS, ['coverage', 'monotonicity', 'final']):
        text(LABEL_X, y_top, label, ha='right')
        for i, m in enumerate(rows):
            ax.add_patch(Rectangle((left(i), H - y_top - CELL_H / 2), CELL_W, CELL_H,
                                   facecolor=DEEP_GREEN if m[key] else PURPLE, edgecolor='none', zorder=2))
    text(LABEL_X, GRID_ROW, rf'$N={large}$', ha='right')
    for i, m in enumerate(rows):
        if m['N'] == large:
            ax.plot([left(i), left(i) + CELL_W], [H - GRID_ROW] * 2, lw=1.3, solid_capstyle='butt', color=INK, zorder=2)

    # The most accurate columns: a box in the strip and the same columns enlarged on the right.
    shown = list(range(n - ZOOM, n))
    assert all(rows[i]['letter'] is None for i in range(n - ZOOM)) and sum(bool(rows[i]['letter']) for i in shown) == 2
    box_x0, box_x1 = left(shown[0]) - .03, x_end + .03
    box_top, box_bottom = ROWS[0][1] - CELL_H / 2 - .05, GRID_ROW + .08
    ax.add_patch(Rectangle((box_x0, H - box_bottom), box_x1 - box_x0, box_bottom - box_top, fill=False,
                           edgecolor=FRAME, linewidth=.5, zorder=4))
    edge = ZX0 - .09                                                       # left edge of the pull-out
    for a, b in [((box_x1, box_top), (edge, ZTOP)), ((box_x1, box_bottom), (edge, ZBOTTOM)), ((edge, ZTOP), (edge, ZBOTTOM))]:
        ax.plot([a[0], b[0]], [H - a[1], H - b[1]], color=FRAME, lw=.5, solid_capstyle='round', zorder=4)
    letters = []
    for j, i in enumerate(shown):
        m, x = rows[i], ZX0 + j * ZPITCH
        for y_top, key in zip(ZROWS, ['coverage', 'monotonicity', 'final']):
            ax.add_patch(Rectangle((x, H - y_top - ZCELL_H / 2), ZCELL_W, ZCELL_H,
                                   facecolor=DEEP_GREEN if m[key] else PURPLE, edgecolor='none', zorder=2))
        if m['N'] == large:
            ax.plot([x, x + ZCELL_W], [H - ZGRID] * 2, lw=2.0, solid_capstyle='butt', color=INK, zorder=2)
        if m['letter']:
            letters.append(text(x + ZCELL_W / 2, LETTER_BASELINE, rf"\textbf{{{m['letter']}}}", size=LETTER, va='baseline'))
    zoom_right = ZX0 + (ZOOM - 1) * ZPITCH + ZCELL_W

    # What the two letters stand for.
    for letter, y_top in zip('ab', NOTE_ROWS):
        m = next(m for m in rows if m['letter'] == letter)
        text(NOTE_X[0], y_top, rf'\textbf{{{letter}}}', ha='left', va='baseline')
        text(NOTE_X[1], y_top, rf"{m['accuracy']:.1f}\%", ha='left', va='baseline')
        text(NOTE_X[2], y_top, rf"$I=[{m['invariant'][0]},{m['invariant'][1]}]$", ha='left', va='baseline')
    text(NOTE_X[0], NOTE_RANGE, rf'reachable range $[{reachable[0]},{reachable[1]}]$', ha='left', color=FRAME, va='baseline')

    text((left(0) + x_end) / 2, 3.48, rf'{n} trained models, in order of accuracy $\rightarrow$')
    y_legend, x = 3.86, 1.62
    for colour, label, advance in [(DEEP_GREEN, 'holds / sound', 2.56), (PURPLE, 'violated / unsound', 3.26)]:
        ax.add_patch(Rectangle((x, H - y_legend - CELL_H / 2), .13, CELL_H, facecolor=colour, edgecolor='none', zorder=2))
        text(x + .25, y_legend, label, ha='left')
        x += advance
    ax.plot([x, x + .15], [H - y_legend - .03] * 2, lw=1.6, color=INK, solid_capstyle='butt', zorder=2)
    text(x + .27, y_legend, rf'$N={large}$ model', ha='left')

    # Layout checks on the rendered text.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()

    def extent(artist):
        bb = artist.get_window_extent(renderer)
        (x0, y0), (x1, y1) = ax.transData.inverted().transform([(bb.x0, bb.y0), (bb.x1, bb.y1)])
        return float(x0), float(y0), float(x1), float(y1)

    boxes = [(artist.get_text(), extent(artist)) for artist in texts]
    closest = (9.0, None)
    for i, (label, (x0, y0, x1, y1)) in enumerate(boxes):
        assert x0 >= .02 and x1 <= W - .02 and y0 >= .02 and y1 <= H - .02, ('outside canvas', label, (x0, y0, x1, y1))
        for other, (p0, q0, p1, q1) in boxes[i + 1:]:
            dx, dy = max(p0 - x1, x0 - p1), max(q0 - y1, y0 - q1)
            assert dx > 0 or dy > 0, ('text overlap', label, other)
            closest = min(closest, (round(max(dx, dy), 4), f'{label} | {other}'))
    assert closest[0] > .02, closest
    for label, (x0, y0, x1, y1) in boxes:                # labels on the left end before the first column
        if x1 < left(0) + .01:
            assert x1 <= left(0) - .10, label
    # The pull-out and its notes stay right of the strip; each letter is centred above its enlarged column.
    assert edge > box_x1 + .2 and zoom_right < W - .5
    centres = {rows[i]['letter']: ZX0 + j * ZPITCH + ZCELL_W / 2 for j, i in enumerate(shown) if rows[i]['letter']}
    for artist in letters:
        x0, _, x1, _ = extent(artist)
        assert abs((x0 + x1) / 2 - centres[artist.get_text()[8]]) < .005, artist.get_text()
    return fig, {'closest_text_gap_cm': closest[0], 'closest_text_pair': closest[1],
                 'enlarged_columns': [{k: rows[i][k] for k in ('N', 'model_id', 'coverage', 'monotonicity', 'final', 'letter')} for i in shown]}


def main():
    for folder in ['figures', 'qa']:
        (ROOT / folder).mkdir(parents=True, exist_ok=True)
    d = checked_records()
    rows, large, reachable = models(d)
    plt.rcParams.update({
        'font.family': 'serif', 'font.serif': ['Computer Modern Roman'], 'font.size': LABEL,
        'text.usetex': True, 'pdf.fonttype': 42, 'svg.fonttype': 'none',
        'text.latex.preamble': r'\usepackage{fix-cm,amsmath,amssymb}'
                               r'\DeclareMathSizes{8}{8}{7.2}{7.2}\DeclareMathSizes{9}{9}{7.2}{7.2}',
    })
    fig, layout = draw(rows, large, reachable)
    pdf = ROOT / 'figures' / f'{NAME}.pdf'
    fig.savefig(pdf, facecolor='white')
    fig.savefig(pdf.with_suffix('.svg'), facecolor='white')
    fig.savefig(pdf.with_suffix('.png'), dpi=300, facecolor='white')
    plt.close(fig)
    with pymupdf.open(pdf) as doc:
        page = doc[0]
        spans = [s for block in page.get_text('dict')['blocks']
                 for line in block.get('lines', []) for s in line['spans']]
        smallest = min(s['size'] for s in spans)
        assert smallest >= 7 and not page.get_images()
        assert abs(page.rect.width / 72 * 2.54 - W) < .002 and abs(page.rect.height / 72 * 2.54 - H) < .002
        page.get_pixmap(dpi=300, colorspace=pymupdf.csGRAY).save(ROOT / 'qa' / f'{NAME}.grayscale.png')
        size = [round(page.rect.width / 72 * 2.54, 3), round(page.rect.height / 72 * 2.54, 3)]
    witnesses = {m['letter']: {'N': m['N'], 'model_id': m['model_id'], 'accuracy': m['accuracy'],
                               'printed_accuracy': f"{m['accuracy']:.1f}", 'final_invariant': m['invariant'], 'accepted': m['final']}
                 for m in rows if m['letter']}
    report = {
        'size_cm': size, 'minimum_actual_glyph_pt': smallest, **layout,
        'models': len(rows), 'larger_grid': large, 'reachable_range': reachable, 'witnesses': witnesses,
        'pass_counts': {key: sum(m[key] for m in rows) for key in ('coverage', 'monotonicity', 'final')},
        'both_global_laws': sum(m['coverage'] and m['monotonicity'] for m in rows),
        'accuracy_range': [min(m['accuracy'] for m in rows), max(m['accuracy'] for m in rows)],
        'order': 'held-out exact match ascending; ties by grid N, then model id',
        'tied_accuracies': len(rows) - len({m['accuracy'] for m in rows}),
        'columns': [{k: m[k] for k in ('N', 'model_id', 'accuracy', 'coverage', 'monotonicity', 'final', 'letter')}
                    for m in rows],
        'colours': {'holds_or_sound': DEEP_GREEN, 'violated_or_unsound': PURPLE},
        'matplotlib': matplotlib.__version__,
    }
    (ROOT / 'qa' / 'figure_3.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ('size_cm', 'minimum_actual_glyph_pt', 'closest_text_gap_cm', 'closest_text_pair',
                                              'models', 'pass_counts', 'both_global_laws', 'witnesses', 'enlarged_columns')}, indent=1))


if __name__ == '__main__':
    main()
