# Figure 2 restored, Figure 3 as an accuracy profile (2026-10-11)

> **Update, later on 2026-10-11.** `recolor_figure2.py` was edited in place: the check elements of Figure 2 are now the dark blue `#465A73` instead of purple, so the statements below about purple in Figure 2 no longer hold. The earlier script and exports are in
> `../provenance/figures_round4_20261011/before/`; see `../figures_round4_20261011/README.md`.

> **Update, 2026-10-12.** `render_figure3.py` was edited in place: in Figure 3 the letters b and a now stand above the frame, bold 10 pt, each with a leader to the centre of its column, and the scale labels 95%, 75%, 50% moved 1.3 mm right and 1.0 mm down. Size and data are unchanged. The earlier script and exports are in `../provenance/writing_revision20_20261012/before/figure3/`; see `../writing_revision20_20261012/README.md`.

> **Update, later on 2026-10-12.** `render_figure3.py` was rewritten in place after a sketch of the user: accuracy is a curve over dotted guides labelled on the left; the six most accurate columns are boxed and repeated enlarged on the right, with the letters b and a above them; a short note gives the two witnesses' accuracy and final invariant. The statements below about the accuracy area, the frame and the letters no longer hold. Size (12.2 × 4.2 cm), data, and the green and purple are unchanged. The earlier script and exports are in `../provenance/writing_revision23_20261012/before/figure3/`; see `../writing_revision23_20261012/README.md`.

Previews: [Figure 2](figures/figure_2.png) · [Figure 3](figures/figure_3.png)

Two requests from the user, carried out by Claude Code (Anthropic, Claude Opus 5.5):
put Figure 2 back to its previous version, and replace Figure 3 with the design of a
sketch the user supplied. Figures 1 and 4 are unchanged and still come from
`../figures_unified_20261011/`. Earlier folders and PDFs are unchanged.

## Figure 2

`recolor_figure2.py` produces the previous design again: the user's PDF with its blue
drawn in purple (checkpoints, route cards, stems) and its green kept green. The iteration
band and the outlined lower glyph are as supplied. The script checks that every shape and
text span matches the previous version of the figure, colour values aside.

One difference from that version: purple and green take the paper's current palette
values (`#6B4A99`, `#429466`) instead of the earlier ones (`#7D5BA6`, `#5BAA7C`), so that
they stay identical to Figures 1, 3 and 4. The caption is not changed; it keeps the two
sentences the user supplied, which also describe this version.

Purple therefore has two meanings again: omission or unsoundness in Figures 1 and 3, and
checkpoints in Figure 2.

## Figure 3

`render_figure3.py` follows the sketch: one column per trained model, sorted by held-out
exact match; the accuracy as a filled curve with the 95 % line; three rows of cells for
coverage, monotonicity and the final invariant; a row marking the models of the `N = 50`
grid; a frame around the two models of Figure 1, labelled b and a.

Drawn for the paper it differs from the sketch in these ways:

- white background, the paper's type and palette (deep green pass or sound, purple fail
  or unsound, light gray for the accuracy fill);
- dotted guides at 50 % and 75 %, and the caption states that the accuracy scale runs
  from 40 % to 100 %, because the filled area does not start at zero;
- models of the `N = 30` grid get a light-gray tick in the last row, so the columns stay
  aligned.

Order: held-out exact match ascending. 27 of the 65 values are tied with another; ties
are ordered by grid, then model id, so neighbouring columns with equal accuracy may sit
in a different order than in the sketch.

The data are the 65 original models of the checked records in
`../figure_final_20261008/artifact/data`, read through that round's checks. The script
also asserts what the text says about the figure: 9 sound finals, 5 models passing both
laws, 20 models of the larger grid, and exactly two models at or above 95 %, both of the
larger grid, neither passing a global law, b sound and a unsound. Counts drawn: coverage
5 pass, monotonicity 6 pass, final invariant 9 sound.

What this figure no longer shows: the earlier scatter plotted how many omission inputs
and how many monotonicity-violating pairs each model has. The profile shows only pass or
fail.

Size 12.2 × 4.2 cm (the scatter was 6.7 cm high); smallest glyph 7.97 pt; glyph-size and
collision audits pass. `caption_figure3.tex` is a new caption for it.

## Palette

Unchanged from `../figures_unified_20261011/palette.py`, which all scripts here import.
`build_paper.py` again reads every colour from the four figure PDFs in use and confirms
that each palette value is identical wherever it appears: deep green `#429466` in Figures
1–4, purple `#6B4A99` in Figures 1–3, light gray `#DDDEE1` in Figures 1 and 3, pale green
`#9AD4B3` in Figure 1, mechanism gray `#555555` in Figures 1 and 2.

## Rebuild

From the manuscript directory:

```powershell
python -X utf8 -B figures_round3_20261011/recolor_figure2.py
python -X utf8 -B figures_round3_20261011/render_figure3.py
python -X utf8 -B figures_round3_20261011/build_paper.py
```

All three were run. The last writes `../paper_figure3_profile.pdf` and receipts in
`../provenance/figures_round3_20261011/`.

## State of the manuscript

`../paper_figure3_profile.pdf`: Figures 1–4 on pages 2, 5, 6 and 13; 9 main pages, 1
data-statement page, 1 reference page and 4 appendix pages, 15 in total. No overfull or
underfull boxes, no undefined references, fonts embedded. The last main page has 29
lines (33 before). The main text is still one page over the 8-page target. Figure 2's
type at text width is unchanged (6.0–6.7 pt, subscripts 4.5 pt).

Three source lines changed: the Figure 2 path in `../sections/02_contracts.tex`, and the
Figure 3 path and caption input in `../sections/03_evidence.tex`. Pre-edit copies are in
`../provenance/figures_round3_20261011/before/`.

Not done: no source ZIP was packaged and nothing was committed to Git.
