"""Numbers and the table of the second loop, from the saved results of experiments/step2_loop_20261011.

Run from any directory: python -B path/to/scripts/generate_loop2.py
Reads results only; no training and no change to any record. Writes
generated/loop2_numbers.tex (macros used through \\loopval), generated/loop2.tex
(rows of Table tab:loop2), generated/loop2_cohort.tex (the second loop's row of
Table tab:cohorts) and generated/loop2_values.json (raw values and the hashes of
the files read). Every statement the paper makes about the second loop
is asserted here, so a result that contradicts the text stops the build.
"""
from pathlib import Path
import argparse
import hashlib
import json
import statistics

OUT = Path(__file__).resolve().parents[1]
EXP = OUT.parents[1] / 'experiments' / 'step2_loop_20261011'
SOURCES = {}
VALUES = {}
PCT = '.1f'


def half_up(x):
    """Nearest integer, halves rounded up (2026-10-14, omission share)."""
    return int(x + 0.5)


def read(path):
    SOURCES['experiments/step2_loop_20261011/' + path.relative_to(EXP).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text(encoding='utf-8'))


def val(key, raw, latex=None):
    VALUES[key] = {'raw': raw, 'latex': str(raw) if latex is None else latex}


def pct(rate):
    return format(100 * rate, PCT)


def interval(v):
    return f'[{v[0]},{v[1]}]'


def main():
    global EXP, OUT
    parser = argparse.ArgumentParser()                   # the defaults are the repository layout; a package may differ
    parser.add_argument('--experiment', default=str(EXP), help='the step2_loop_20261011 directory')
    parser.add_argument('--out', default=None, help='directory for the three output files; default is generated/ of the paper')
    args = parser.parse_args()
    EXP = Path(args.experiment).resolve()
    target = OUT / 'generated' if args.out is None else Path(args.out).resolve()
    target.mkdir(parents=True, exist_ok=True)
    summary = read(EXP / 'results/evaluation/summary.json')
    models = read(EXP / 'results/evaluation/models.json')
    truth = read(EXP / 'results/grid/truth.json')
    tests = read(EXP / 'results/unit_tests.json')
    lock = read(EXP / 'plan_lock.json')
    record = read(EXP / 'results/grid/execution_record.json')
    n, k = truth['N'], truth['K']
    rate = lambda m: m['accuracy']['test']['exact_rate']
    count = lambda m: m['accuracy']['test']['exact_count']
    # Omission share (2026-10-14): omission inputs as a percentage of inexact inputs.
    share = lambda m: 100 * m['omission_inputs'] / (len(truth['inputs']) - m['accuracy']['full_domain']['exact_count'])

    # The grid, the loop, and the order of plan and training.
    assert truth['step'] == 2 and summary['grid_complete'] and len(models) == summary['models'] == 45
    assert lock['locked_at'] < record['started_at'], 'The analysis plan must precede training'
    val('N', n); val('K', k); val('Models', len(models))
    # Exact joined iteration ends in [0, K + 1]; sound means containing [0, K]; among sound intervals only [0, K] is rejected.
    checks = tests['tests']
    assert tests['all_passed'] and (tests['N'], tests['K'], tests['step']) == (n, k, 2)
    exact_final = checks['P1_exact_joined_iteration_ends_in_0_K_plus_1']['final']
    assert exact_final == [0, k + 1] == summary['expected_envelope_final']
    assert checks['C3_reachable_set']['least_interval_containing_it'] == [0, k]
    assert checks['P2_sound_interval_0_K_is_rejected']['passed'] and not checks['P2_sound_interval_0_K_is_rejected']['accepted']
    assert sorted(map(int, checks['P3_intervals_0_u_accepted_for_u_at_least_K_plus_1']['accepted_by_u'])) == list(range(k + 1, n + 1))
    assert all(checks['P3_intervals_0_u_accepted_for_u_at_least_K_plus_1']['accepted_by_u'].values())
    val('ExactFinal', exact_final, interval(exact_final)); val('RejectedSound', [0, k], interval([0, k]))
    # Why the sound [0, K] is rejected: the unreachable value K - 1 lies in it and passes the guard, and its successor K + 1 does not.
    assert k - 1 not in checks['C3_reachable_set']['reachable'] and k - 1 < k and (k - 1) + truth['step'] == k + 1 == exact_final[1]
    val('UnreachableInside', k - 1); val('ItsSuccessor', k + 1)

    # Outcomes: every sound result is accepted, none is sound but rejected.
    sound = [m for m in models if m['sound']]
    unsound = [m for m in models if not m['sound']]
    assert all(m['accepted'] for m in sound) and not any(m['accepted'] for m in unsound)
    assert summary['totals']['sound_rejected'] == 0 and all(m['final_invariant'] == exact_final for m in sound)
    val('Sound', len(sound)); val('Unsound', len(unsound))
    val('SoundWithViolation', sum(not m['global_pass'] for m in sound))
    val('SoundMin', min(map(rate, sound)), pct(min(map(rate, sound)))); val('SoundMax', max(map(rate, sound)), pct(max(map(rate, sound))))
    val('UnsoundMin', min(map(rate, unsound)), pct(min(map(rate, unsound)))); val('UnsoundMax', max(map(rate, unsound)), pct(max(map(rate, unsound))))
    val('CoveragePass', sum(m['coverage_pass'] for m in models)); val('GlobalPass', sum(m['global_pass'] for m in models))

    # "The three most accurate models violate both global laws yet reach the sound invariant."
    ranked = sorted(models, key=lambda m: -count(m))
    top = [m for m in ranked if count(m) >= count(ranked[2])]
    assert len(top) == 3, 'A tie at third place: the text says three'
    assert all(m['omission_inputs'] > 0 and m['monotonicity_violations'] > 0 and m['final_invariant'] == exact_final for m in top)
    val('TopMin', min(map(rate, top)), pct(min(map(rate, top)))); val('TopMax', max(map(rate, top)), pct(max(map(rate, top))))
    assert VALUES['TopMax']['latex'] == VALUES['SoundMax']['latex']
    # "The two models with a global pass are the least accurate."
    passing = [m for m in models if m['global_pass']]
    assert len(passing) == 2 and max(map(count, passing)) < min(count(m) for m in models if not m['global_pass'])
    assert VALUES['SoundMin']['latex'] == pct(min(map(rate, passing)))

    # "The most accurate unsound model returns I on its training input I, whose exact image is F(I), and stops there."
    worst = [m for m in unsound if count(m) == max(map(count, unsound))]
    assert len(worst) == 1 and worst[0]['model_id'] == 'w32_c50_s2'
    at = worst[0]['at_final']
    assert at['input'] == at['model_output'] == worst[0]['final_invariant'] and at['input_in_training_set'] and at['relation'] == 'omission'
    val('WorstModel', worst[0]['model_id']); val('WorstInput', at['input'], interval(at['input']))
    val('WorstOutput', at['model_output'], interval(at['model_output'])); val('WorstImage', at['exact_output'], interval(at['exact_output']))

    # Omissions on iteration paths: those after which the output still exceeds the current interval do not stop iteration.
    omissions = [e for m in models for e in m['path'] if e['relation'] == 'omission']
    larger = lambda e: e['model_output'][0] <= e['state'][0] and e['model_output'][1] > e['state'][1]
    cont = [e for e in omissions if e['next'] != e['state']]
    assert all(larger(e) for e in cont) and not any(larger(e) for e in omissions if e['next'] == e['state'])
    val('PathOmissions', len(omissions)); val('PathOmissionsContinue', len(cont)); val('PathOmissionsStop', len(omissions) - len(cont))
    assert len(omissions) - len(cont) == len(unsound) and all(m['at_final']['relation'] == 'omission' for m in unsound)
    val('SoundDespitePathOmission', sum(m['path_omissions'] > 0 for m in sound))
    words = ('Zero One Two Three Four Five Six Seven Eight Nine Ten Eleven Twelve Thirteen Fourteen Fifteen Sixteen '
             'Seventeen Eighteen Nineteen Twenty').split()
    val('SoundDespitePathOmissionWord', words[VALUES['SoundDespitePathOmission']['raw']])   # the count spelled out, to start a sentence
    # "Sound and unsound results again overlap in accuracy."
    assert min(map(rate, unsound)) < max(map(rate, sound)) and min(map(rate, sound)) < max(map(rate, unsound))

    # "Every model outputs [0, K + 1] on [0, K], so no run stops at [0, K], and every envelope reaches [0, K + 1]."
    at_k = truth['inputs'].index([0, k])
    assert truth['outputs'][at_k] == exact_final
    for m in models:
        table = read(EXP / 'results/grid/A' / m['model_id'] / 'result.json')['predictions']
        assert table[at_k] == exact_final, m['model_id']
        assert m['envelope']['final'] == exact_final and m['final_invariant'] != [0, k]
    assert summary['envelope']['equal_to_expected'] == len(models)

    # Table: one row per configuration, then all models.
    def row(label, rows):
        rates = sorted(map(rate, rows))
        return [*label, pct(statistics.median(rates)), f'{pct(rates[0])}--{pct(rates[-1])}', half_up(statistics.median(map(share, rows))),
                f"{sum(m['coverage_pass'] for m in rows)}/{len(rows)}", f"{sum(m['global_pass'] for m in rows)}/{len(rows)}",
                sum(m['sound'] for m in rows), sum(not m['sound'] for m in rows)]
    table = []
    for width in sorted({m['width'] for m in models}):
        for coverage in sorted({m['coverage'] for m in models}):
            rows = [m for m in models if (m['width'], m['coverage']) == (width, coverage)]
            assert len(rows) == 5
            table.append(row([width, int(round(100 * coverage))], rows))
    total = row(['All', ''], models)
    lines = [' & '.join(map(str, r)) + r' \\' for r in table] + [r'\midrule', ' & '.join(map(str, total)) + r' \\']
    (target / 'loop2.tex').write_text('\n'.join(lines) + '\n', encoding='utf-8', newline='\n')
    macros = ['% Generated from experiments/step2_loop_20261011 by scripts/generate_loop2.py.']
    macros += [r'\expandafter\def\csname Loop%s\endcsname{%s}' % (key, value['latex']) for key, value in VALUES.items()]
    (target / 'loop2_numbers.tex').write_text('\n'.join(macros) + '\n', encoding='utf-8', newline='\n')
    # The second loop's row of the main text's cohort table (tab:cohorts): N, cohort, count, coverage pass, global pass,
    # accept, accepted with violation. Every sound result is accepted, so the accept count is the number of sound results.
    accepted = sum(m['accepted'] for m in models)
    cohort = [n, 'Trained, second loop', len(models), total[5], total[6], f'{accepted}/{len(models)}',
              sum(m['accepted'] and not m['global_pass'] for m in models)]
    assert accepted == len(sound) == total[7] and cohort[6] == VALUES['SoundWithViolation']['raw']
    (target / 'loop2_cohort.tex').write_text(' & '.join(map(str, cohort)) + r' \\' + '\n', encoding='utf-8', newline='\n')
    (target / 'loop2_values.json').write_text(json.dumps({'values': VALUES, 'table': table + [total], 'cohort_row': cohort, 'sources': SOURCES},
                                                              indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({key: value['latex'] for key, value in VALUES.items()}, ensure_ascii=False))
    print('\n'.join(lines))
    print(' & '.join(map(str, cohort)))
    print('files read:', len(SOURCES))


if __name__ == '__main__':
    main()
