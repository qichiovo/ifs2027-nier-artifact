"""Numbers of the mechanism analysis of Section 3, from experiments/section3_mechanisms_20261014/results.

Run from any directory: python -B path/to/scripts/generate_mechanisms.py
Reads result files only. Writes generated/mechanism_numbers.tex (macros used through
\\mechval) and generated/mechanism_values.json (raw values and hashes of the files read).
Every statement the paper makes with these numbers is asserted here, so a result that
contradicts the text stops the build.
"""
from pathlib import Path
import csv
import hashlib
import io
import json
import statistics

OUT = Path(__file__).resolve().parents[1]
RES = OUT.parents[1] / 'experiments' / 'section3_mechanisms_20261014' / 'results'
SOURCES, VALUES = {}, {}
WORDS = 'zero one two three four five six seven eight nine ten eleven twelve'.split()


def read_bytes(path):
    data = path.read_bytes()
    SOURCES[path.relative_to(OUT.parents[1]).as_posix()] = hashlib.sha256(data).hexdigest()
    return data


def read(path):
    return json.loads(read_bytes(path).decode('utf-8'))


def val(key, raw, latex=None):
    VALUES[key] = {'raw': raw, 'latex': str(raw) if latex is None else latex}


def word(key, n, cap=False):
    w = WORDS[n]
    val(key, n, w.capitalize() if cap else w)


def half_up(x):
    return int(x + 0.5)


def main():
    item1 = read(RES / 'item1_path_omissions.json')
    item2 = read(RES / 'item2_summary.json')
    item3 = read(RES / 'item3_retraining.json')
    extras = read(RES / 'extras.json')
    shuffle = read(RES / 'shuffle' / 'summary.json')
    models = list(csv.DictReader(io.StringIO(read_bytes(RES / 'item1_item2_models.csv').decode('utf-8'))))
    values = read(OUT / 'generated' / 'values.json')
    loop2 = read(OUT / 'generated' / 'loop2_values.json')['values']
    D = lambda k: values[k]['raw']
    L = lambda k: loop2[k]['raw']
    truthy = lambda s: s == 'True'
    s1, s2, f = item1['summary'], item2['by_setting'], extras['facts']

    # Appendix B: lower bounds 0, upper bounds at most the largest label, short paths.
    assert all(f[n]['non_bottom_outputs_with_lower_endpoint_not_0'] == 0 for n in ('N30', 'N50', 'loop2'))
    assert f['N30']['max_upper_endpoint'] == f['N30']['K'] and f['N50']['max_upper_endpoint'] == f['N50']['K']
    assert f['loop2']['max_upper_endpoint'] == f['loop2']['max_F_upper_endpoint']
    assert s1['N30']['path_length']['median'] == s1['N50']['path_length']['median']
    word('PathMedianMainWord', int(s1['N30']['path_length']['median']))
    word('PathMedianLoopWord', int(s1['loop2']['path_length']['median']))
    assert all(s1[n]['path_fraction']['median'] < 0.01 for n in ('N30', 'N50', 'loop2'))           # "under 1% of the domain"
    # Main loop: every path omission stops iteration, and only path omissions make results unsound.
    for n in ('N30', 'N50'):
        assert s1[n]['blocking'] == s1[n]['path_omissions'] and s1[n]['models_with_path_omission_and_sound_result'] == 0
        assert s1[n]['unsound_models_without_path_omission'] == 0
        for u in s2[n]['unsound_models']:                       # stops at [0,u] mapped to itself, one short of F
            lo, hi = map(int, u['state'].strip('[]').split(','))
            assert lo == 0 and u['output'] == [lo, hi] and u['exact'][1] - u['output'][1] == 1
    for key, n in (('Core', 'N30'), ('Confirm', 'N50'), ('Loop', 'loop2')):
        val('StopTraining' + key, sum(u['in_training'] for u in s2[n]['unsound_models']))
        val('Unsound' + key, len(s2[n]['unsound_models']))
    assert VALUES['UnsoundLoop']['raw'] == L('Unsound')
    assert 2 * VALUES['StopTrainingCore']['raw'] > VALUES['UnsoundCore']['raw']                 # "more than half"
    # Appendix D: path omissions on the second loop, by shortfall.
    loop_path = [c for m in item1['per_model'] if m['setting'] == 'loop2' for c in m['path_omission_list']]
    blocking = [c['exact'][1] - c['output'][1] for c in loop_path if c['kind'] == 'blocks']
    passing = [c['exact'][1] - c['output'][1] for c in loop_path if c['kind'] != 'blocks']
    assert len(loop_path) == L('PathOmissions') and len(passing) == L('PathOmissionsContinue') and len(blocking) == L('PathOmissionsStop')
    assert set(passing) == {1} and min(blocking) >= 2
    word('LoopStopShortMinWord', min(blocking)); word('LoopStopShortMaxWord', max(blocking))
    assert set(blocking) == set(range(min(blocking), max(blocking) + 1))                       # "two or three short"

    # Section 3: the eleven models accepted despite a law violation.
    final_path = {}
    for r in item3['rounds']:
        final_path[(r['setting'], r['model_id'])] = r['omissions_on_own_path']                 # the last round wins
    violators = []
    for m in models:
        if m['setting'] in ('N30', 'N50') and truthy(m['accepted']) and not truthy(m['global_pass']):
            violators.append((int(m['omission_inputs']), int(m['path_omissions'])))
    for r in item3['runs']:
        if r['after']['accepted'] and not r['after']['global_pass']:
            violators.append((r['after']['omissions'], final_path[(r['setting'], r['model_id'])]))
    assert len(violators) == D('AcceptedLawBad')
    assert all(p == 0 for _, p in violators)
    word('AcceptedViolationOffPathWord', sum(o > 0 for o, _ in violators))
    word('AcceptedViolationMonoOnlyWord', sum(o == 0 for o, _ in violators))

    # Section 3: closer fits. The 30 primary-grid models at 50% and 80% coverage.
    high = [m for m in models if m['setting'] == 'N30' and m['coverage'] in ('50', '80')]
    short = {(x['model_id']): x for x in extras['shortfall_on_exact_path'] if x['setting'] == 'N30'}
    assert all(short[m['model_id']]['first_short_by'] == 1 for m in high) and not any(truthy(m['accepted']) for m in high)
    val('HighCoverageModels', len(high))
    accepted = [m for m in models if m['setting'] == 'N30' and truthy(m['accepted'])]
    constant = [m for m in accepted if m['distinct_outputs'] == '1' and float(m['outputs_equal_0K_share']) == 1.0]
    assert len(accepted) == D('CoreAccept')
    word('ConstantAcceptedWordCap', len(constant), cap=True); word('CoreAcceptedWord', len(accepted))
    lawful_main = [m for m in models if m['setting'] in ('N30', 'N50') and truthy(m['global_pass'])]
    assert sorted(m['model_id'] for m in lawful_main) == sorted(m['model_id'] for m in constant)   # the only lawful ones
    lawful_loop = s2['loop2']['lawful_models']
    assert len(lawful_loop) == L('GlobalPass') and all(x['most_common_output_share'] >= 0.99 for x in lawful_loop)
    word('LoopLawfulWord', len(lawful_loop))

    # Section 3 and Appendix A: the eight newly accepted models.
    flips = [r['rejected_to_accepted'] for r in item3['runs'] if 'rejected_to_accepted' in r]
    assert len(flips) == D('RepairAccept') - D('MatchedAccept')
    assert all(x['stop_before_relation_after'] != 'omission' for x in flips)                  # each repairs its old stop
    never_added = [x for x in flips if x['stop_before_added_in_round'] is None]
    assert all(x['stop_before_in_original_training'] for x in never_added)
    word('FlipsWord', len(flips)); word('FlipStopInTrainingWord', len(never_added))
    extend = sum(x['path_after_extends_path_before'] for x in flips)
    word('FlipExtendWordCap', extend, cap=True); word('FlipDepartWord', len(flips) - extend)
    val('FlipPathRepairedMax', max(x['omissions_fixed_on_path_after'] for x in flips))
    val('FlipRepairedMin', min(x['omissions_fixed_total'] for x in flips))
    val('FlipRepairedMax', max(x['omissions_fixed_total'] for x in flips))
    # New omissions and new monotonicity violations.
    t = item3['totals']
    new = t['new_omissions']
    assert 2 * (new['in_added'] + new['next_to_added']) > new['count'] and 2 * new['were_wider_before'] > new['count']
    val('NewOmissions', new['count']); val('NewOmissionsAdded', new['in_added'])
    val('NewOmissionsNext', new['next_to_added']); val('NewOmissionsWider', new['were_wider_before'])
    pairs = t['new_monotonicity_pairs']
    val('NewPairs', pairs['count'])
    share = 100 * pairs['touching_added'] / pairs['count']
    assert abs(share - round(share) - 0.5) > 1e-6 and abs(share - round(share) + 0.5) > 1e-6
    val('NewPairsAddedPercent', half_up(share))
    # Runs that end with a law violation, and how many violating inputs outside the training data they keep.
    failing = [r for r in item3['runs'] if not r['after']['global_pass']]
    threshold = 6
    few = [r for r in failing if r['end_state']['fresh_candidates_last'] <= threshold]
    assert len(failing) == D('RepairCount') - D('RepairLawful') and 2 * len(few) > len(failing)   # "most"
    val('FailingRuns', len(failing)); val('FewFresh', len(few)); word('FreshThresholdWord', threshold)
    # Shuffled counterexample order.
    rows = shuffle['by_variant_and_seed']
    original = [x for x in rows if x['variant'] == 'original']
    others = [x for x in rows if x['variant'] != 'original']
    assert len(original) == 1 and original[0]['accepted'] == D('RepairAccept') and original[0]['global_pass'] == D('RepairLawful')
    assert shuffle['original_reproduced']
    seeds = {x['seed'] for x in others}
    assert all({x['seed'] for x in others if x['variant'] == v} == seeds for v in {x['variant'] for x in others})
    word('ShuffleSeedsWord', len(seeds))
    val('ShuffleAcceptMin', min(x['accepted'] for x in others)); val('ShuffleAcceptMax', max(x['accepted'] for x in others))
    val('ShuffleGlobalMin', min(x['global_pass'] for x in others)); val('ShuffleGlobalMax', max(x['global_pass'] for x in others))
    runs = shuffle['accepted_per_run']
    keys = [k for k in runs[0] if k not in ('setting', 'model_id')]
    changing = sum(len({r[k] for k in keys}) > 1 for r in runs)
    assert len(runs) == D('RepairCount')
    assert changing == len(runs) - extras['item5_runs_accepted_in_every_variant'] - extras['item5_runs_rejected_in_every_variant']
    val('ShuffleChanging', changing)

    # Revision v27 (2026-10-14), B3: omission shares of Table 3 quoted in the text, and where models a and b come from.
    shares, heldout = {}, {}
    for m in models:
        key = (m['setting'], m['width'], m['coverage'])
        shares.setdefault(key, []).append(100 * float(m['omission_share_of_inexact_all']))
        heldout.setdefault(key, []).append(float(m['heldout_exact']))
    median_share = {k: half_up(statistics.median(v)) for k, v in shares.items()}
    table3 = [l.rstrip(' \\').split(' & ') for l in read_bytes(OUT / 'generated' / 'configurations.tex').decode('utf-8').splitlines() if '&' in l]
    for n, w, c, *rest in table3:
        assert median_share[('N30' if n == '30' else 'N50', w, c)] == int(rest[2])
    val('ShareCoreLow', median_share[('N30', '16', '20')]); val('ShareCoreHigh', median_share[('N30', '64', '80')])
    confirm = [k for k in median_share if k[0] == 'N50']
    best = max(confirm, key=lambda k: statistics.median(heldout[k]))
    assert best == ('N50', '64', '80') and median_share[best] == min(median_share[k] for k in confirm)   # "its most accurate configuration ... has the lowest share"
    assert {m['model_id'] for m in models if (m['setting'], m['width'], m['coverage']) == best} >= {'w64_c80_s0', 'w64_c80_s1'}   # models b and a
    val('ShareConfirmTop', median_share[best])
    # Revision v27, B4: the second loop's most accurate configuration, all of its models sound, every path omission one short.
    loop = [k for k in heldout if k[0] == 'loop2']
    top = max(loop, key=lambda k: statistics.median(heldout[k]))
    rows = [m for m in models if (m['setting'], m['width'], m['coverage']) == top]
    assert top == ('loop2', '64', '80') and all(m['sound'] == 'True' for m in rows)
    top_paths = [c for m in item1['per_model'] if m['setting'] == 'loop2' and m['model_id'] in {r['model_id'] for r in rows} for c in m['path_omission_list']]
    assert top_paths and all(c['kind'] != 'blocks' and c['exact'][1] - c['output'][1] == 1 for c in top_paths)
    word('LoopTopSoundWord', sum(m['sound'] == 'True' for m in rows)); word('LoopTopModelsWord', len(rows))

    # Final revision (2026-10-14), B2: model a's path and omissions, from the analysis table and the worker's record.
    a = next(m for m in models if (m['setting'], m['model_id']) == ('N50', 'w64_c80_s1'))
    record = json.loads(read_bytes(OUT.parents[1] / 'experiments' / 'learned_admission' / 'confirmation_n50' / 'results' / 'A' / 'w64_c80_s1' / 'result.json').decode('utf-8'))
    trace = [t['state'] for t in record['joined']['trace']]
    high_final = [int(x) for x in values['HighFinal']['latex'].strip('[]').split(',')]
    assert trace[:3] == [None, [0, 0], [0, 2]] and trace[-1] == high_final and len(trace) == int(a['path_length'])
    assert int(a['omission_inputs']) == D('HighOmissions') and int(a['path_omissions']) == 1 and a['sound'] == 'False'   # it ends at an omission
    val('HighPathInputs', len(trace)); word('HighOmissionsWord', D('HighOmissions'))
    # Final revision, B8: Table 6, the 80%-coverage models of widths 32 and 64 give the most sound results of their width.
    sound_by = {}
    for m in models:
        if m['setting'] == 'loop2':
            sound_by.setdefault((m['width'], m['coverage']), []).append(m['sound'] == 'True')
    seeds = {len(v) for v in sound_by.values()}
    assert len(seeds) == 1
    for width in ('32', '64'):
        counts = {c: sum(sound_by[(width, c)]) for c in ('20', '50', '80')}
        assert counts['80'] > max(counts['20'], counts['50'])
        val(f'LoopW{width}C80Sound', counts['80'])
    table6 = {tuple(r[:2]): int(r[7]) for r in (l.rstrip(' \\').split(' & ') for l in read_bytes(OUT / 'generated' / 'loop2.tex').decode('utf-8').splitlines()) if len(r) > 7 and r[0] != 'All'}
    assert table6[('32', '80')] == VALUES['LoopW32C80Sound']['raw'] and table6[('64', '80')] == VALUES['LoopW64C80Sound']['raw']
    val('SeedsPerConfig', seeds.pop())

    macros = ['% Generated from experiments/section3_mechanisms_20261014/results by scripts/generate_mechanisms.py; do not edit.']
    macros += [r'\expandafter\def\csname Mech%s\endcsname{%s}' % (k, v['latex']) for k, v in VALUES.items()]
    (OUT / 'generated' / 'mechanism_numbers.tex').write_text('\n'.join(macros) + '\n', encoding='utf-8', newline='\n')
    (OUT / 'generated' / 'mechanism_values.json').write_text(json.dumps({'values': VALUES, 'sources': SOURCES}, indent=2, ensure_ascii=False) + '\n',
                                                                encoding='utf-8', newline='\n')
    print(json.dumps({k: v['latex'] for k, v in VALUES.items()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
