"""Step 0 of the analysis: recompute Tables 2, 3 and 6 and the 51 / 30 / 12 of Appendix D from the raw records.

Updated 2026-10-14: Tables 3 and 6 gained the column "Omission share (%)", which is recomputed here as well.

Independent of the paper's generator scripts: every number is recomputed from the
saved predictions with the definitions in common.py, formatted like the generated
TeX rows, and compared with the files the paper inputs. Stops with exit code 1 on
any difference.

Run:  python -X utf8 -B reproduce.py
Writes results/reproduction.json.
"""
from __future__ import annotations
import re
import statistics
import sys
from common import HERE, EXP, Setting, rollout, relations, mono_mask, verdict, write_json

PAPER = EXP.parent / 'revisions' / 'ifs2027_nier_20261007'


def tex_rows(name):
    rows = []
    for line in (PAPER / 'generated' / name).read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if not line or line.startswith('%') or line.startswith('\\midrule'):
            continue
        rows.append([re.sub(r'\s+', ' ', c.strip()) for c in line.rstrip('\\').strip().split('&')])
    return rows


def loopval(key):
    text = (PAPER / 'generated' / 'loop2_numbers.tex').read_text(encoding='utf-8')
    return re.search(r'\\csname Loop' + key + r'\\endcsname\{([^}]*)\}', text).group(1)


def summary(s, record_pred, split=None):
    """Law, iteration and acceptance facts of one table of outputs."""
    rel = relations(record_pred, s.truth)
    run = rollout(s.d, record_pred)
    v = verdict(s, run)
    omissions = int((rel == 2).sum())
    mono = int(mono_mask(s.d, record_pred).sum())
    path_om = [i for i in run['ids'] if rel[i] == 2]
    blocking = [i for i in path_om if i == run['ids'][-1] and run['status'] == 'converged']
    inexact = int((rel != 0).sum())
    return {'coverage_pass': omissions == 0, 'global_pass': omissions == 0 and mono == 0, **v, 'omission_share': 100 * omissions / inexact,
            'path_omissions': len(path_om), 'path_omissions_blocking': len(blocking), 'run': run,
            'test_rate': None if split is None else float((rel[split['test']] == 0).mean())}


def pct(x):
    return f'{100 * x:.1f}'


def share(rows):
    """Omission share column of Tables 3 and 6 (added to the paper on 2026-10-14): median over seeds of 100 x omissions / inexact inputs, halves up."""
    return str(int(statistics.median(r['omission_share'] for r in rows) + 0.5))


def main():
    import numpy as np
    out, problems = {}, []
    models = {}
    for name in ('N30', 'N50', 'loop2'):
        s = Setting(name)
        rows = []
        for folder, r in s.a_records():
            pred = np.array(r['predictions'], dtype=np.int64)
            m = summary(s, pred, r['split'])
            # Cross-check with the worker's own record.
            assert r['soundness_violations'] == int((relations(pred, s.truth) == 2).sum())
            assert r['joined']['final'] == m['final'] and r['joined']['postfixed_exact_F'] == (m['accepted'] if m['converged'] else False)
            assert abs(r['accuracy']['test']['exact_rate'] - m['test_rate']) < 1e-12
            rows.append({**r['job'], **{k: v for k, v in m.items() if k != 'run'}})
        models[name] = rows
        if name != 'loop2':
            after = {}
            for folder, r in s.b_runs():
                pred = np.array(r['predictions'], dtype=np.int64)
                after[r['job']['model_id']] = {k: v for k, v in summary(s, pred).items() if k != 'run'}
            models[name + '_after'] = after

    def frac(rows, key):
        return f"{sum(r[key] for r in rows)}/{len(rows)}"

    # Table 2.
    mine = []
    for name, n in (('N30', '30'), ('N50', '50')):
        rows = models[name]
        mine.append([n, 'Trained', str(len(rows)), frac(rows, 'coverage_pass'), frac(rows, 'global_pass'), frac(rows, 'accepted'),
                     str(sum(r['accepted'] and not r['global_pass'] for r in rows))])
    for name, n in (('N30', '30'), ('N50', '50')):
        after = models[name + '_after']
        before = [r for r in models[name] if r['model_id'] in after]
        aft = [after[r['model_id']] for r in before]
        arrow = lambda key: f"{sum(r[key] for r in before)} $\\to$ {sum(r[key] for r in aft)}"
        mine.append([n, 'Retrained (before $\\to$ after)', str(len(before)), arrow('coverage_pass'), arrow('global_pass'), arrow('accepted'),
                     f"{sum(r['accepted'] and not r['global_pass'] for r in before)} $\\to$ {sum(r['accepted'] and not r['global_pass'] for r in aft)}"])
    rows = models['loop2']
    loop_row = ['30', 'Trained, second loop', str(len(rows)), frac(rows, 'coverage_pass'), frac(rows, 'global_pass'), frac(rows, 'sound'),
                str(sum(r['sound'] and not r['global_pass'] for r in rows))]
    paper_t2 = tex_rows('cohorts_final.tex') + tex_rows('loop2_cohort.tex')
    out['table2'] = {'recomputed': mine + [loop_row], 'paper': paper_t2, 'equal': mine + [loop_row] == paper_t2}

    # Table 3.
    mine = []
    for name, n in (('N30', '30'), ('N50', '50')):
        rows = models[name]
        for w in sorted({r['width'] for r in rows}):
            for c in sorted({r['coverage'] for r in rows}):
                g = [r for r in rows if r['width'] == w and r['coverage'] == c]
                if not g:
                    continue
                rates = [r['test_rate'] for r in g]
                mine.append([n, str(w), str(int(round(c * 100))), pct(statistics.median(rates)), f"{pct(min(rates))}--{pct(max(rates))}", share(g),
                             frac(g, 'global_pass'), frac(g, 'accepted')])
    paper_t3 = tex_rows('configurations.tex')
    out['table3'] = {'recomputed': mine, 'paper': paper_t3, 'equal': mine == paper_t3}

    # Table 6.
    rows = models['loop2']
    mine = []
    for w in sorted({r['width'] for r in rows}):
        for c in sorted({r['coverage'] for r in rows}):
            g = [r for r in rows if r['width'] == w and r['coverage'] == c]
            rates = [r['test_rate'] for r in g]
            mine.append([str(w), str(int(round(c * 100))), pct(statistics.median(rates)), f"{pct(min(rates))}--{pct(max(rates))}", share(g),
                         frac(g, 'coverage_pass'), frac(g, 'global_pass'), str(sum(r['sound'] for r in g)), str(sum(not r['sound'] for r in g))])
    rates = [r['test_rate'] for r in rows]
    mine.append(['All', '', pct(statistics.median(rates)), f"{pct(min(rates))}--{pct(max(rates))}", share(rows), frac(rows, 'coverage_pass'), frac(rows, 'global_pass'),
                 str(sum(r['sound'] for r in rows)), str(sum(not r['sound'] for r in rows))])
    paper_t6 = tex_rows('loop2.tex')
    out['table6'] = {'recomputed': mine, 'paper': paper_t6, 'equal': mine == paper_t6}

    # Appendix D: 51 / 30 (/ 21) / 12.
    total = sum(r['path_omissions'] for r in rows)
    blocking = sum(r['path_omissions_blocking'] for r in rows)
    sound_despite = sum(r['sound'] and r['path_omissions'] > 0 for r in rows)
    mine = {'PathOmissions': total, 'PathOmissionsContinue': total - blocking, 'PathOmissionsStop': blocking,
            'SoundDespitePathOmission': sound_despite}
    paper = {k: int(loopval(k)) for k in mine}
    out['appendix_d'] = {'recomputed': mine, 'paper': paper, 'equal': mine == paper}

    out['all_equal'] = all(out[k]['equal'] for k in ('table2', 'table3', 'table6', 'appendix_d'))
    write_json(HERE / 'results' / 'reproduction.json', out)
    for key in ('table2', 'table3', 'table6', 'appendix_d'):
        print(key, 'equal' if out[key]['equal'] else 'DIFFERENT')
        if not out[key]['equal']:
            problems.append(key)
            print('  recomputed:', out[key]['recomputed'])
            print('  paper:     ', out[key]['paper'])
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main())
