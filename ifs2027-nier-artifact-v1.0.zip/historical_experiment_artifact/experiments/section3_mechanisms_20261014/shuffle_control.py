"""Item 5: the 20 retraining runs again, with the counterexample order shuffled.

Everything else is the original code path: learned_admission/worker.py's repair_job,
the locked configuration of each grid, the original trained checkpoints, the same
seeds. Only worker.choose_counterexamples is replaced for the duration of a run.

  original      the unmodified selector; must reproduce every recorded final model
  within_kind   omission inputs in random order, then violating pairs in random order
                (omissions still come before pairs, as in the original rule)
  all_mixed     omission inputs and violating pairs in one random order

The cap of 64 new inputs per round and the rule that both members of a pair must fit
are unchanged. Shuffle seeds 0, 1, 2; each run draws from its own generator, seeded
with the variant, the shuffle seed and the model id.

Run:  python -X utf8 -B shuffle_control.py
Writes results/shuffle/summary.json and results/shuffle/runs.csv; checkpoints of the
reruns stay under results/shuffle/runs/ (not for Git).
"""
from __future__ import annotations
import csv
import random
import shutil
import sys
import time
import numpy as np
from common import HERE, Setting, rollout, verdict, relations, mono_mask, read_json, write_json
import core
import worker

OUT = HERE / 'results' / 'shuffle'
SEEDS = (0, 1, 2)


def selector(mode, rng):
    def choose(report, d, existing, cap):
        omissions = list(report['soundness_ids'])
        pairs = list(report['monotonicity_pair_indices'])
        if mode == 'within_kind':
            rng.shuffle(omissions)
            rng.shuffle(pairs)
            units = [('s', i) for i in omissions] + [('m', q) for q in pairs]
        else:
            units = [('s', i) for i in omissions] + [('m', q) for q in pairs]
            rng.shuffle(units)
        added, selected, sources = [], set(existing), []
        for kind, x in units:                       # same filling rule as core.choose_counterexamples
            if kind == 's':
                if x not in selected and len(added) < cap:
                    selected.add(x)
                    added.append(x)
                    sources.append({'kind': 'soundness', 'ids': [x]})
            else:
                pair = [int(d.left[x]), int(d.right[x])]
                fresh = [i for i in pair if i not in selected]
                if fresh and len(added) + len(fresh) <= cap:
                    added.extend(fresh)
                    selected.update(fresh)
                    sources.append({'kind': 'monotonicity', 'ids': pair})
        return added, sources
    return choose


def run_all(variant, seed, settings):
    rows = []
    original_chooser = core.choose_counterexamples
    for name, s in settings.items():
        for folder, recorded in s.b_runs():
            job = read_json(folder / 'job.json')
            out = OUT / 'runs' / variant / f'seed_{seed}' / name / job['model_id']
            if out.exists():
                shutil.rmtree(out)
            out.mkdir(parents=True)
            worker.choose_counterexamples = original_chooser if variant == 'original' else \
                selector(variant, random.Random(f'{variant}-{seed}-{name}-{job["model_id"]}'))
            try:
                worker.seed_all(job['seed'])
                start = time.perf_counter()
                report = worker.repair_job(job, s.cfg, s.root, out)
                seconds = time.perf_counter() - start
            finally:
                worker.choose_counterexamples = original_chooser
            pred = np.array(report['predictions'], dtype=np.int64)
            v = verdict(s, rollout(s.d, pred))
            omissions = int((relations(pred, s.truth) == 2).sum())
            mono = int(mono_mask(s.d, pred).sum())
            rows.append({'variant': variant, 'seed': seed, 'setting': name, 'model_id': job['model_id'], 'rounds': len(report['rounds']),
                         'stop_reason': report['stop_reason'], 'accepted': v['accepted'], 'sound': v['sound'], 'final': v['final'],
                         'global_pass': omissions == 0 and mono == 0, 'omissions': omissions, 'monotonicity_violations': mono,
                         'same_final_model_as_recorded': pred.tolist() == recorded['predictions'],
                         'added_total': sum(r['added_n'] for r in report['rounds']), 'seconds': seconds})
    return rows


def main():
    settings = {name: Setting(name) for name in ('N30', 'N50')}
    OUT.mkdir(parents=True, exist_ok=True)
    rows = run_all('original', 0, settings)
    reproduced = all(r['same_final_model_as_recorded'] for r in rows)
    print('original order reproduces all recorded final models:', reproduced,
          '| accepted', sum(r['accepted'] for r in rows), '| global pass', sum(r['global_pass'] for r in rows))
    if not reproduced:
        write_json(OUT / 'summary.json', {'original_reproduced': False, 'runs': rows})
        return 1
    for variant in ('within_kind', 'all_mixed'):
        for seed in SEEDS:
            got = run_all(variant, seed, settings)
            rows += got
            print(variant, 'seed', seed, '| accepted', sum(r['accepted'] for r in got), '/20 | global pass', sum(r['global_pass'] for r in got),
                  '/20 | sound', sum(r['sound'] for r in got), '| seconds', round(sum(r['seconds'] for r in got), 1), flush=True)
    summary = {'original_reproduced': True, 'by_variant_and_seed': [
        {'variant': v, 'seed': sd, 'accepted': sum(r['accepted'] for r in rows if r['variant'] == v and r['seed'] == sd),
         'global_pass': sum(r['global_pass'] for r in rows if r['variant'] == v and r['seed'] == sd),
         'sound': sum(r['sound'] for r in rows if r['variant'] == v and r['seed'] == sd),
         'accepted_N30': sum(r['accepted'] for r in rows if r['variant'] == v and r['seed'] == sd and r['setting'] == 'N30'),
         'accepted_N50': sum(r['accepted'] for r in rows if r['variant'] == v and r['seed'] == sd and r['setting'] == 'N50'),
         'seconds': sum(r['seconds'] for r in rows if r['variant'] == v and r['seed'] == sd)}
        for v, sd in [('original', 0)] + [(v, sd) for v in ('within_kind', 'all_mixed') for sd in SEEDS]]}
    per_run = {}
    for r in rows:
        per_run.setdefault((r['setting'], r['model_id']), {})[f"{r['variant']}_{r['seed']}"] = r['accepted']
    summary['accepted_per_run'] = [{'setting': k[0], 'model_id': k[1], **v} for k, v in per_run.items()]
    write_json(OUT / 'summary.json', summary)
    with (OUT / 'runs.csv').open('w', newline='', encoding='utf-8') as stream:
        w = csv.DictWriter(stream, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    return 0


if __name__ == '__main__':
    sys.exit(main())
