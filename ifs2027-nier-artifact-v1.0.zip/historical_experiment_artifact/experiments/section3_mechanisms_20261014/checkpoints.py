"""Step 0b: the records used here are the saved checkpoints' outputs, and the same files as in the package.

1. Every file of historical_experiment_artifact/experiments/{learned_admission,
   step2_loop_20261011} in the reproducibility package is compared with the
   experiment folders read by this analysis: bytes, then line endings, then JSON
   content. The data files read here must agree; metadata files may differ where the
   package replaced machine paths and repository details.
2. Every saved checkpoint (trained models, every retraining round, final retrained
   models) is reloaded and its full-domain outputs are compared with the predictions
   stored in the matching result.json.

Run:  python -X utf8 -B checkpoints.py
Writes results/checkpoints.json.
"""
from __future__ import annotations
import json
import sys
import zipfile
import torch
from common import HERE, EXP, Setting, read_json, write_json
from inference import load_model
from core import model_table

torch.set_num_threads(1)
PACKAGE = EXP.parent / 'revisions' / 'ifs2027_nier_20261007' / 'artifact' / 'nier_full_artifact_20261012.zip'
PREFIX = 'historical_experiment_artifact/experiments/'
# Files this analysis reads. Other files differ only where the package replaced machine paths and repository details.
DATA = ('result.json', 'model.pt', 'truth.json', 'config.lock.json', 'selected_counterexamples.json', 'counterexamples.json', 'references.json')


def main():
    report = {'package': str(PACKAGE.relative_to(EXP.parent))}
    same, endings, formatting, different, missing = 0, [], [], [], []
    with zipfile.ZipFile(PACKAGE) as z:
        for name in z.namelist():
            if not name.startswith(PREFIX) or name.endswith('/'):
                continue
            rel = name[len(PREFIX):]
            if not rel.startswith(('learned_admission/', 'step2_loop_20261011/')):
                continue
            disk = EXP / rel
            if not disk.exists():
                missing.append(rel)
                continue
            packed, local = z.read(name), disk.read_bytes()
            if packed == local:
                same += 1
            elif packed.replace(b'\r\n', b'\n') == local.replace(b'\r\n', b'\n'):
                endings.append(rel)
            elif rel.endswith('.json') and json.loads(packed) == json.loads(local):
                formatting.append(rel)
            else:
                different.append(rel)
    report['package_vs_disk'] = {'identical_bytes': same, 'only_line_endings_differ': len(endings),
                                 'same_json_content_other_formatting': len(formatting),
                                 'data_files_with_different_content': [r for r in different if r.endswith(DATA) or '/splits/' in r],
                                 'metadata_files_with_different_content': [r for r in different if not (r.endswith(DATA) or '/splits/' in r)],
                                 'in_package_not_on_disk': missing}
    checked, mismatched = 0, []
    for name in ('N30', 'N50', 'loop2'):
        s = Setting(name)
        folders = [f for f, _ in s.a_records()]
        for f, _ in s.b_runs():
            folders.append(f)
            folders.extend(sorted(p for p in f.glob('round_*') if (p / 'model.pt').exists()))
        for folder in folders:
            record = read_json(folder / 'result.json')
            table, _, _ = model_table(load_model(folder / 'model.pt'), s.d)
            checked += 1
            if table.tolist() != record['predictions']:
                mismatched.append(str(folder.relative_to(EXP)))
    report['checkpoints'] = {'reloaded': checked, 'outputs_equal_to_record': checked - len(mismatched), 'mismatched': mismatched}
    write_json(HERE / 'results' / 'checkpoints.json', report)
    print({k: (v if isinstance(v, int) else len(v)) for k, v in report['package_vs_disk'].items()})
    print(checked, 'checkpoints reloaded;', len(mismatched), 'with outputs different from the record')
    return 1 if report['package_vs_disk']['data_files_with_different_content'] or mismatched else 0


if __name__ == '__main__':
    sys.exit(main())
