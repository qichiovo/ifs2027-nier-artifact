"""Supplementary counts used in the report: how far short upper endpoints fall, and the facts item 4 relies on.

1. On the exact path (bottom, [0,0], ... up to the exact result), for every trained
   model: inputs whose upper endpoint is short of F's, by shortfall (1 or 2+), and
   for the first such input along the exact path whether joined iteration could
   still move past it (shortfall 1 under step 2), by setting and coverage.
2. Facts item 4 relies on: lower endpoints of all recorded outputs; maximum upper
   endpoints; the second loop's outputs on [0,18] and whether [0,18] is a training
   input; every sound interval accepted in the main loop (checked over the domain).
3. Item 5: per run, agreement of acceptance between the original order and the
   shuffled orders.

Run after mechanisms.py and shuffle_control.py:  python -X utf8 -B extras.py
Writes results/extras.json.
"""
from __future__ import annotations
import numpy as np
from common import HERE, Setting, G, loop_function, read_json, write_json


def main():
    out = {'shortfall_on_exact_path': [], 'facts': {}}
    for name in ('N30', 'N50', 'loop2'):
        s = Setting(name)
        path = np.array(s.exact_path)
        lower_nonzero, max_hi, at_18 = 0, 0, []
        for folder, r in s.a_records():
            pred = np.array(r['predictions'], dtype=np.int64)
            lower_nonzero += int((pred[1:, 0] != 0).sum())          # every non-bottom input
            max_hi = max(max_hi, int(pred[:, 1].max()))
            gap = s.truth[path, 1] - pred[path, 1]
            short = gap > 0
            first = int(np.argmax(short)) if short.any() else None
            out['shortfall_on_exact_path'].append({
                'setting': name, 'model_id': r['job']['model_id'], 'coverage': int(round(r['job']['coverage'] * 100)),
                'short_by_1': int((gap == 1).sum()), 'short_by_2_or_more': int((gap >= 2).sum()),
                'first_short_state': None if first is None else s.exact_path[first],
                'first_short_by': None if first is None else int(gap[first])})
            if name == 'loop2':
                i = s.d.ids[G.Interval(0, 18)]
                at_18.append({'model_id': r['job']['model_id'], 'output': pred[i].tolist(), 'in_training': i in set(r['split']['train'])})
        # Main loop: is every interval that covers [0, K] a post-fixpoint of F?
        sound = [a for a in s.d.states if not a.is_bot and G.leq(G.Interval(0, s.k), a)]
        accepted = [a for a in sound if G.leq(loop_function(a, s.k, s.n, s.step), a)]
        out['facts'][name] = {'non_bottom_outputs_with_lower_endpoint_not_0': lower_nonzero, 'max_upper_endpoint': max_hi,
                              'K': s.k, 'max_F_upper_endpoint': int(s.truth[:, 1].max()),
                              'sound_intervals': len(sound), 'sound_intervals_accepted': len(accepted),
                              'sound_but_rejected': [[a.lo, a.hi] for a in sound if a not in accepted]}
        if at_18:
            out['facts'][name]['outputs_on_0_18'] = {str(o): sum(x['output'] == o for x in at_18) for o in {tuple(x['output']) for x in at_18} for o in [list(o)]}
            out['facts'][name]['0_18_in_training'] = sum(x['in_training'] for x in at_18)
            out['facts'][name]['models'] = len(at_18)
    by = {}
    for x in out['shortfall_on_exact_path']:
        key = f"{x['setting']} c{x['coverage']}"
        b = by.setdefault(key, {'models': 0, 'with_short_input_on_exact_path': 0, 'first_short_by_1': 0, 'first_short_by_2_or_more': 0,
                                'short_by_1_inputs': 0, 'short_by_2_or_more_inputs': 0})
        b['models'] += 1
        b['with_short_input_on_exact_path'] += x['first_short_state'] is not None
        b['first_short_by_1'] += x['first_short_by'] == 1
        b['first_short_by_2_or_more'] += (x['first_short_by'] or 0) >= 2
        b['short_by_1_inputs'] += x['short_by_1']
        b['short_by_2_or_more_inputs'] += x['short_by_2_or_more']
    out['shortfall_by_setting_and_coverage'] = by
    shuffle = read_json(HERE / 'results' / 'shuffle' / 'summary.json')
    keys = [k for k in shuffle['accepted_per_run'][0] if k not in ('setting', 'model_id', 'original_0')]
    out['item5_agreement_with_original'] = {k: sum(r[k] == r['original_0'] for r in shuffle['accepted_per_run']) for k in keys}
    out['item5_runs_accepted_in_every_variant'] = sum(all(r[k] for k in keys + ['original_0']) for r in shuffle['accepted_per_run'])
    out['item5_runs_rejected_in_every_variant'] = sum(not any(r[k] for k in keys + ['original_0']) for r in shuffle['accepted_per_run'])
    write_json(HERE / 'results' / 'extras.json', out)
    for k, v in by.items():
        print(k, v)
    print(out['facts'])
    print('item 5 agreement:', out['item5_agreement_with_original'], 'always accepted', out['item5_runs_accepted_in_every_variant'],
          'never accepted', out['item5_runs_rejected_in_every_variant'])


if __name__ == '__main__':
    main()
