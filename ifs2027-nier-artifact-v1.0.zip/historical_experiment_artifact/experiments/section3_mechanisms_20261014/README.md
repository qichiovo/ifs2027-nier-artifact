# Section 3 mechanism analysis (2026-10-14)

Post-hoc analysis of the saved models and records behind Section 3 of the NIER
manuscript, run by Claude Code (Anthropic, Claude Opus 5.5) on the author's
instruction. No manuscript file and no existing experiment file was changed. Detail
tables (in Chinese) are in `results/tables_zh.md`.

## Inputs (read only)

- `../learned_admission/results/core/` (N = 30) and `../learned_admission/confirmation_n50/results/` (N = 50):
  trained models (`A/`), retraining runs with every round (`B/`), `truth.json`, splits, locked configurations.
- `../step2_loop_20261011/results/grid/`: the second loop.
- The reproducibility package `../../revisions/ifs2027_nier_20261007/artifact/nier_full_artifact_20261012.zip`,
  only to check that its `historical_experiment_artifact/` holds the same data.

## Scripts, in the order they were run

```powershell
python -X utf8 -B reproduce.py        # Tables 2, 3, 6 and Appendix D's 51/30/21/12 from raw records; exit 1 on any difference
python -X utf8 -B checkpoints.py      # package vs disk; reload all 217 checkpoints and compare outputs with the records
python -X utf8 -B mechanisms.py       # items 1-3
python -X utf8 -B shuffle_control.py  # item 5: 20 retraining runs, original order (must reproduce) + 2 shuffles x 3 seeds
python -X utf8 -B extras.py           # shortfalls, facts for item 4, item-5 agreement
python -X utf8 -B report_tables.py    # results/tables_zh.md
```

`common.py` holds the shared definitions (exact / wider / omission, path, blocking,
joined iteration, acceptance). Environment: CPython 3.14.7, PyTorch 2.14.1+cpu,
NumPy 2.5.2, one thread, the interpreter used by the original experiments.

## Results

| File | Content |
|---|---|
| `results/reproduction.json` | recomputed and printed rows of Tables 2, 3, 6 and Appendix D numbers; all equal |
| `results/checkpoints.json` | package comparison; 217 checkpoints reloaded, outputs equal to the records |
| `results/item1_item2_models.csv` | one row per trained model (110): path, path omissions by kind, error directions, training membership, widths |
| `results/item1_path_omissions.json` | item 1 summary and every path omission |
| `results/item2_configurations.csv`, `results/item2_summary.json` | item 2 by configuration and by setting |
| `results/item3_rounds.csv`, `results/item3_retraining.json` | item 3: every round of the 20 retraining runs, per-run analyses, totals |
| `results/shuffle/summary.json`, `results/shuffle/runs.csv` | item 5 |
| `results/extras.json` | supplementary counts |
| `results/tables_zh.md` | generated detail tables |

The checkpoints written by `shuffle_control.py` (under `results/shuffle/runs/`) are
not for Git (`.gitignore`), like the other experiments' model weights.

