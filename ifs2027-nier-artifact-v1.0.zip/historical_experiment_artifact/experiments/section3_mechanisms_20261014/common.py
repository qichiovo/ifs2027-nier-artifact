"""Shared loading for the Section 3 mechanism analysis. Read-only on the experiment records.

The three settings are the paper's primary grid (N = 30), the N = 50 grid and the
second loop (step 2). Records are the workers' result.json files; the oracle is
recomputed from the loop's definition and compared with each grid's truth.json.
Definitions follow the analysis instruction (user_instructions.md):
  exact     X(a) = F(a)
  wider     F(a) below X(a) and X(a) != F(a)
  omission  F(a) not below X(a)
  path      the states visited by joined iteration from bottom up to and including the state where it stops
  blocking  iteration stops at a, i.e. X(a) below a
"""
from __future__ import annotations
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
EXP = HERE.parent
LEARNED = EXP / 'learned_admission'
STEP2 = EXP / 'step2_loop_20261011'
sys.dont_write_bytecode = True
for p in (str(EXP), str(STEP2), str(LEARNED)):
    if p not in sys.path:
        sys.path.insert(0, p)
import numpy as np
from core import G, Domain                    # noqa: E402  (imports torch through inference.py)
from loop import loop_function                # noqa: E402

SETTINGS = {
    'N30': {'root': LEARNED / 'results' / 'core', 'label': 'primary grid, N = 30, K = 18'},
    'N50': {'root': LEARNED / 'confirmation_n50' / 'results', 'label': 'N = 50 grid, K = 30'},
    'loop2': {'root': STEP2 / 'results' / 'grid', 'label': 'second loop (step 2), N = 30, K = 18'},
}


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=1, ensure_ascii=False, default=lambda o: o.item()) + '\n', encoding='utf-8')


def state(a):
    return None if a.is_bot else [a.lo, a.hi]


def interval(v):
    return G.BOT if v is None else G.Interval(int(v[0]), int(v[1]))


class Setting:
    def __init__(self, name):
        self.name = name
        self.root = SETTINGS[name]['root']
        self.label = SETTINGS[name]['label']
        self.cfg = read_json(self.root / 'config.lock.json')
        self.step = self.cfg.get('step', 1)
        self.d = Domain(self.cfg['N'], self.cfg['K'])
        self.n, self.k = self.d.n, self.d.k
        self.truth = np.array([state(loop_function(a, self.k, self.n, self.step)) for a in self.d.states], dtype=np.int64)
        saved = read_json(self.root / 'truth.json')
        assert saved['outputs'] == self.truth.tolist(), 'truth.json differs from the loop definition'
        assert all(self.truth[i, 0] == 0 for i in range(self.d.size)), 'F has lower endpoint 0 everywhere'
        self.exact_path = rollout(self.d, self.truth)['ids']
        self.exact_final = state(self.d.states[self.exact_path[-1]])

    def a_records(self):
        for path in sorted((self.root / 'A').glob('*/result.json')):
            yield path.parent, read_json(path)

    def b_runs(self):
        if not (self.root / 'B').exists():
            return
        for path in sorted((self.root / 'B').glob('*/result.json')):
            yield path.parent, read_json(path)

    def ids_of(self, states):
        return [self.d.ids[interval(s)] for s in states]


def rollout(d, table):
    """Joined iteration from bottom over a table of outputs; no oracle."""
    current, seen, ids = G.BOT, set(), []
    for _ in range(d.size + 1):
        idx = d.ids[current]
        if idx in seen:
            return {'status': 'cycle', 'ids': ids, 'final': None}
        seen.add(idx)
        ids.append(idx)
        nxt = G.join(current, interval(table[idx]))
        if nxt == current:
            return {'status': 'converged', 'ids': ids, 'final': state(current)}
        current = nxt
    return {'status': 'step_limit', 'ids': ids, 'final': None}


def relations(pred, truth):
    """Per input: 0 exact, 1 wider, 2 omission."""
    exact = np.all(pred == truth, axis=1)
    omission = (pred[:, 0] > truth[:, 0]) | (pred[:, 1] < truth[:, 1])
    rel = np.where(exact, 0, np.where(omission, 2, 1))
    return rel


def mono_mask(d, pred):
    """Violating comparable ordered pairs (bottom and reflexive pairs included), as in core.rules."""
    lo, hi = pred[:, 0], pred[:, 1]
    return (lo[d.left] < lo[d.right]) | (hi[d.left] > hi[d.right])


def verdict(s, run):
    """Soundness and post-fixpoint acceptance of a joined run."""
    if run['status'] != 'converged':
        return {'converged': False, 'sound': False, 'accepted': False, 'final': None}
    final = interval(run['final'])
    image = loop_function(final, s.k, s.n, s.step)
    return {'converged': True, 'sound': G.leq(G.Interval(0, s.k), final), 'accepted': G.leq(image, final), 'final': run['final']}


def width(table):
    return table[:, 1] - table[:, 0] + 1                       # no output and no oracle value is bottom


def neighbours(s, a, b):
    """Endpoints differ by at most one (bottom counts as adjacent to the singletons)."""
    x, y = s.d.states[a], s.d.states[b]
    if a == b:
        return False
    if x.is_bot or y.is_bot:
        other = y if x.is_bot else x
        return (not other.is_bot) and other.lo == other.hi
    return abs(x.lo - y.lo) <= 1 and abs(x.hi - y.hi) <= 1
