"""Items 1 to 3 of the analysis: path omissions, direction of errors, and what retraining changes.

Covers every trained model of the three settings (45 + 20 + 45) and every round of
the 20 retraining runs. Read-only on the records; the oracle is recomputed.

Run:  python -X utf8 -B mechanisms.py
Writes results/item1_*, item2_*, item3_* (CSV per model or round, JSON summaries).
"""
from __future__ import annotations
import csv
import statistics
import numpy as np
from common import HERE, Setting, G, rollout, relations, mono_mask, verdict, width, neighbours, interval, state, read_json, write_json

OUT = HERE / 'results'


def fmt(s, i):
    return 'bottom' if s.d.states[i].is_bot else f'[{s.d.states[i].lo},{s.d.states[i].hi}]'


def classify_path_omission(s, i, x, f):
    """Item 1: what an omission at a visited state does to joined iteration."""
    a = s.d.states[i]
    xi, fi = interval(x), interval(f)
    nxt = G.join(a, xi)
    lower_wrong, upper_short = x[0] > f[0], x[1] < f[1]
    if nxt == a:
        kind = 'blocks'
        detail = ('upper endpoint short' if upper_short else '') + (' and ' if upper_short and lower_wrong else '') + ('lower endpoint wrong' if lower_wrong else '')
        return {'kind': kind, 'detail': detail, 'stop_state_sound': G.leq(G.Interval(0, s.k), a)}
    if not upper_short and lower_wrong and G.leq(fi, nxt):
        return {'kind': 'i_lower_only_absorbed', 'detail': 'lower endpoint wrong, absorbed by the join with the current state'}
    top = -1 if a.is_bot else a.hi
    if upper_short and x[1] > top:
        return {'kind': 'ii_upper_short_but_progress', 'detail': 'upper endpoint short of F but above the current state' + (', lower endpoint also wrong' if lower_wrong else '')}
    if a.is_bot:
        return {'kind': 'iii_other', 'detail': 'at bottom: output does not contain 0, iteration starts elsewhere'}
    if not upper_short and lower_wrong:
        return {'kind': 'iii_other', 'detail': 'lower endpoint wrong and not absorbed (current state does not start at 0)'}
    return {'kind': 'iii_other', 'detail': 'upper endpoint short and not above the current state; iteration moves only through the lower endpoint'}


def share(part, whole):
    return None if whole == 0 else part / whole


def med_range(values):
    values = [v for v in values if v is not None]
    if not values:
        return None
    return {'median': statistics.median(values), 'min': min(values), 'max': max(values), 'n': len(values)}


# ----------------------------------------------------------------------------- items 1 and 2
def trained_models(s):
    rows = []
    for folder, r in s.a_records():
        pred = np.array(r['predictions'], dtype=np.int64)
        rel = relations(pred, s.truth)
        run = rollout(s.d, pred)
        assert [t['id'] for t in r['joined']['trace']] == run['ids'], 'trace differs from the record'
        v = verdict(s, run)
        path = run['ids']
        on_path = np.zeros(s.d.size, dtype=bool)
        on_path[path] = True
        train = np.zeros(s.d.size, dtype=bool)
        train[r['split']['train']] = True
        mono = mono_mask(s.d, pred)
        job = r['job']
        m = {'setting': s.name, 'model_id': job['model_id'], 'width': job['width'], 'coverage': int(round(job['coverage'] * 100)), 'seed': job['seed'],
             'heldout_exact': r['accuracy']['test']['exact_rate'], 'train_exact': r['accuracy']['train']['exact_rate'],
             'omission_inputs': int((rel == 2).sum()), 'monotonicity_violations': int(mono.sum()),
             'global_pass': bool((rel == 2).sum() == 0 and mono.sum() == 0), 'coverage_pass': bool((rel == 2).sum() == 0),
             **v, 'stop_state': fmt(s, path[-1]) if v['converged'] else None}
        # Item 1.
        cats = []
        for i in path:
            if rel[i] == 2:
                c = classify_path_omission(s, i, pred[i].tolist(), s.truth[i].tolist())
                cats.append({'state': fmt(s, i), 'output': pred[i].tolist(), 'exact': s.truth[i].tolist(), 'in_training': bool(train[i]), **c})
        m.update({'path_length': len(path), 'path_fraction': len(path) / s.d.size, 'path_omissions': len(cats),
                  'path_omissions_blocking': sum(c['kind'] == 'blocks' for c in cats),
                  'path_omissions_i': sum(c['kind'] == 'i_lower_only_absorbed' for c in cats),
                  'path_omissions_ii': sum(c['kind'] == 'ii_upper_short_but_progress' for c in cats),
                  'path_omissions_iii': sum(c['kind'] == 'iii_other' for c in cats), 'path_omission_list': cats})
        # Item 2.
        for where, mask in (('all', np.ones(s.d.size, dtype=bool)), ('path', on_path), ('off_path', ~on_path)):
            wider, om = int(((rel == 1) & mask).sum()), int(((rel == 2) & mask).sum())
            m[f'wider_{where}'], m[f'omission_{where}'] = wider, om
            m[f'omission_share_of_inexact_{where}'] = share(om, wider + om)
        m['omissions_in_training'] = int(((rel == 2) & train).sum())
        m['omissions_not_in_training'] = int(((rel == 2) & ~train).sum())
        m['training_inputs'] = int(train.sum())
        dx = width(pred) - width(s.truth)
        m['mean_width_minus_F'] = float(dx.mean())
        outputs = [tuple(o) for o in pred.tolist()]
        values, counts = np.unique(pred, axis=0, return_counts=True)
        m['distinct_outputs'] = int(len(values))
        m['most_common_output'] = values[counts.argmax()].tolist()
        m['most_common_output_share'] = float(counts.max() / s.d.size)
        m['outputs_equal_0K_share'] = float(np.mean([o == (0, s.k) for o in outputs]))
        m['outputs_equal_top_share'] = float(np.mean([o == (0, s.n) for o in outputs]))
        m['max_upper_endpoint'] = int(pred[:, 1].max())
        # On the exact path (bottom, [0,0], ..., up to the exact result), compare upper endpoints with F.
        exact_path = np.array(s.exact_path)
        m['exact_path_upper_short'] = int((pred[exact_path, 1] < s.truth[exact_path, 1]).sum())
        m['exact_path_upper_over'] = int((pred[exact_path, 1] > s.truth[exact_path, 1]).sum())
        m['exact_path_lower_wrong'] = int((pred[exact_path, 0] > s.truth[exact_path, 0]).sum())
        m['exact_path_in_training'] = int(train[exact_path].sum())
        m['exact_path_length'] = len(exact_path)
        if v['converged'] and not v['sound']:
            i = path[-1]
            m['unsound_stop'] = {'state': fmt(s, i), 'output': pred[i].tolist(), 'exact': s.truth[i].tolist(), 'in_training': bool(train[i]),
                                 'relation': ['exact', 'wider', 'omission'][rel[i]]}
        rows.append(m)
    return rows


def summarize_item1(rows):
    out = {}
    for name in ('N30', 'N50', 'loop2'):
        g = [m for m in rows if m['setting'] == name]
        details = {}
        for m in g:
            for c in m['path_omission_list']:
                key = c['kind'] + ': ' + c['detail']
                details[key] = details.get(key, 0) + 1
        out[name] = {'models': len(g),
                     'path_length': med_range([m['path_length'] for m in g]),
                     'path_fraction': med_range([m['path_fraction'] for m in g]),
                     'path_omissions': sum(m['path_omissions'] for m in g),
                     'blocking': sum(m['path_omissions_blocking'] for m in g),
                     'not_blocking': sum(m['path_omissions'] - m['path_omissions_blocking'] for m in g),
                     'not_blocking_i_lower_only_absorbed': sum(m['path_omissions_i'] for m in g),
                     'not_blocking_ii_upper_short_but_progress': sum(m['path_omissions_ii'] for m in g),
                     'not_blocking_iii_other': sum(m['path_omissions_iii'] for m in g),
                     'by_detail': details,
                     'models_with_path_omission': sum(m['path_omissions'] > 0 for m in g),
                     'models_with_path_omission_and_sound_result': sum(m['path_omissions'] > 0 and m['sound'] for m in g),
                     'models_with_path_omission_and_unsound_result': sum(m['path_omissions'] > 0 and not m['sound'] for m in g),
                     'unsound_models': sum(not m['sound'] for m in g),
                     'unsound_models_without_path_omission': sum(not m['sound'] and m['path_omissions'] == 0 for m in g),
                     'blocking_at_sound_state': sum(c['kind'] == 'blocks' and c['stop_state_sound'] for m in g for c in m['path_omission_list']),
                     'path_omissions_on_training_inputs': sum(c['in_training'] for m in g for c in m['path_omission_list'])}
    return out


def summarize_item2(rows):
    configs = []
    for name in ('N30', 'N50', 'loop2'):
        g = [m for m in rows if m['setting'] == name]
        for w in sorted({m['width'] for m in g}):
            for c in sorted({m['coverage'] for m in g}):
                h = [m for m in g if m['width'] == w and m['coverage'] == c]
                if not h:
                    continue
                row = {'setting': name, 'width': w, 'coverage': c, 'models': len(h), 'sound': sum(m['sound'] for m in h),
                       'accepted': sum(m['accepted'] for m in h), 'global_pass': sum(m['global_pass'] for m in h)}
                for key in ('omission_share_of_inexact_all', 'omission_share_of_inexact_path', 'omission_share_of_inexact_off_path',
                            'wider_all', 'omission_all', 'wider_path', 'omission_path', 'mean_width_minus_F', 'heldout_exact',
                            'exact_path_upper_short', 'exact_path_upper_over', 'exact_path_lower_wrong', 'exact_path_in_training', 'path_omissions'):
                    r = med_range([m[key] for m in h])
                    row[key + '_median'] = None if r is None else r['median']
                    row[key + '_min'] = None if r is None else r['min']
                    row[key + '_max'] = None if r is None else r['max']
                configs.append(row)
    summary = {}
    for name in ('N30', 'N50', 'loop2'):
        g = [m for m in rows if m['setting'] == name]
        lawful = [m for m in g if m['global_pass']]
        others = [m for m in g if not m['global_pass']]
        summary[name] = {
            'omissions_total': sum(m['omission_inputs'] for m in g),
            'omissions_in_training': sum(m['omissions_in_training'] for m in g),
            'omissions_not_in_training': sum(m['omissions_not_in_training'] for m in g),
            'models_with_omissions_on_training_inputs': sum(m['omissions_in_training'] > 0 for m in g),
            'unsound_models': [{'model_id': m['model_id'], 'heldout_exact': m['heldout_exact'], **m['unsound_stop']} for m in g if 'unsound_stop' in m],
            'lawful_models': [{'model_id': m['model_id'], 'heldout_exact': m['heldout_exact'], 'mean_width_minus_F': m['mean_width_minus_F'],
                               'distinct_outputs': m['distinct_outputs'], 'most_common_output': m['most_common_output'],
                               'most_common_output_share': m['most_common_output_share'], 'outputs_equal_0K_share': m['outputs_equal_0K_share'],
                               'outputs_equal_top_share': m['outputs_equal_top_share'], 'final': m['final']} for m in lawful],
            'mean_width_minus_F_lawful': med_range([m['mean_width_minus_F'] for m in lawful]),
            'mean_width_minus_F_others': med_range([m['mean_width_minus_F'] for m in others]),
            'distinct_outputs_lawful': med_range([m['distinct_outputs'] for m in lawful]),
            'distinct_outputs_others': med_range([m['distinct_outputs'] for m in others]),
            'max_upper_endpoint_over_models': max(m['max_upper_endpoint'] for m in g),
        }
    return configs, summary


# ----------------------------------------------------------------------------- item 3
def stage(s, pred, train_ids):
    rel = relations(pred, s.truth)
    run = rollout(s.d, pred)
    mono = mono_mask(s.d, pred)
    violating_inputs = set(np.flatnonzero(rel == 2).tolist()) | set(s.d.left[mono].tolist()) | set(s.d.right[mono].tolist())
    return {'pred': pred, 'rel': rel, 'run': run, 'path': set(run['ids']), 'mono': mono, 'verdict': verdict(s, run), 'train': set(train_ids),
            'violating_inputs': violating_inputs, 'fresh_candidates': violating_inputs - set(train_ids),
            'fresh_omissions': set(np.flatnonzero(rel == 2).tolist()) - set(train_ids)}


def retraining(s):
    runs, round_rows = [], []
    exact_path = set(s.exact_path)
    zero_u = {s.d.ids[G.Interval(0, u)] for u in range(s.n + 1)}
    for folder, final in s.b_runs():
        model_id = final['job']['model_id']
        original = read_json(s.root / 'A' / model_id / 'result.json')
        stages = [stage(s, np.array(original['predictions'], dtype=np.int64), original['split']['train'])]
        added_by_round, sources_by_round = [], []
        for k in range(1, len(final['rounds']) + 1):
            r = read_json(folder / f'round_{k}' / 'result.json')
            sel = read_json(folder / f'round_{k}' / 'selected_counterexamples.json')
            assert sel['added_ids'] == r['added_ids']
            # Selection order: omission inputs in ascending state id, then members of violating pairs.
            kinds = [x['kind'] for x in sel['sources']]
            assert kinds == sorted(kinds, key=lambda k: k != 'soundness')
            om = [x['ids'][0] for x in sel['sources'] if x['kind'] == 'soundness']
            assert om == sorted(om)
            added_by_round.append(r['added_ids'])
            sources_by_round.append(sel['sources'])
            stages.append(stage(s, np.array(r['predictions'], dtype=np.int64), r['split']['train']))
        assert stages[-1]['pred'].tolist() == final['predictions'], 'final model differs from the last round'
        added_all = [i for a in added_by_round for i in a]
        for k, st in enumerate(stages):
            row = {'setting': s.name, 'model_id': model_id, 'round': k,
                   'omissions_on_own_path': int(sum(st['rel'][i] == 2 for i in st['path'])),
                   'omissions_off_own_path': int(sum(st['rel'] == 2) - sum(st['rel'][i] == 2 for i in st['path'])),
                   'monotonicity_violations': int(st['mono'].sum()), 'violating_inputs': len(st['violating_inputs']),
                   'final': st['verdict']['final'], 'sound': st['verdict']['sound'], 'accepted': st['verdict']['accepted']}
            if k:
                added = added_by_round[k - 1]
                before = stages[k - 1]
                kinds = {}                          # the source that first brought an input in (omissions come first)
                for x in sources_by_round[k - 1]:
                    for i in x['ids']:
                        if i in added and i not in kinds:
                            kinds[i] = x['kind']
                row.update({'added': len(added),
                            'added_on_own_path_before_round': sum(i in before['path'] for i in added),
                            'added_off_own_path_before_round': sum(i not in before['path'] for i in added),
                            'added_on_exact_path': sum(i in exact_path for i in added),
                            'added_zero_u_beyond_exact_path': sum(i in zero_u and i not in exact_path for i in added),
                            'added_as_omission': sum(kinds.get(i) == 'soundness' for i in added),
                            'added_as_pair_member': sum(kinds.get(i) == 'monotonicity' for i in added),
                            'first_added': [fmt(s, i) for i in added[:6]],
                            'fresh_omission_candidates': len(before['fresh_omissions']),
                            'fresh_omissions_left_out_by_cap': len(before['fresh_omissions'] - set(added)),
                            'fresh_exact_path_omissions': len(before['fresh_omissions'] & exact_path),
                            'exact_path_omissions_already_in_training': len({i for i in exact_path if before['rel'][i] == 2} & before['train']),
                            'own_path_stop_is_fresh_omission': (before['run']['ids'][-1] in before['fresh_omissions']),
                            'own_path_stop_is_omission_in_training': bool(before['rel'][before['run']['ids'][-1]] == 2 and before['run']['ids'][-1] in before['train']),
                            'fixed_violating_inputs': len(before['violating_inputs'] - st['violating_inputs']),
                            'new_violating_inputs': len(st['violating_inputs'] - before['violating_inputs'])})
            round_rows.append(row)
        first, last = stages[0], stages[-1]
        info = {'setting': s.name, 'model_id': model_id, 'rounds': len(stages) - 1, 'stop_reason': final['stop_reason'],
                'before': {'final': first['verdict']['final'], 'sound': first['verdict']['sound'], 'accepted': first['verdict']['accepted'],
                           'omissions': int((first['rel'] == 2).sum()), 'monotonicity_violations': int(first['mono'].sum())},
                'after': {'final': last['verdict']['final'], 'sound': last['verdict']['sound'], 'accepted': last['verdict']['accepted'],
                          'omissions': int((last['rel'] == 2).sum()), 'monotonicity_violations': int(last['mono'].sum()),
                          'global_pass': bool((last['rel'] == 2).sum() == 0 and last['mono'].sum() == 0)},
                'added_total': len(added_all)}
        # 3c.
        if not first['verdict']['accepted'] and last['verdict']['accepted']:
            stop = s.exact_path and first['run']['ids'][-1]
            added_round = next((k + 1 for k, a in enumerate(added_by_round) if stop in a), None)
            fixed = (first['rel'] == 2) & (last['rel'] != 2)
            info['rejected_to_accepted'] = {
                'stop_before': fmt(s, stop), 'stop_before_output': first['pred'][stop].tolist(), 'stop_before_exact': s.truth[stop].tolist(),
                'stop_before_added_in_round': added_round,
                'stop_before_in_original_training': stop in first['train'],
                'stop_before_relation_after': ['exact', 'wider', 'omission'][int(last['rel'][stop])],
                'path_before': [fmt(s, i) for i in first['run']['ids']], 'path_after': [fmt(s, i) for i in last['run']['ids']],
                'path_after_extends_path_before': last['run']['ids'][:len(first['run']['ids']) - 1] == first['run']['ids'][:-1],
                'path_after_is_exact_path': last['run']['ids'] == s.exact_path,
                'omissions_fixed_total': int(fixed.sum()),
                'omissions_fixed_on_path_after': int(sum(fixed[i] for i in last['run']['ids'])),
                'path_inputs_after_that_were_omissions_before': [fmt(s, i) for i in last['run']['ids'] if first['rel'][i] == 2],
                'omissions_on_path_before': [fmt(s, i) for i in first['run']['ids'] if first['rel'][i] == 2],
                'after_still_violates_a_law': not info['after']['global_pass']}
        # 3d.
        new_om = np.flatnonzero((first['rel'] != 2) & (last['rel'] == 2)).tolist()
        added_set = set(added_all)
        info['new_omissions'] = {'count': len(new_om), 'in_added': sum(i in added_set for i in new_om),
                                 'next_to_added': sum(i not in added_set and any(neighbours(s, i, j) for j in added_set) for i in new_om),
                                 'elsewhere': sum(i not in added_set and not any(neighbours(s, i, j) for j in added_set) for i in new_om),
                                 'were_exact_before': sum(first['rel'][i] == 0 for i in new_om),
                                 'were_wider_before': sum(first['rel'][i] == 1 for i in new_om)}
        # 3e.
        new_pairs = np.flatnonzero(last['mono'] & ~first['mono'])
        left, right = s.d.left[new_pairs], s.d.right[new_pairs]
        touches = np.array([a in added_set or b in added_set for a, b in zip(left, right)], dtype=bool)
        fixed_a = (first['rel'][left] == 2) & (last['rel'][left] != 2)
        exposed_after = fixed_a & (last['rel'][right] == 2)
        exposed_still = exposed_after & (first['rel'][right] == 2)
        info['new_monotonicity_pairs'] = {'count': int(len(new_pairs)), 'touching_added': int(touches.sum()),
                                          'smaller_fixed_larger_omission_after': int(exposed_after.sum()),
                                          'smaller_fixed_larger_omission_before_and_after': int(exposed_still.sum()),
                                          'pairs_violating_before': int(first['mono'].sum()), 'pairs_violating_after': int(last['mono'].sum()),
                                          'old_pairs_repaired': int((first['mono'] & ~last['mono']).sum())}
        # 3f.
        budget = s.cfg['repair_new_inputs'] * (s.cfg['repair_rounds'] - (len(stages) - 1))
        info['end_state'] = {'violating_inputs_last': len(last['violating_inputs']),
                             'fresh_candidates_last': len(last['fresh_candidates']),
                             'violating_inputs_already_in_training': len(last['violating_inputs']) - len(last['fresh_candidates']),
                             'remaining_budget': budget,
                             'violating_inputs_by_round': [len(st['violating_inputs']) for st in stages],
                             'fixed_by_round': [len(stages[k - 1]['violating_inputs'] - stages[k]['violating_inputs']) for k in range(1, len(stages))],
                             'new_by_round': [len(stages[k]['violating_inputs'] - stages[k - 1]['violating_inputs']) for k in range(1, len(stages))]}
        runs.append(info)
    return runs, round_rows


def write_csv(path, rows, skip=()):
    keys = [k for k in rows[0] if k not in skip]
    with path.open('w', newline='', encoding='utf-8') as stream:
        w = csv.DictWriter(stream, fieldnames=keys, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in keys})


def main():
    OUT.mkdir(exist_ok=True)
    settings = {name: Setting(name) for name in ('N30', 'N50', 'loop2')}
    rows = [m for s in settings.values() for m in trained_models(s)]
    write_csv(OUT / 'item1_item2_models.csv', rows, skip=('path_omission_list', 'unsound_stop', 'most_common_output'))
    write_json(OUT / 'item1_path_omissions.json', {'summary': summarize_item1(rows),
                                                   'per_model': [{k: m[k] for k in ('setting', 'model_id', 'sound', 'final', 'path_length', 'path_omission_list')}
                                                                 for m in rows if m['path_omissions']]})
    configs, summary2 = summarize_item2(rows)
    write_csv(OUT / 'item2_configurations.csv', configs)
    write_json(OUT / 'item2_summary.json', {'by_setting': summary2, 'by_configuration': configs})
    runs, round_rows = [], []
    for name in ('N30', 'N50'):
        r, rr = retraining(settings[name])
        runs += r
        round_rows += rr
    write_csv(OUT / 'item3_rounds.csv', round_rows, skip=('first_added',))
    totals = {
        'runs': len(runs), 'rounds': sum(r['rounds'] for r in runs),
        'rejected_to_accepted': sum('rejected_to_accepted' in r for r in runs),
        'accepted_to_rejected': sum(r['before']['accepted'] and not r['after']['accepted'] for r in runs),
        'global_pass_after': sum(r['after']['global_pass'] for r in runs),
        'new_omissions': {k: sum(r['new_omissions'][k] for r in runs) for k in runs[0]['new_omissions']},
        'new_monotonicity_pairs': {k: sum(r['new_monotonicity_pairs'][k] for r in runs) for k in runs[0]['new_monotonicity_pairs']},
        'added': {k: sum(x.get(k, 0) for x in round_rows if x['round']) for k in
                  ('added', 'added_on_own_path_before_round', 'added_off_own_path_before_round', 'added_on_exact_path',
                   'added_zero_u_beyond_exact_path', 'added_as_omission', 'added_as_pair_member', 'fresh_omission_candidates',
                   'fresh_omissions_left_out_by_cap', 'fresh_exact_path_omissions', 'exact_path_omissions_already_in_training',
                   'own_path_stop_is_fresh_omission', 'own_path_stop_is_omission_in_training')},
        'rounds_where_the_cap_left_out_omissions': sum(x.get('fresh_omissions_left_out_by_cap', 0) > 0 for x in round_rows if x['round']),
        'stop_reasons': {k: sum(r['stop_reason'] == k for r in runs) for k in sorted({r['stop_reason'] for r in runs})},
    }
    write_json(OUT / 'item3_retraining.json', {'totals': totals, 'runs': runs, 'rounds': round_rows})
    print('item 1:', {k: {x: v[x] for x in ('path_omissions', 'blocking', 'not_blocking', 'not_blocking_i_lower_only_absorbed',
                                          'not_blocking_ii_upper_short_but_progress', 'not_blocking_iii_other', 'models_with_path_omission_and_sound_result')}
                      for k, v in summarize_item1(rows).items()})
    print('item 3:', totals)


if __name__ == '__main__':
    main()
