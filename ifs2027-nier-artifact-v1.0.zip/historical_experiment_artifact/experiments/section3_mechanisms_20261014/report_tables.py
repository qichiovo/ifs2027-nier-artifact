"""Detail tables of the report, generated from results/*.json. Writes results/tables_zh.md.

Run last:  python -X utf8 -B report_tables.py
"""
from __future__ import annotations
from common import HERE, read_json

R = HERE / 'results'


def table(head, rows):
    out = ['| ' + ' | '.join(head) + ' |', '|' + '---|' * len(head)]
    out += ['| ' + ' | '.join(str(c) for c in r) + ' |' for r in rows]
    return '\n'.join(out)


def pct(x):
    return '' if x is None else f'{100 * x:.0f}%'


def main():
    item1 = read_json(R / 'item1_path_omissions.json')['summary']
    item2 = read_json(R / 'item2_summary.json')
    item3 = read_json(R / 'item3_retraining.json')
    extras = read_json(R / 'extras.json')
    shuffle = read_json(R / 'shuffle' / 'summary.json')
    names = {'N30': '主循环 N=30', 'N50': '主循环 N=50', 'loop2': '第二个循环'}
    parts = ['# 第 3 节机制分析：明细表\n\n由 `report_tables.py` 从 `results/` 里的 JSON 生成。说明和结论见 `../REPORT_ZH.md`。\n']

    parts.append('## 第 1 项：路径上的遗漏\n')
    keys = [('models', '模型数'), ('path_omissions', '路径遗漏'), ('blocking', '阻断'), ('not_blocking', '未阻断'),
            ('not_blocking_i_lower_only_absorbed', '(i) 下端点错被吸收'), ('not_blocking_ii_upper_short_but_progress', '(ii) 上端点短但仍超出当前区间'),
            ('not_blocking_iii_other', '(iii) 其他'), ('models_with_path_omission', '有路径遗漏的模型'),
            ('models_with_path_omission_and_sound_result', '其中结果可靠'), ('unsound_models', '不可靠模型'),
            ('unsound_models_without_path_omission', '不可靠但路径上无遗漏'), ('path_omissions_on_training_inputs', '路径遗漏中属于训练输入的')]
    rows = [[label] + [item1[n][k] for n in names] for k, label in keys]
    rows.insert(1, ['路径长度 中位数（范围）'] + [f"{item1[n]['path_length']['median']:g}（{item1[n]['path_length']['min']}–{item1[n]['path_length']['max']}）" for n in names])
    rows.insert(2, ['路径占全域 中位数（范围）'] + [f"{100 * item1[n]['path_fraction']['median']:.1f}%（{100 * item1[n]['path_fraction']['min']:.1f}–{100 * item1[n]['path_fraction']['max']:.1f}%）" for n in names])
    parts.append(table([''] + list(names.values()), rows) + '\n')

    parts.append('## 第 2 项：错误方向，按配置（中位数，括号内为范围）\n')
    rows = []
    for c in item2['by_configuration']:
        rows.append([names[c['setting']], c['width'], c['coverage'], f"{c['accepted']}/{c['models']}", f"{c['sound']}/{c['models']}", c['global_pass'],
                     f"{pct(c['omission_share_of_inexact_all_median'])}（{pct(c['omission_share_of_inexact_all_min'])}–{pct(c['omission_share_of_inexact_all_max'])}）",
                     f"{c['wider_all_median']:g}", f"{c['omission_all_median']:g}", f"{c['mean_width_minus_F_median']:.2f}",
                     f"{c['exact_path_upper_over_median']:g}", f"{c['exact_path_upper_short_median']:g}", f"{c['exact_path_in_training_median']:g}"])
    parts.append(table(['设置', '宽度', '覆盖率%', '接受', '可靠', '全局通过', '遗漏占不精确输入', '更宽输入数', '遗漏输入数', '平均比 F 宽',
                        '精确路径上上端点偏高', '精确路径上上端点偏低', '精确路径输入在训练集'], rows) + '\n')
    parts.append('“精确路径”指 F 自己的联合迭代经过的输入（⊥, [0,0], …, 到 F 的结果）。\n')
    rows = []
    for n in names:
        s = item2['by_setting'][n]
        rows.append([names[n], s['omissions_total'], s['omissions_in_training'], s['omissions_not_in_training'],
                     f"{sum(x['in_training'] for x in s['unsound_models'])}/{len(s['unsound_models'])}", len(s['lawful_models']),
                     '' if s['mean_width_minus_F_lawful'] is None else f"{s['mean_width_minus_F_lawful']['median']:.2f}",
                     f"{s['mean_width_minus_F_others']['median']:.2f}（{s['mean_width_minus_F_others']['min']:.2f}–{s['mean_width_minus_F_others']['max']:.2f}）",
                     '' if s['distinct_outputs_lawful'] is None else f"{s['distinct_outputs_lawful']['min']}–{s['distinct_outputs_lawful']['max']}",
                     f"{s['distinct_outputs_others']['median']:g}（{s['distinct_outputs_others']['min']}–{s['distinct_outputs_others']['max']}）"])
    parts.append(table(['设置', '遗漏总数', '在训练集', '不在训练集', '不可靠模型停在训练输入上', '全局通过模型', '其平均比 F 宽',
                        '其他模型平均比 F 宽', '全局通过模型的不同输出个数', '其他模型的不同输出个数'], rows) + '\n')
    for n in names:
        s = item2['by_setting'][n]
        parts.append(f"**{names[n]}，每个不可靠模型停在哪里**（输出 / F / 是否训练输入）：" + '；'.join(
            f"{x['model_id']} 停在 {x['state']}（{x['output']} / {x['exact']} / {'是' if x['in_training'] else '否'}）" for x in s['unsound_models']) + '\n')
        if s['lawful_models']:
            parts.append(f"**{names[n]}，全局通过的模型**：" + '；'.join(
                f"{x['model_id']}（留出精确率 {100 * x['heldout_exact']:.1f}%，最常见输出 {x['most_common_output']} 占 {100 * x['most_common_output_share']:.1f}%，不同输出 {x['distinct_outputs']} 个）"
                for x in s['lawful_models']) + '\n')
    rows = [[k, v['models'], v['with_short_input_on_exact_path'], v['first_short_by_1'], v['first_short_by_2_or_more'], v['short_by_1_inputs'], v['short_by_2_or_more_inputs']]
            for k, v in extras['shortfall_by_setting_and_coverage'].items()]
    parts.append('**精确路径上上端点偏低的输入**\n\n' + table(['设置与覆盖率', '模型', '精确路径上有偏低输入的模型', '第一个偏低输入差 1', '第一个偏低输入差 ≥2', '差 1 的输入', '差 ≥2 的输入'], rows) + '\n')

    parts.append('## 第 3 项：重训练\n')
    t = item3['totals']
    parts.append(table(['统计', '数值'], [[k, v] for k, v in t['added'].items()] + [['截断了遗漏输入的轮次', t['rounds_where_the_cap_left_out_omissions']]]) + '\n')
    parts.append('**3b 每个 run 每一轮**（第 0 轮是重训练前；加入数按“上一轮模型自己的路径上 / 路径外”分；遗漏按“本轮模型自己的路径上 / 路径外”分）\n')
    rows = []
    for x in item3['rounds']:
        rows.append([names[x['setting']], x['model_id'], x['round'],
                     '' if not x['round'] else f"{x['added_on_own_path_before_round']} / {x['added_off_own_path_before_round']}",
                     '' if not x['round'] else f"{x['added_as_omission']} / {x['added_as_pair_member']}",
                     f"{x['omissions_on_own_path']} / {x['omissions_off_own_path']}", x['monotonicity_violations'],
                     x['violating_inputs'], x['final'], '接受' if x['accepted'] else '拒绝'])
    parts.append(table(['设置', 'run', '轮', '加入（路径上 / 路径外）', '加入（遗漏 / 违规对成员）', '遗漏（路径上 / 路径外）', '单调性违规对', '违规输入', '最终区间', '检查'], rows) + '\n')
    rows = []
    for r in item3['runs']:
        x = r.get('rejected_to_accepted')
        if x:
            rows.append([names[r['setting']], r['model_id'], x['stop_before'], x['stop_before_added_in_round'] or '未加入（已在训练集）',
                         '是' if x['path_after_extends_path_before'] else '否', len(x['path_after']), x['omissions_fixed_on_path_after'],
                         x['omissions_fixed_total'], '是' if x['after_still_violates_a_law'] else '否'])
    parts.append('**3c 由拒绝变成接受的 run**\n\n' + table(['设置', 'run', '原停止输入', '在第几轮被加入', '新路径沿用旧路径前缀', '新路径长度',
                                                         '新路径上被修好的原遗漏', '共修好的原遗漏', '重训练后仍违反定律'], rows) + '\n')
    rows = [[names[r['setting']], r['model_id'], r['new_omissions']['count'], r['new_omissions']['in_added'], r['new_omissions']['next_to_added'],
             r['new_omissions']['elsewhere'], r['new_monotonicity_pairs']['count'], r['new_monotonicity_pairs']['touching_added'],
             r['new_monotonicity_pairs']['smaller_fixed_larger_omission_after'], r['new_monotonicity_pairs']['pairs_violating_before'],
             r['new_monotonicity_pairs']['pairs_violating_after']] for r in item3['runs']]
    parts.append('**3d / 3e 新冒出来的遗漏和单调性违规对**（相对重训练前的原模型）\n\n' + table(
        ['设置', 'run', '新遗漏', '在加入的反例里', '与反例相邻', '其他', '新违规对', '至少一端是反例', '小端被修好、大端仍遗漏', '重训练前违规对', '重训练后违规对'], rows) + '\n')
    rows = [[names[r['setting']], r['model_id'], r['stop_reason'], r['rounds'], r['end_state']['violating_inputs_last'],
             r['end_state']['violating_inputs_already_in_training'], r['end_state']['fresh_candidates_last'], r['end_state']['remaining_budget'],
             sum(r['end_state']['fixed_by_round']), sum(r['end_state']['new_by_round']),
             ' → '.join(str(v) for v in r['end_state']['violating_inputs_by_round'])]
            for r in item3['runs'] if not r['after']['global_pass']]
    parts.append('**3f 没通过全局检查的 17 个 run**\n\n' + table(['设置', 'run', '停止原因', '轮数', '最后剩下的违规输入', '其中已在训练集',
                                                              '其中可作新反例', '剩余预算', '各轮修好合计', '各轮新增合计', '违规输入逐轮'], rows) + '\n')

    parts.append('## 第 5 项：打乱反例顺序\n')
    rows = [[x['variant'], x['seed'], f"{x['accepted']}/20", f"{x['accepted_N30']}/10", f"{x['accepted_N50']}/10", f"{x['global_pass']}/20", f"{x['seconds']:.1f}"]
            for x in shuffle['by_variant_and_seed']]
    parts.append(table(['顺序', '种子', '接受', 'N=30', 'N=50', '全局通过', '用时（秒）'], rows) + '\n')
    parts.append(f"与原顺序逐个 run 比，接受与否相同的 run 数：{extras['item5_agreement_with_original']}；七次运行都接受的 run：{extras['item5_runs_accepted_in_every_variant']} 个，都不接受的：{extras['item5_runs_rejected_in_every_variant']} 个。\n")
    (R / 'tables_zh.md').write_text('\n'.join(parts), encoding='utf-8')
    print('wrote', R / 'tables_zh.md')


if __name__ == '__main__':
    main()
