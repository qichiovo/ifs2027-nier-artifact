"""Finite semantics imported from the original artifact; cached full-domain checks."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from collections import defaultdict
import numpy as np
import torch
from inference import encode, decode

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import nonmonotone_interval_gate as G


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def code_hash():
    paths = [HERE / x for x in ("inference.py", "core.py", "worker.py", "run.py")]
    paths.append(HERE.parent / "nonmonotone_interval_gate.py")
    return digest({str(p.relative_to(HERE.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})


class Domain:
    def __init__(self, n, k):
        self.n, self.k = n, k
        self.states = G.intervals(n)
        self.ids = {s: i for i, s in enumerate(self.states)}
        self.size = len(self.states)
        self.inputs = [None if s.is_bot else [s.lo, s.hi] for s in self.states]
        self.x = encode(self.inputs, n)
        # Build comparable ordered pairs once, including bottom and self pairs.
        pairs = [(i, j) for i, a in enumerate(self.states)
                 for j, b in enumerate(self.states) if G.leq(a, b)]
        self.left, self.right = np.asarray(pairs, dtype=np.int32).T
        self.subsets = [self.left[self.right == j] for j in range(self.size)]


class Oracle:
    """Full truth cache is generated once. Count requests as well as evaluations.

    Cache exposure is an offline operation; model inference never owns this object.
    """
    def __init__(self, domain, cache):
        self.d = domain
        self.cache = read_json(cache)
        assert self.cache["N"] == domain.n and self.cache["K"] == domain.k
        self.table = np.array(self.cache["outputs"], dtype=np.int64)
        self.requests = defaultdict(int)
        self.unique = defaultdict(set)

    def get(self, ids, category):
        ids = [int(i) for i in ids]
        self.requests[category] += len(ids)
        self.unique[category].update(ids)
        return self.table[ids]

    def stats(self):
        return {"requests": dict(self.requests),
                "unique_ids_by_category": {k: sorted(v) for k, v in self.unique.items()},
                "unique_counts": {k: len(v) for k, v in self.unique.items()},
                "actual_F_evaluations_this_worker": 0,
                "cache": "shared immutable full carrier truth.json; see preparation.json for its construction cost"}


def rules(d, prediction, truth):
    t0 = time.perf_counter()
    lo, hi = prediction.T
    mono_mask = (lo[d.left] < lo[d.right]) | (hi[d.left] > hi[d.right])
    mono_idx = np.flatnonzero(mono_mask)
    sound = np.flatnonzero((lo > truth[:, 0]) | (hi < truth[:, 1]))
    infl = [i for i, s in enumerate(d.states) if not s.is_bot and
            not (lo[i] <= s.lo and s.hi <= hi[i])]
    examples = {"soundness": [{"id": int(i), "input": d.inputs[i],
                               "exact": truth[i].tolist(), "predicted": prediction[i].tolist()} for i in sound[:5]],
                "monotonicity": [{"smaller_id": int(d.left[q]), "larger_id": int(d.right[q]),
                                   "smaller": d.inputs[d.left[q]], "larger": d.inputs[d.right[q]],
                                   "output_smaller": prediction[d.left[q]].tolist(),
                                   "output_larger": prediction[d.right[q]].tolist()} for q in mono_idx[:5]]}
    return {"monotonicity_violations": len(mono_idx), "ordered_pairs": len(d.left),
            "soundness_violations": len(sound), "inputs": d.size,
            "has_rule_violation": bool(len(mono_idx) or len(sound)),
            "raw_inflation_violations_diagnostic": len(infl),
            "joined_update_inflation_violations": 0,
            "mean_output_width": float(np.mean(hi - lo + 1)),
            "examples": examples, "soundness_ids": sound.tolist(),
            "monotonicity_pair_indices": mono_idx.tolist(),
            "check_seconds": time.perf_counter() - t0}


def iterate(d, prediction, oracle, joined, category="final_evaluation"):
    t0 = time.perf_counter()
    current = G.BOT
    seen = {}
    trace = []
    calls = 0
    status = "step_limit"
    cycle_from = None
    # Full state count is a conservative cap for either update strategy.
    for _ in range(d.size + 1):
        idx = d.ids[current]
        if idx in seen:
            status, cycle_from = "cycle", seen[idx]
            break
        seen[idx] = len(trace)
        v = prediction[idx]
        target = G.Interval(int(v[0]), int(v[1]))
        next_value = G.join(current, target) if joined else target
        trace.append({"id": idx, "state": d.inputs[idx], "prediction": v.tolist(),
                      "next": [next_value.lo, next_value.hi]})
        calls += 1
        if next_value == current:
            status = "converged"
            break
        current = next_value
    converged = status == "converged"
    exact = oracle.get([d.ids[current]], category)[0]
    postfixed = G.leq(G.Interval(int(exact[0]), int(exact[1])), current)
    covers = G.leq(G.Interval(0, d.k), current)
    proved = sum(current.is_bot or current.hi <= c for c in range(d.k, d.n + 1)) if converged else None
    return {"status": status, "terminated": converged, "cycle": status == "cycle",
            "cycle_from": cycle_from, "final": None if not converged else [current.lo, current.hi],
            "last_state": None if current.is_bot else [current.lo, current.hi],
            "steps": len(trace) - 1 if converged else len(trace),
            "transformer_calls_including_stability": calls,
            "covers_reachable": covers if converged else False,
            "postfixed_exact_F": postfixed if converged else False,
            "analysis_failure": not (converged and covers and postfixed),
            "false_proof_x_le_k_minus_1": bool(converged and (current.is_bot or current.hi < d.k)),
            "true_assertions_proved": proved, "true_assertions_total": d.n - d.k + 1,
            "final_width": current.width(d.n) if converged else None,
            "trace": trace, "iteration_cached_seconds": time.perf_counter() - t0}


def assess(d, prediction, oracle, split, category="final_evaluation", logits=None):
    truth = oracle.get(range(d.size), category)
    rep = rules(d, prediction, truth)
    equal = np.all(prediction == truth, axis=1)
    accuracy = {}
    for name, ids in {**{x: split[x] for x in ("train", "validation", "test")},
                      "carrier": list(range(d.size))}.items():
        accuracy[name] = {"n": len(ids), "exact_count": int(equal[ids].sum()),
                          "exact_rate": float(equal[ids].mean()) if ids else None,
                          "endpoint_mae": np.abs(prediction[ids] - truth[ids]).mean(0).tolist() if ids else None}
    rep["accuracy"] = accuracy
    rep["invalid_decoded_outputs"] = int(np.sum((prediction[:, 0] < 0) |
        (prediction[:, 1] > d.n) | (prediction[:, 0] > prediction[:, 1])))
    rep["invalid_independent_argmax_outputs"] = None if logits is None else int(
        (logits[:, 0].argmax(1) > logits[:, 1].argmax(1)).sum())
    rep["joined"] = iterate(d, prediction, oracle, True, category)
    rep["direct"] = iterate(d, prediction, oracle, False, category)
    return rep


@torch.inference_mode()
def model_table(model, d):
    model.eval()
    t0 = time.perf_counter()
    logits = model(d.x)
    table = decode(logits).numpy()
    return table, logits, time.perf_counter() - t0


@torch.inference_mode()
def timing(model, d):
    model.eval()
    sample = d.x[:1]
    for _ in range(10):
        decode(model(sample))
    times = []
    for _ in range(5):
        start = time.perf_counter()
        for _ in range(100):
            decode(model(sample))
        times.append((time.perf_counter() - start) / 100)
    return {"single_input_median_seconds": float(np.median(times)),
            "single_input_min_seconds": min(times), "single_input_max_seconds": max(times),
            "repeats": 5, "calls_per_repeat": 100,
            "scope": "CPU forward plus legal decode; normalized tensor already constructed"}


def envelopes(d, prediction, truth):
    start = time.perf_counter()
    closure = np.array([[prediction[ids, 0].min(), prediction[ids, 1].max()] for ids in d.subsets])
    paper = np.stack([np.minimum(closure[:, 0], truth[:, 0]),
                      np.maximum(closure[:, 1], truth[:, 1])], axis=1)
    paper_seconds = time.perf_counter() - start
    start = time.perf_counter()
    legacy = np.array([[v[0], v[1]] if a.is_bot else [min(a.lo, v[0]), max(a.hi, v[1])]
                       for a, v in zip(d.states, closure)])
    return paper, legacy, {"paper_build_seconds": paper_seconds,
                           "legacy_extra_build_seconds": time.perf_counter() - start,
                           "cached_truth_acquisition_excluded": True}


def choose_counterexamples(report, d, existing, cap):
    added = []
    selected = set(existing)
    sources = []
    for i in report["soundness_ids"]:
        if i not in selected and len(added) < cap:
            selected.add(i)
            added.append(i)
            sources.append({"kind": "soundness", "ids": [i]})
    for q in report["monotonicity_pair_indices"]:
        pair = [int(d.left[q]), int(d.right[q])]
        fresh = [i for i in pair if i not in selected]
        if fresh and len(added) + len(fresh) <= cap:
            added.extend(fresh)
            selected.update(fresh)
            sources.append({"kind": "monotonicity", "ids": pair})
    return added, sources
