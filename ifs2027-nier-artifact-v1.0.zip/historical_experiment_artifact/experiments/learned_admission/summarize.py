"""Generate all tables, figures and bilingual reports from the saved run only."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import statistics
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from core import HERE, read_json, atomic_json


def write_csv(path, rows):
    if not rows:
        return
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def summary_range(values):
    values = [v for v in values if v is not None]
    return {"mean": statistics.mean(values), "median": statistics.median(values),
            "min": min(values), "max": max(values)} if values else None


def fmt_range(values, digits=3):
    s = summary_range(values)
    if s is None:
        return "NA"
    return f"{s['median']:.{digits}f} [{s['min']:.{digits}f}, {s['max']:.{digits}f}]"


def flat(row, method):
    job = row.get("job", {})
    out = {"model_id": job.get("model_id"), "method": method, "width": job.get("width"),
           "coverage": job.get("coverage"), "seed": job.get("seed"), "status": row.get("status", "completed")}
    for split in ("train", "validation", "test", "carrier"):
        out[f"{split}_accuracy"] = row["accuracy"][split]["exact_rate"]
        out[f"{split}_n"] = row["accuracy"][split]["n"]
        out[f"{split}_lo_mae"], out[f"{split}_hi_mae"] = row["accuracy"][split]["endpoint_mae"] or (None, None)
    for key in ("monotonicity_violations", "ordered_pairs", "soundness_violations", "inputs",
                "has_rule_violation", "mean_output_width", "invalid_decoded_outputs",
                "invalid_independent_argmax_outputs", "checkpoint_bytes", "parameter_count", "wall_seconds"):
        out[key] = row.get(key)
    for use in ("joined", "direct"):
        for key in ("status", "steps", "transformer_calls_including_stability", "covers_reachable",
                    "postfixed_exact_F", "analysis_failure", "false_proof_x_le_k_minus_1",
                    "true_assertions_proved", "final_width", "iteration_cached_seconds"):
            out[f"{use}_{key}"] = row[use][key]
        out[f"{use}_final"] = str(row[use]["final"])
    out["check_seconds"] = row["check_seconds"]
    out["train_seconds"] = row.get("training", {}).get("seconds")
    out["single_inference_seconds"] = row.get("inference_timing", {}).get("single_input_median_seconds")
    out["rounds"] = len(row.get("rounds", [])) if method == "repaired" else None
    out["stop_reason"] = row.get("stop_reason")
    out["scope"] = "held-out test for original only" if method == "original" else "finite-domain adaptation/control"
    return out


def load_runs(root, lane):
    records, statuses = [], []
    for p in sorted((root / lane).glob("*/status.json")):
        s = read_json(p)
        statuses.append({"lane": lane, "model_id": p.parent.name, "status": s["status"]})
        if s["status"] == "completed":
            row = read_json(p.parent / "result.json")
            assert row["status"] == "completed"
            records.append(row)
    return records, statuses


def generate(root):
    cfg = read_json(root / "config.lock.json")
    prep = read_json(root / "preparation.json")
    A, a_status = load_runs(root, "A")
    B, b_status = load_runs(root, "B")
    by_id = {r["job"]["model_id"]: r for r in A}
    out = root / "summary"
    out.mkdir(exist_ok=True)
    figures = out / "figures"
    figures.mkdir(exist_ok=True)
    source_files = sorted(list((root / "A").glob("*/result.json")) + list((root / "B").glob("*/result.json")))
    source_hashes = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    manifest_hash = hashlib.sha256(json.dumps(source_hashes, sort_keys=True).encode()).hexdigest()
    atomic_json(out / "source_manifest.json", {"batch_hash": manifest_hash, "source_results": source_hashes,
                "config_hash": prep["config_hash"], "code_hash": prep["code_hash"]})
    rows = [flat(r, "original") for r in A] + [flat(r, "repaired") for r in B]
    comparisons = []
    for b in B:
        job = b["job"]
        comparisons += [flat(by_id[job["model_id"]], "original"), flat(b, "repaired")]
        for name, reference in b["references"].items():
            comparisons.append(flat({**reference, "job": job}, name))
    write_csv(out / "models.csv", rows)
    write_csv(out / "comparisons.csv", comparisons)
    write_csv(out / "statuses.csv", a_status + b_status)
    with (out / "all_results.jsonl").open("w", encoding="utf-8") as f:
        for lane, records in (("A", A), ("B", B)):
            for r in records:
                f.write(json.dumps({"lane": lane, **r}, ensure_ascii=False) + "\n")
    groups = []
    for width in cfg["widths"]:
        for coverage in cfg["coverages"]:
            group = [r for r in A if r["job"]["width"] == width and r["job"]["coverage"] == coverage]
            record = {"width": width, "coverage": coverage, "planned": len(cfg["seeds"]), "completed": len(group),
                      "law_violation_models": sum(r["has_rule_violation"] for r in group),
                      "joined_failure_models": sum(r["joined"]["analysis_failure"] for r in group),
                      "direct_failure_models": sum(r["direct"]["analysis_failure"] for r in group)}
            for key, vals in {"test_accuracy": [r["accuracy"]["test"]["exact_rate"] for r in group],
                              "carrier_accuracy": [r["accuracy"]["carrier"]["exact_rate"] for r in group],
                              "monotonicity": [r["monotonicity_violations"] for r in group],
                              "soundness": [r["soundness_violations"] for r in group],
                              "training_seconds": [r["training"]["seconds"] for r in group]}.items():
                stats = summary_range(vals)
                if stats:
                    record.update({f"{key}_{k}": v for k, v in stats.items()})
            groups.append(record)
    write_csv(out / "configurations.csv", groups)
    thresholds = []
    for split in ("test", "carrier"):
        for threshold in cfg["thresholds"]:
            subset = [r for r in A if r["accuracy"][split]["exact_rate"] >= threshold]
            thresholds.append({"accuracy_scope": split, "threshold": threshold, "n": len(subset),
                              "rule_violation_models": sum(r["has_rule_violation"] for r in subset),
                              "joined_failure_models": sum(r["joined"]["analysis_failure"] for r in subset)})
    write_csv(out / "accuracy_thresholds.csv", thresholds)
    costs = []
    actual_timing_F = 0
    for lane, records in (("A", A), ("B", B)):
        for r in records:
            stats = r["oracle"]
            cost = {"lane": lane, "model_id": r["job"]["model_id"], "wall_seconds": r["wall_seconds"],
                    "train_seconds": r.get("training", {}).get("seconds", sum(x["training_seconds"] for x in r.get("rounds", []))),
                    "logical_oracle_requests": sum(stats["requests"].values()),
                    "unique_query_ids_worker": len(set(i for ids in stats["unique_ids_by_category"].values() for i in ids)),
                    "actual_F_evaluations_worker": stats["actual_F_evaluations_this_worker"]}
            cost.update({f"requests_{k}": v for k, v in stats["requests"].items()})
            if lane == "B":
                actual = r["references"]["exact_F"]["timing_actual_F_evaluations"]
                cost["actual_F_timing_calls"] = actual
                cost["envelope_build_seconds"] = r["references"]["paper_oracle_envelope"]["construction"]["paper_build_seconds"]
                actual_timing_F += actual
            costs.append(cost)
    write_csv(out / "costs.csv", costs)
    rounds = []
    for b in B:
        original = by_id[b["job"]["model_id"]]
        for rnd in [{"round": 0, "added_n": 0, "monotonicity_violations": original["monotonicity_violations"],
                     "soundness_violations": original["soundness_violations"], "joined": original["joined"]}] + b["rounds"]:
            rounds.append({"model_id": b["job"]["model_id"], "round": rnd["round"], "new_inputs": rnd["added_n"],
                           "monotonicity_violations": rnd["monotonicity_violations"],
                           "soundness_violations": rnd["soundness_violations"],
                           "joined_failure": rnd["joined"]["analysis_failure"],
                           "joined_final_width": rnd["joined"]["final_width"]})
    write_csv(out / "repair_rounds.csv", rounds)
    method_summary = []
    for method in ["exact_F", "original", "paper_oracle_envelope", "repaired", "top", "legacy_input_join_envelope_diagnostic"]:
        group = [r for r in comparisons if r["method"] == method]
        method_summary.append({"method": method, "n": len(group),
                               "fully_certified": sum(not r["has_rule_violation"] for r in group),
                               "reliable_joined": sum(not r["joined_analysis_failure"] for r in group),
                               "joined_width_median_range": fmt_range([r["joined_final_width"] for r in group], 1),
                               "mean_output_width_median_range": fmt_range([r["mean_output_width"] for r in group], 2),
                               "true_proofs_median_range": fmt_range([r["joined_true_assertions_proved"] for r in group], 1),
                               "reliable_true_proofs_median_range": fmt_range([r["joined_true_assertions_proved"] for r in group if not r["joined_analysis_failure"]], 1)})
    write_csv(out / "method_summary.csv", method_summary)
    aggregate = {"batch_hash": manifest_hash, "planned_A": len(cfg["widths"]) * len(cfg["coverages"]) * len(cfg["seeds"]),
                 "planned_B": len(cfg["repair_coverages"]) * len(cfg["seeds"]),
                 "completed_A": len(A), "completed_B": len(B),
                 "statuses": dict(Counter(f"{r['lane']}:{r['status']}" for r in a_status + b_status)),
                 "A_rule_violations": sum(r["has_rule_violation"] for r in A),
                 "A_joined_failures": sum(r["joined"]["analysis_failure"] for r in A),
                 "A_false_proofs": sum(r["joined"]["false_proof_x_le_k_minus_1"] for r in A),
                 "A_direct_cycles": sum(r["direct"]["cycle"] for r in A),
                 "A_direct_failures": sum(r["direct"]["analysis_failure"] for r in A),
                 "A_test_accuracy": summary_range([r["accuracy"]["test"]["exact_rate"] for r in A]),
                 "A_carrier_accuracy": summary_range([r["accuracy"]["carrier"]["exact_rate"] for r in A]),
                 "B_certified": sum(not r["has_rule_violation"] for r in B),
                 "B_not_needed": sum(r["stop_reason"] == "not_needed" for r in B),
                 "B_newly_certified": sum(r["stop_reason"] == "certified" for r in B),
                 "B_joined_failures": sum(r["joined"]["analysis_failure"] for r in B),
                 "B_stop_reasons": dict(Counter(r["stop_reason"] for r in B)),
                 "actual_oracle_data_generation_calls": prep["F_evaluations"],
                 "actual_oracle_timing_calls": actual_timing_F,
                 "logical_oracle_requests_A_B": sum(c["logical_oracle_requests"] for c in costs),
                 "global_unique_oracle_states": prep["carrier_size"],
                 "training_seconds_A": sum(r["training"]["seconds"] for r in A),
                 "training_seconds_B": sum(t["training_seconds"] for r in B for t in r["rounds"]),
                 "worker_wall_seconds_A_B": sum(r["wall_seconds"] for r in A + B),
                 "neural_single_call_median_microseconds": statistics.median(r["inference_timing"]["single_input_median_seconds"]*1e6 for r in A),
                 "exact_single_call_median_microseconds": statistics.median(r["references"]["exact_F"]["direct_single_call_seconds"]*1e6 for r in B),
                 "envelope_build_median_milliseconds": statistics.median(r["references"]["paper_oracle_envelope"]["construction"]["paper_build_seconds"]*1e3 for r in B),
                 "fully_exact_A": sum(r["accuracy"]["carrier"]["exact_rate"] == 1 for r in A),
                 "fully_exact_B": sum(r["accuracy"]["carrier"]["exact_rate"] == 1 for r in B),
                 "constant_top_A_B": sum(all(p == [0, cfg["N"]] for p in r["predictions"]) for r in A + B),
                 "completed_repair_rounds": sum(len(r["rounds"]) for r in B),
                 "illegal_decoded_A_B": sum(r["invalid_decoded_outputs"] for r in A + B),
                 "illegal_independent_argmax_A_B": sum(r["invalid_independent_argmax_outputs"] for r in A + B),
                 "thresholds": thresholds, "methods": method_summary,
                 "scope": "core A/B only; smoke, original artifact replay, final verification and startup overhead are separate"}
    atomic_json(out / "aggregate.json", aggregate)
    draw_figures(A, B, groups, comparisons, rounds, costs, figures, manifest_hash)
    write_reports(root, out, cfg, prep, A, B, by_id, aggregate, groups, method_summary, manifest_hash)
    print(json.dumps(aggregate, indent=2))


def draw_figures(A, B, groups, comparisons, rounds, costs, target, batch):
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
    def save(fig, name):
        fig.text(.01, .006, "Source batch " + batch[:16] + "; descriptive, shared splits across widths", fontsize=7, color="gray")
        fig.tight_layout(rect=(0, .03, 1, 1))
        fig.savefig(target / (name + ".png"), dpi=170)
        fig.savefig(target / (name + ".pdf"))
        plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for fail, color, marker in [(False, "#16746b", "o"), (True, "#c14c35", "x")]:
        subset = [r for r in A if r["joined"]["analysis_failure"] == fail]
        for ax, key, label in zip(axes, ["monotonicity_violations", "soundness_violations"],
                                  ["Violating comparable pairs", "Inputs with soundness omission"]):
            ax.scatter([100*r["accuracy"]["test"]["exact_rate"] for r in subset], [r[key] for r in subset],
                       color=color, marker=marker, alpha=.8, label="Joined failure" if fail else "Joined reliable")
            ax.set(xlabel="Held-out test exact match (%)", ylabel=label)
    axes[0].legend()
    save(fig, "accuracy_and_laws")
    fig, ax = plt.subplots(figsize=(11, 4))
    x = np.arange(len(groups))
    ax.bar(x-.18, [g["law_violation_models"]/g["planned"] for g in groups], .36, label="Any rule violation")
    ax.bar(x+.18, [g["joined_failure_models"]/g["planned"] for g in groups], .36, label="Joined analysis failure")
    ax.set_xticks(x, [f"w{g['width']} / {int(g['coverage']*100)}%" for g in groups], rotation=35, ha="right")
    ax.set(ylabel="Fraction of 5 scheduled seeds", ylim=(0, 1.13))
    ax.legend(loc="upper right")
    save(fig, "configuration_frequencies")
    methods = ["exact_F", "original", "paper_oracle_envelope", "repaired", "top"]
    labels = ["Exact F", "Original", "Oracle envelope", "Retrained", "Top"]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    for i, method in enumerate(methods):
        group = [r for r in comparisons if r["method"] == method]
        axes[0].bar(i-.17, sum(not r["has_rule_violation"] for r in group), .34, color="#326ca5")
        axes[0].bar(i+.17, sum(not r["joined_analysis_failure"] for r in group), .34, color="#37a38c")
        jitter = np.linspace(-.13, .13, len(group))
        for ax, key in zip(axes[1:], ["joined_final_width", "joined_true_assertions_proved"]):
            for offset, r in zip(jitter, group):
                ax.scatter(i+offset, r[key], marker="x" if r["joined_analysis_failure"] else "o",
                           color="#c14c35" if r["joined_analysis_failure"] else "#16746b", alpha=.7)
    axes[0].set(ylabel="Count in fixed 10-model subset", title="Blue: certified; green: reliable joined")
    axes[1].set(ylabel="Final invariant width", title="Red x: unsound result")
    axes[2].set(ylabel="True assertions entailed (of 13)", title="Red x: proof basis is unsound")
    for ax in axes:
        ax.set_xticks(range(len(labels)), labels, rotation=35, ha="right")
    save(fig, "repair_comparison")
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for b in B:
        model_id = b["job"]["model_id"]
        group = [r for r in rounds if r["model_id"] == model_id]
        for ax, key in zip(axes, ["monotonicity_violations", "soundness_violations"]):
            ax.plot([r["round"] for r in group], [r[key] for r in group], marker=".", linewidth=1, label=model_id)
            ax.set(xlabel="Completed repair round (0 = original)", ylabel=key.replace("_", " "))
    axes[1].legend(fontsize=7, ncol=2)
    save(fig, "repair_rounds")
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    group = [c for c in costs if c["lane"] == "B"]
    x = np.arange(len(group))
    axes[0].bar(x, [c["logical_oracle_requests"] for c in group], color="#326ca5")
    axes[0].set(ylabel="Logical oracle/cache requests", title="All phases; unique domain states = 497")
    axes[1].bar(x, [c["train_seconds"] for c in group], color="#37a38c")
    axes[1].set(ylabel="Offline retraining seconds", title="Excludes process startup and checking")
    for ax in axes:
        ax.set_xticks(x, [c["model_id"] for c in group], rotation=45, ha="right")
    save(fig, "offline_costs")


def write_reports(root, out, cfg, prep, A, B, by_id, ag, groups, methods, batch):
    n, k = cfg["N"], cfg["K"]
    a_n, b_n = len(A), len(B)
    threshold_lines = "\n".join(f"| {t['accuracy_scope']} | {t['threshold']:.0%} | {t['n']} | {t['rule_violation_models']} | {t['joined_failure_models']} |" for t in ag["thresholds"])
    group_lines = "\n".join(f"| {g['width']} | {g['coverage']:.0%} | {g['completed']}/{g['planned']} | {g.get('test_accuracy_median', 0):.3f} [{g.get('test_accuracy_min', 0):.3f}, {g.get('test_accuracy_max', 0):.3f}] | {g['law_violation_models']} | {g['joined_failure_models']} |" for g in groups)
    method_lines = "\n".join(f"| {m['method']} | {m['fully_certified']}/{m['n']} | {m['reliable_joined']}/{m['n']} | {m['joined_width_median_range']} | {m['mean_output_width_median_range']} | {m['reliable_true_proofs_median_range']} |" for m in methods)
    repaired_lines = "\n".join(f"| {b['job']['model_id']} | {by_id[b['job']['model_id']]['monotonicity_violations']} → {b['monotonicity_violations']} | {by_id[b['job']['model_id']]['soundness_violations']} → {b['soundness_violations']} | {by_id[b['job']['model_id']]['joined']['final']} → {b['joined']['final']} | {len(b['rounds'])} | {b['stop_reason']} |" for b in B)
    failures = [r for r in A if r["joined"]["analysis_failure"]]
    representative = max(failures or A, key=lambda r: (r["accuracy"]["test"]["exact_rate"], r["job"]["model_id"])) if A else None
    rep_text = "无已完成模型。"
    if representative:
        r = representative
        example = r["examples"]["soundness"][:1]
        trace = [s["state"] for s in r["joined"]["trace"]]
        rep_text = (f"用于展示的模型为 `{r['job']['model_id']}`，选择规则为合并分析失败者中测试准确率最高者（仅选择展示，不改变统计样本）。"
                    f"测试完全一致率 {r['accuracy']['test']['exact_count']}/{r['accuracy']['test']['n']} = {r['accuracy']['test']['exact_rate']:.4f}，"
                    f"全 carrier 为 {r['accuracy']['carrier']['exact_rate']:.4f}。真实遗漏反例：`{example}`。"
                    f"合并轨迹：`{trace}`，最终 `{r['joined']['final']}`，覆盖真实可达 `[0,{k}]`：{r['joined']['covers_reachable']}，"
                    f"精确后固定点：{r['joined']['postfixed_exact_F']}。")
        atomic_json(out / "representative.json", {"model_id": r["job"]["model_id"], "rule_examples": r["examples"],
                    "joined": r["joined"], "direct": r["direct"], "selection": "highest test accuracy among joined failures, display only"})
    high = next(t for t in ag["thresholds"] if t["accuracy_scope"] == "test" and t["threshold"] == .95)
    high_text = (f"在预先指定的测试准确率 ≥95% 分组中有 {high['n']} 个模型，其中 {high['rule_violation_models']} 个存在规则违反，"
                 f"{high['joined_failure_models']} 个合并分析失败。" if high["n"] else
                 "没有模型达到预设的测试准确率 95% 门槛，因此本轮不能声称观察到按此门槛定义的‘高准确率但违规’。没有继续调参或降低门槛来制造这一结论。")
    originals = [by_id[b["job"]["model_id"]] for b in B]
    original_failed = sum(r["joined"]["analysis_failure"] for r in originals)
    repair_cases = [r for r in B if r["stop_reason"] == "certified"]
    certification_note = " ".join(f"新通过的 `{r['job']['model_id']}` 全 carrier 完全一致率为 {r['accuracy']['carrier']['exact_rate']:.4f}，平均输出宽度 {r['mean_output_width']:.4f}，最终范围 {r['joined']['final']}。" for r in repair_cases)
    adapted_high = [r for r in B if r["accuracy"]["carrier"]["exact_rate"] >= .98 and r["has_rule_violation"]]
    adapted_note = " ".join(f"修复后的 `{r['job']['model_id']}` 域内一致率 {r['accuracy']['carrier']['exact_rate']:.4f}，仍有 {r['monotonicity_violations']} 个单调违反对及 {r['soundness_violations']} 个可靠性遗漏输入，合并最终范围 {r['joined']['final']}。" for r in adapted_high)
    report = f"""# 真实学习区间转换器补充实验结果

2026 年 10 月 6 日，Australia/Sydney。本报告来自实际 CPU 运行，批次 `{batch}`。

实验 A 完成 {a_n}/{ag['planned_A']} 个真实训练模型；实验 B 完成固定子集 {b_n}/{ag['planned_B']} 个模型的反例引导修复流程。原始模型中 {ag['A_rule_violations']}/{a_n} 存在全域规则违反，{ag['A_joined_failures']}/{a_n} 在合并更新下分析失败。修复后 {ag['B_certified']}/{b_n} 通过完整有限域规则检查，{ag['B_joined_failures']}/{b_n} 仍有合并分析失败。修复过程执行完成不等于修复成功。

{high_text}

## 语义与原实验复现

直接导入原 `nonmonotone_interval_gate.py` 的 Interval、bottom、包含关系、join 和 `true_loop_function`。标签严格为 `F(a)=[0,0] join increment(a intersect [0,K-1])`，不是单独的赋值转换器。F 永远非 bottom，故两端点分类无需输出 bottom 类；输入仍有独立 bottom 标记。模型输入为 lo/N、hi/N、bottom 标记。模型为两层等宽 ReLU MLP，输出两组 N+1 类 logits，以分数和最大且 `0≤lo≤hi≤N` 解码，平分时按端点字典序。解码不接收 K，不使用 oracle，也不固定正确端点。

原 N=14、K=9、30 个人为缺陷候选的 paper-level gate 已独立落盘，metrics 与原文件完全一致；121 个状态和 3181 个可比有序对均包括 bottom，自反对计入。精确 F 与 top 在适用的单调性和可靠性检查下通过，故障候选被识别。原函数本身不必 inflationary；合并更新总是 inflationary。区间宽度为 `hi-lo+1`，bottom 宽度 0。steps 从 bottom 起统计真正状态变化，不包括最后确认稳定的调用；另报调用总数。原 scaling 脚本用 round(0.6N)，与论文 ceil 描述不同；本次 N14 明确 K9，主实验明确 N30/K18，未改原脚本来对数。

发现并保留包络定义差异：论文公式为 `join_{{b≤a}} T(b) join F(a)`，旧代码为 `a join join_{{b≤a}} T(b)`。主要控制使用论文的 oracle 公式，另列旧代码构造的诊断结果，绝不把两者混称同一实现；旧构造在任意新模型上不自动保证可靠性。论文原始代码、结果和正文未修改。

## 固定协议和样本口径

主域 N={n}、K={k}，含 {prep['carrier_size']} 个状态、{prep['ordered_pairs']} 个可比有序对。种子 0–4，宽度 16/32/64，覆盖率 20/50/80%，45 次训练。每个 split seed 对 carrier 做一次 NumPy 随机置换，所有比例向下取整：测试 74、验证 24、训练候选池 399；训练量 99、248、397，占全域 19.9195%、49.8994%、79.8793%，为同一候选池前缀。不同宽度复用相同划分。所有状态 ID、关键迭代状态是否入训练集均保存。

Adam 1e-3，batch size 64，最多 300 epochs，验证损失早停 patience 30；按验证损失最小值取 checkpoint。只进行了一次完整 smoke test，无基础配置调整。正式网格未按测试、违例或下游结果选模型或 checkpoint。每个模型 CPU 单线程、顺序执行；环境和源代码 SHA256 见 results/core。首个 smoke 模型不纳入 45 个正式统计。

train/validation/test exact match 各有独立分母；carrier 准确率单列。原始模型的 test 是未见样本。本次修复在整个有限域发现反例，可能纳入原 test 和 validation 状态；修复后的对应准确率只表示域内适配，不能解释为未见泛化。被纳入训练的 validation 状态从当轮早停集合删除，保留剩余验证样本；这些样本也已参与全域检查，因此亦不是独立认证证据。通过与否始终来自完整穷举。

## 实验 A 结果

| 宽度 | 覆盖率 | 完成/计划 | 测试准确率中位数 [最小,最大] | 有规则违反 | 合并失败 |
|---|---|---|---|---|---|
{group_lines}

测试准确率总体中位数和范围为 {fmt_range([r['accuracy']['test']['exact_rate'] for r in A],4)}；全 carrier 为 {fmt_range([r['accuracy']['carrier']['exact_rate'] for r in A],4)}。这里的跨配置汇总仅描述这 45 次相关实验，不构成 45 个独立随机样本的推断。每配置仅 5 个 seed，无显著性检验或置信区间。

| 准确率口径 | 阈值 | 模型数 | 有规则违反 | 合并失败 |
|---|---|---|---|---|
{threshold_lines}

0 表示无样本，不能解释为门槛以上模型安全。全域规则失败与实际循环失败分别计数。合并失败包括未收敛、未覆盖 `[0,K]` 或不是精确 F 的后固定点；直接更新额外报告。合并更新错误证明 `x≤K-1` 的模型为 {ag['A_false_proofs']}/{a_n}；直接更新出现循环 {ag['A_direct_cycles']}/{a_n}，失败 {ag['A_direct_failures']}/{a_n}。非收敛结果保持为空，不自动换成 top。

{rep_text}

## 实验 B 结果

固定使用宽度 32、覆盖率 20/80%、种子 0–4，不按原始成败挑选。每轮按状态 ID 升序取可靠性反例，再按字典序取单调性反例对，每对两个端点一并计算新增唯一输入预算；每轮最多 64 个。保留全部原训练数据，以相同监督损失训练，未加入复杂成对损失。每轮最多 100 epochs、patience 15，最多 5 轮。两轮连续无新增反例输入且综合违例未改善时停止；不按失败多少回选历史 checkpoint。所有轮次有 checkpoint、选择的反例、累计训练 ID、指标和轨迹。

| 原始模型 | 单调违反对 原→修复 | 可靠性遗漏输入 原→修复 | 合并最终范围 原→修复 | 轮数 | 停止原因 |
|---|---|---|---|---|---|
{repaired_lines}

固定子集中原始合并失败 {original_failed}/{b_n}，最终修复后 {ag['B_joined_failures']}/{b_n}。修复后规则零违反 {ag['B_certified']}/{b_n}，其中 {ag['B_not_needed']} 个原模型已通过、无需修复；真正由修复新通过 {ag['B_newly_certified']}/{b_n-ag['B_not_needed']} 个。停止原因 {ag['B_stop_reasons']}，实际执行 {ag['completed_repair_rounds']} 轮。保留所有未修复成功者；没有返回 top 冒充成功。

{certification_note} {adapted_note} 后一观察只是适配后的全域一致率，不是原始模型的未见测试结果，不能补作实验 A 的高准确率证据。

完整学成精确 F 的原模型为 {ag['fully_exact_A']} 个、修复模型为 {ag['fully_exact_B']} 个；恒 top 模型共 {ag['constant_top_A_B']} 个。两个无需修复的宽度32/覆盖率20%模型实际恒输出 `[0,18]`，以牺牲逐输入精度得到零规则违反；不能把这解释为学会了精确函数。另有修复出现违例增多或中间可靠、后续又不可靠，均在逐轮表中保留，未择优回退。

| 方法 | 全域通过 | 合并可靠 | 最终宽度中位数 [范围] | 全域平均宽度中位数 [范围] | 可靠结果所证真实断言数中位数 [范围] |
|---|---|---|---|---|---|
{method_lines}

真实断言为 `x≤c, c=K,…,N`，共 {n-k+1} 条。表中证明能力仅汇总最终可靠结果；CSV 另保存不可靠结果的语法蕴含数量，不能把这些当作可靠证明。精确 F 和 oracle 包络是控制，top 是无 oracle 的退化基线。`inference.py` 只读取输入、架构 N/width 和保存的权重，修复模型在线 oracle 调用为 0；离线标签、反例发现和认证明确依赖 F。

## 成本与运行状态

全域 truth cache 构造实际调用 F {ag['actual_oracle_data_generation_calls']} 次、唯一状态 {ag['global_unique_oracle_states']} 个；A/B 逻辑 oracle 或缓存请求合计 {ag['logical_oracle_requests_A_B']} 次。每阶段 requests、unique IDs 和缓存命中口径均保存在 JSON；后续训练、找反例、修复标签及评估复用同一不可变缓存，不重复实际计算 F。独立精确函数计时额外实际调用 F {ag['actual_oracle_timing_calls']} 次，不能与标签成本混淆。原实验复现、smoke 和最终审计另计，不计入 A/B 科学样本。

A 训练合计 {ag['training_seconds_A']:.3f} 秒，B 重训练合计 {ag['training_seconds_B']:.3f} 秒，A/B worker 内墙钟合计 {ag['worker_wall_seconds_A_B']:.3f} 秒，均不含父进程启动开销。单输入神经前向加合法解码、全 carrier 批量推理、规则检查、缓存上的迭代、包络构建与查表分别计时，详见 costs.csv 和原 JSON。包络查表时延不包括构造成本，构造成本明确另列；没有据此声称速度优于精确 F。绝对时间是这台机器上的微基准，不是稳定性能排名。

原模型单输入前向加解码中位数 {ag['neural_single_call_median_microseconds']:.2f} 微秒，精确 F 调用中位数 {ag['exact_single_call_median_microseconds']:.2f} 微秒；神经模型在此微基准上更慢。包络离线构造中位数 {ag['envelope_build_median_milliseconds']:.3f} 毫秒，另有共享 truth 构造成本。合法解码后非法区间 {ag['illegal_decoded_A_B']} 个；独立端点 argmax 的非法区间 {ag['illegal_independent_argmax_A_B']} 个（均以 55 个最终模型各自的全 carrier 输出为统计对象，允许跨模型重复输入）。参数量分别为 1390、3230、8446，无 GPU 推理或付费算力。

运行状态：`{ag['statuses']}`。未完成数量为 A={ag['planned_A']-a_n}，B={ag['planned_B']-b_n}；失败/超时保留在 statuses.csv，不从计划分母剔除。进程父级真正执行终止，配置上限 5 分钟、修复上限 15 分钟，总预算上限 4 小时，至少预留 20 分钟。实际工作远少于预算；可选 N50 未执行，未因追求显著或预期结论追加任务。

## 支持范围和交付

本实验评估的是这个有限单变量循环上的实际小型 MLP；训练错误并未手工注入，种子和划分未按结果挑选。自然违例支持在该配置下分别检查预测质量、全域规则和最终分析的必要性；不能推出真实 AI 的普遍失败率。未达到高准确率门槛时，不能借用全 carrier 数值或旧的人为缺陷数据补足主张。反例引导重训练是否产生完整认证的无在线 oracle 模型，以本表实际通过数为限；离线穷举仍可能比直接用精确函数更昂贵，也不等价于更大域或其他程序的保证。

完整原始/修复 checkpoint 在 `results/core/A` 和 `B`，每轮结果在 `B/*/round_*`；图表在 `results/core/summary/figures`；英文补充在 `PAPER_SUPPLEMENT_EN.md`。本报告、所有 CSV、图和英文稿均由同一 source_manifest 中的结果生成。最终重载、独立规则复核、oracle 禁用推理、超时终止和原文件保护检查见 `results/core/verification.json`。正式配置和复现命令见 README。
"""
    (HERE / "REPORT_ZH.md").write_text(report, encoding="utf-8")
    english = f"""# Draft Supplement Trained Predictors and Offline Repair

This supplement reports executed experiments for *Local Accuracy Is Not a Contract for Abstract Transformers*. It does not replace the planted-defect evidence. Source batch: `{batch}`. All numbers below are generated from the saved result files.

## Protocol

We reuse the artifact's finite interval semantics, including bottom, and learn the full loop functional F(a) = [0,0] join increment(a intersect [0,K-1]), with N={n} and K={k}. The carrier contains {prep['carrier_size']} states and {prep['ordered_pairs']} comparable ordered pairs, including reflexive pairs. F is always non-bottom. Two-hidden-layer ReLU MLPs of widths 16, 32, and 64 predict two categorical endpoints. A fixed maximum-score legal decoder enforces 0 <= lo <= hi <= N without using K, F, or a label table.

Seeds 0–4 define the data permutations and model initialization. Test and validation contain 74 and 24 states; nested training sets contain 99, 248, and 397 states (19.9195%, 49.8994%, and 79.8793% of the full carrier). Widths share splits. Training uses Adam at 0.001, batch size 64, at most 300 epochs, patience 30, and minimum validation loss for checkpoint selection. No hyperparameter adjustment followed the smoke run. No split, seed, or checkpoint was selected by violations or downstream behavior.

We completed {a_n}/{ag['planned_A']} scheduled fits. Test exact match had median/range {fmt_range([r['accuracy']['test']['exact_rate'] for r in A],4)}; full-carrier agreement, separately labeled, was {fmt_range([r['accuracy']['carrier']['exact_rate'] for r in A],4)}. Full-carrier checking found at least one monotonicity or soundness violation in {ag['A_rule_violations']}/{a_n} predictors. Joined iteration a <- a join T(a) failed to return a reachable-state-covering exact post-fixpoint in {ag['A_joined_failures']}/{a_n} cases; {ag['A_false_proofs']}/{a_n} entailed the false assertion x <= K-1. Direct updates are an additional deployment mode: {ag['A_direct_cycles']}/{a_n} cycled and {ag['A_direct_failures']}/{a_n} failed overall. A local omission is not counted as a downstream failure unless the actual run fails the stated criteria.

The prespecified >=95% held-out test group contains {high['n']} models, with {high['rule_violation_models']} law-violating and {high['joined_failure_models']} joined-failing models. Empty threshold groups provide no evidence about high-accuracy behavior. The complete 95%, 98%, and 99% counts, including separate carrier-based descriptive groups, are in accuracy_thresholds.csv. We do not lower the threshold or substitute carrier accuracy for held-out accuracy.

## Counterexample Guided Retraining

The fixed repair cohort comprises all ten width-32 models at 20% and 80% coverage, seeds 0–4; {b_n}/{ag['planned_B']} repair workflows completed. Each of at most five rounds retains the original data and adds at most 64 unique counterexample inputs in a deterministic order, using exact labels. Monotonicity-pair endpoints count separately against the budget. Each round trains for at most 100 epochs (patience 15); original validation states that become training inputs are excluded from checkpoint validation. No pairwise penalty or hand-written output repair is used. Two rounds with no new inputs and no improvement trigger stagnation. Final inference uses only the saved neural parameters and legal decoding, with zero online F calls.

After repair, {ag['B_certified']}/{b_n} models pass exhaustive monotonicity and soundness checks, including {ag['B_not_needed']} already-admissible originals and {ag['B_newly_certified']}/{b_n-ag['B_not_needed']} newly certified attempted repairs. We completed {ag['completed_repair_rounds']} retraining rounds. Joined analysis still fails in {ag['B_joined_failures']}/{b_n}, compared with {original_failed}/{b_n} original models in the matched cohort. Stopping reasons are {ag['B_stop_reasons']}. Unsuccessful repairs remain in every denominator and are never replaced with top. Repair is finite-domain adaptation and certification: original test states may be queried or added, so post-repair accuracy is not held-out generalization. The two already-admissible width-32/20% models constantly predict [0,18], trading pointwise precision for soundness; neither is an exact implementation of F.

| Method | Exhaustive pass | Reliable joined result | Final width median [range] | Mean output width median [range] | True assertions on reliable results median [range] |
|---|---|---|---|---|---|
{method_lines}

The manuscript's oracle envelope is join_{{b<=a}} T(b) join F(a); the archived implementation instead joins the input a. We preserve the original artifact, implement the manuscript formula as the primary oracle-backed reference, and report the archived construction separately as a diagnostic. Exact F and the oracle envelope are controls, not oracle-free neural repairs. There are {n-k+1} true assertions x<=c, K<=c<=N. Width/proof counts on unsound invariants are not credited as useful reliable analysis.

## Cost and Limits

The shared immutable truth cache costs {ag['actual_oracle_data_generation_calls']} actual F calls over {ag['global_unique_oracle_states']} unique states. Training, validation, counterexample discovery, repair labels, envelope construction, and final evaluation make {ag['logical_oracle_requests_A_B']} logical oracle/cache requests in total. Exact-function microbenchmarks add {ag['actual_oracle_timing_calls']} actual F calls, separately accounted. Original training and repair training take {ag['training_seconds_A']:.3f}s and {ag['training_seconds_B']:.3f}s, respectively, on a single CPU thread; worker-internal wall time totals {ag['worker_wall_seconds_A_B']:.3f}s, excluding process startup. Envelope construction cost is reported separately from lookup latency, and cached iteration time is distinguished from neural inference. We claim no speed advantage over exact F.

Median neural single-input forward-plus-decode latency is {ag['neural_single_call_median_microseconds']:.2f} microseconds versus {ag['exact_single_call_median_microseconds']:.2f} microseconds per exact F call; median envelope construction is {ag['envelope_build_median_milliseconds']:.3f} milliseconds, excluding shared truth generation. No original or repaired model exactly matches F on the complete carrier, and no neural model is constantly top. All {ag['illegal_decoded_A_B']} decoded-invalid outputs and {ag['illegal_independent_argmax_A_B']} independent-argmax invalid outputs are recorded over the 55 final model tables; these zero counts, when zero, reflect the actual evaluated outputs, not an assumed guarantee for the unconstrained argmax.

Statuses: {ag['statuses']}. The optional N=50 confirmation was not run. Five seeds per configuration support descriptive ranges only; shared splits and matched models are not independent trials for a population failure rate. This one-loop finite-domain experiment does not establish prevalence across learned analyzers, larger domains, or programs. Any claim of high-accuracy natural violations or successful neural repair must be limited to the observed threshold/cohort counts above. Original experiments and the main manuscript remain unchanged.
"""
    (HERE / "PAPER_SUPPLEMENT_EN.md").write_text(english, encoding="utf-8")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--root", required=True)
    generate(Path(p.parse_args().root).resolve())
