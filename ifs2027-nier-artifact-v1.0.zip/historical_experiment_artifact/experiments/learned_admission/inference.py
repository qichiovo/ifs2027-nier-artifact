"""Deployable inference: only inputs, architecture metadata and saved weights.

No imports of the original gate, oracle, dataset, or prediction table.
"""
from pathlib import Path
import torch
from torch import nn


class IntervalMLP(nn.Module):
    def __init__(self, n: int, width: int):
        super().__init__()
        self.n, self.width = n, width
        self.layers = nn.Sequential(nn.Linear(3, width), nn.ReLU(),
                                    nn.Linear(width, width), nn.ReLU(),
                                    nn.Linear(width, 2 * (n + 1)))

    def forward(self, x):
        return self.layers(x).reshape(-1, 2, self.n + 1)


def encode(states, n):
    # None is bottom. Its endpoints are placeholders, separated by the flag.
    return torch.tensor([[0., 0., 1.] if a is None else
                         [a[0] / n, a[1] / n, 0.] for a in states], dtype=torch.float32)


def decode(logits):
    """Maximum sum of endpoint logits subject only to 0 <= lo <= hi <= N.

    Flattened argmax resolves ties lexicographically. No loop bound is known.
    """
    size = logits.shape[-1]
    scores = logits[:, 0, :, None] + logits[:, 1, None, :]
    invalid = torch.ones((size, size), dtype=torch.bool).tril(-1)
    flat = scores.masked_fill(invalid, -torch.inf).flatten(1).argmax(1)
    return torch.stack((flat // size, flat % size), 1)


def load_model(path: str | Path):
    saved = torch.load(path, map_location="cpu", weights_only=True)
    model = IntervalMLP(saved["n"], saved["width"])
    model.load_state_dict(saved["state_dict"])
    model.eval()
    return model


@torch.inference_mode()
def predict(model, states):
    return decode(model(encode(states, model.n))).tolist()
