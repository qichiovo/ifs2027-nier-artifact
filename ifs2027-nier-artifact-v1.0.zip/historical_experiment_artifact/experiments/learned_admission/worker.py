"""One bounded training or repair job. Parent enforces wall-clock termination."""
from __future__ import annotations
import argparse
import copy
import os
from pathlib import Path
import random
import time
import traceback
import numpy as np
import torch
from torch import nn
from inference import IntervalMLP, load_model
from core import (Domain, Oracle, atomic_json, read_json, digest, code_hash,
                  assess, model_table, timing, envelopes, choose_counterexamples)


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)


def save_model(path, model, metadata):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    torch.save({"n": model.n, "width": model.width,
                "state_dict": model.state_dict(), "metadata": metadata}, tmp)
    os.replace(tmp, path)


def fit(model, d, labels, train_ids, val_ids, cfg, repair=False):
    if not val_ids:
        raise ValueError("No validation inputs remain outside adapted training data")
    start = time.perf_counter()
    opt = torch.optim.Adam(model.parameters(), lr=cfg["learning_rate"])
    loss_fn = nn.CrossEntropyLoss()
    target = torch.tensor(labels, dtype=torch.long)
    train_ids = torch.tensor(train_ids, dtype=torch.long)
    val_ids = torch.tensor(val_ids, dtype=torch.long)
    best_loss, best_epoch, stale = float("inf"), 0, 0
    best_state = None
    history = []
    max_epochs = cfg["repair_epochs"] if repair else cfg["epochs"]
    patience = cfg["repair_patience"] if repair else cfg["patience"]
    heartbeat = start
    for epoch in range(1, max_epochs + 1):
        model.train()
        perm = train_ids[torch.randperm(len(train_ids))]
        sum_loss = 0.
        for ids in perm.split(cfg["batch_size"]):
            out = model(d.x[ids])
            loss = loss_fn(out[:, 0], target[ids, 0]) + loss_fn(out[:, 1], target[ids, 1])
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            sum_loss += loss.item() * len(ids)
        model.eval()
        with torch.inference_mode():
            out = model(d.x[val_ids])
            val_loss = float(loss_fn(out[:, 0], target[val_ids, 0]) + loss_fn(out[:, 1], target[val_ids, 1]))
        history.append({"epoch": epoch, "train_loss": sum_loss / len(train_ids), "validation_loss": val_loss})
        if val_loss < best_loss - cfg["min_delta"]:
            best_loss, best_epoch, stale = val_loss, epoch, 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            stale += 1
        if time.perf_counter() - heartbeat >= 30:
            print(f"epoch {epoch}/{max_epochs}; best validation loss {best_loss:.6f}", flush=True)
            heartbeat = time.perf_counter()
        if stale >= patience:
            break
    model.load_state_dict(best_state)
    model.eval()
    return {"epochs_run": epoch, "best_epoch": best_epoch, "best_validation_loss": best_loss,
            "early_stopped": epoch < max_epochs, "seconds": time.perf_counter() - start,
            "history": history, "train_n": len(train_ids), "validation_n": len(val_ids)}


def evaluate_model(model, d, oracle, split):
    prediction, logits, batch_seconds = model_table(model, d)
    report = assess(d, prediction, oracle, split, logits=logits)
    report["batch_inference_seconds"] = batch_seconds
    report["inference_timing"] = timing(model, d)
    report["parameter_count"] = sum(p.numel() for p in model.parameters())
    report["parameter_bytes_float32"] = report["parameter_count"] * 4
    report["predictions"] = prediction.tolist()
    return report


def label_tensor(d, oracle, train_ids, val_ids, repair=False):
    # Only supervised / validation rows receive labels in the optimizer's tensor.
    out = np.zeros((d.size, 2), dtype=np.int64)
    out[train_ids] = oracle.get(train_ids, "repair_labels" if repair else "training_labels")
    out[val_ids] = oracle.get(val_ids, "validation_labels")
    return out


def train_job(job, cfg, root, out):
    d = Domain(cfg["N"], cfg["K"])
    oracle = Oracle(d, root / "truth.json")
    split = read_json(root / "splits" / f"seed_{job['seed']}.json")
    split["train"] = split["train_by_coverage"][str(job["coverage"]) ]
    model = IntervalMLP(d.n, job["width"])
    training = fit(model, d, label_tensor(d, oracle, split["train"], split["validation"]),
                   split["train"], split["validation"], cfg)
    save_model(out / "model.pt", model, job)
    reloaded = load_model(out / "model.pt")
    report = evaluate_model(reloaded, d, oracle, split)
    report["checkpoint_bytes"] = (out / "model.pt").stat().st_size
    report["training"] = training
    report["split"] = split
    report["key_iteration_states"] = [
        {"id": d.ids[GState], "state": d.inputs[d.ids[GState]],
         "in_training": d.ids[GState] in split["train"]}
        for GState in [d.states[0]] + [s for s in d.states if not s.is_bot and s.lo == 0 and s.hi <= d.k]]
    report["oracle"] = oracle.stats()
    atomic_json(out / "counterexamples.json", report["examples"])
    atomic_json(out / "training.json", training)
    return report


def repair_job(job, cfg, root, out):
    original_dir = root / "A" / job["model_id"]
    original = read_json(original_dir / "result.json")
    assert original["status"] == "completed"
    d = Domain(cfg["N"], cfg["K"])
    oracle = Oracle(d, root / "truth.json")
    split = copy.deepcopy(original["split"])
    model = load_model(original_dir / "model.pt")
    prediction, _, _ = model_table(model, d)
    assert prediction.tolist() == original["predictions"]
    truth = oracle.get(range(d.size), "reference_control")
    envelope_truth = oracle.get(range(d.size), "envelope_build")
    env, legacy, construction = envelopes(d, prediction, envelope_truth)
    references = {"exact_F": assess(d, truth, oracle, split),
                  "paper_oracle_envelope": assess(d, env, oracle, split),
                  "legacy_input_join_envelope_diagnostic": assess(d, legacy, oracle, split),
                  "top": assess(d, np.tile([0, d.n], (d.size, 1)), oracle, split)}
    references["paper_oracle_envelope"]["construction"] = construction
    references["paper_oracle_envelope"]["predictions"] = env.tolist()
    # Time actual callable references separately from cached iteration traversal.
    from core import G
    f_exact = lambda a: G.true_loop_function(a, d.k, d.n)
    timer = time.perf_counter()
    for _ in range(100):
        for a in d.states:
            f_exact(a)
    references["exact_F"]["direct_single_call_seconds"] = (time.perf_counter() - timer) / (100 * d.size)
    references["exact_F"]["timing_actual_F_evaluations"] = 100 * d.size
    timer = time.perf_counter()
    for _ in range(100):
        for i in range(d.size):
            _v = env[i]
    references["paper_oracle_envelope"]["lookup_seconds"] = (time.perf_counter() - timer) / (100 * d.size)
    atomic_json(out / "references.json", references)
    rounds = []
    stop_reason = "round_limit"
    stagnant = 0
    report = assess(d, prediction, oracle, split, category="counterexample_discovery")
    previous_score = report["monotonicity_violations"] + report["soundness_violations"]
    for round_no in range(1, cfg["repair_rounds"] + 1):
        if not report["has_rule_violation"]:
            stop_reason = "not_needed" if round_no == 1 else "certified"
            break
        added, sources = choose_counterexamples(report, d, set(split["train"]), cfg["repair_new_inputs"])
        split["train"] = sorted(set(split["train"]) | set(added))
        split["validation"] = sorted(set(original["split"]["validation"]) - set(split["train"]))
        if not split["validation"]:
            stop_reason = "validation_exhausted"
            break
        round_dir = out / f"round_{round_no}"
        round_dir.mkdir(parents=True, exist_ok=True)
        atomic_json(round_dir / "selected_counterexamples.json", {"added_ids": added, "sources": sources,
                     "before": report["examples"], "training_ids": split["train"],
                     "remaining_validation_ids": split["validation"]})
        seed_all(job["seed"] + 10000 * round_no)
        training = fit(model, d, label_tensor(d, oracle, split["train"], split["validation"], repair=True),
                       split["train"], split["validation"], cfg, repair=True)
        save_model(round_dir / "model.pt", model, {**job, "round": round_no})
        report = evaluate_model(load_model(round_dir / "model.pt"), d, oracle, split)
        report.update({"round": round_no, "added_ids": added, "training": training,
                       "split": copy.deepcopy(split), "oracle": oracle.stats(),
                       "status": "completed", "evaluation_scope": "finite-carrier adaptation and certification; original test IDs may be queried"})
        atomic_json(round_dir / "counterexamples.json", report["examples"])
        atomic_json(round_dir / "result.json", report)
        rounds.append({"round": round_no, "added_n": len(added), "monotonicity_violations": report["monotonicity_violations"],
                       "soundness_violations": report["soundness_violations"], "joined": report["joined"],
                       "training_seconds": training["seconds"], "oracle": oracle.stats()})
        print(f"repair round {round_no}: added={len(added)} mono={report['monotonicity_violations']} sound={report['soundness_violations']}", flush=True)
        new_score = report["monotonicity_violations"] + report["soundness_violations"]
        stagnant = stagnant + 1 if not added and new_score >= previous_score else 0
        previous_score = new_score
        if not report["has_rule_violation"]:
            stop_reason = "certified"
            break
        if stagnant >= 2:
            stop_reason = "stagnation"
            break
        # Reclassify the next full check as discovery, using the same frozen table.
        report = assess(d, np.asarray(report["predictions"]), oracle, split, category="counterexample_discovery")
    save_model(out / "model.pt", model, {**job, "rounds": len(rounds)})
    final = evaluate_model(load_model(out / "model.pt"), d, oracle, split)
    final.update({"rounds": rounds, "stop_reason": stop_reason, "split": split,
                  "original_test_ids_added_to_training": sorted(set(original["split"]["test"]) & set(split["train"])),
                  "original_validation_ids_added_to_training": sorted(set(original["split"]["validation"]) & set(split["train"])),
                  "oracle": oracle.stats(), "references": references,
                  "evaluation_scope": "finite-carrier adaptation and certification; test accuracy is not held-out generalization",
                  "online_oracle_calls": 0, "checkpoint_bytes": (out / "model.pt").stat().st_size})
    atomic_json(out / "counterexamples.json", final["examples"])
    return final


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", required=True)
    parser.add_argument("--root", required=True)
    args = parser.parse_args()
    job = read_json(args.job)
    root = Path(args.root).resolve()
    cfg = read_json(root / "config.lock.json")
    out = Path(args.job).parent
    seed_all(job["seed"])
    atomic_json(out / "status.json", {"status": "running", "job": job})
    start = time.perf_counter()
    try:
        report = train_job(job, cfg, root, out) if job["kind"] in ("train", "smoke") else repair_job(job, cfg, root, out)
        report.update({"status": "completed", "job": job, "config_hash": digest(cfg),
                       "code_hash": code_hash(), "wall_seconds": time.perf_counter() - start})
        atomic_json(out / "result.json", report)
        atomic_json(out / "status.json", {"status": "completed", "job": job,
                    "config_hash": digest(cfg), "code_hash": code_hash()})
        print(f"completed {job['model_id']} in {report['wall_seconds']:.2f}s", flush=True)
    except Exception:
        trace = traceback.format_exc()
        (out / "traceback.txt").write_text(trace, encoding="utf-8")
        atomic_json(out / "status.json", {"status": "failed", "job": job, "traceback": trace})
        raise


if __name__ == "__main__":
    main()
