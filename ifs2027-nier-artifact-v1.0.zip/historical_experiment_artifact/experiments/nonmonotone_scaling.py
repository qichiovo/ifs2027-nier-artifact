#!/usr/bin/env python3
"""Scaling + workflow-utility study for the finite-lattice gate.

Extends ``nonmonotone_interval_gate.py`` along the two axes reviewers asked for:

  1. Scaling: rerun the exhaustive law/fixpoint/envelope/top battery over a sweep
     of domain bounds N (and a proportional loop bound K), reporting wall-clock
     time and domain size at each N. This shows the phenomenon and the envelope
     repair are not artefacts of the smallest N.
  2. Utility, not just interval width: for an assertion family ``x <= c`` at the
     loop head, count how many *true* assertions each analysis (exact, monotone
     envelope, always-top, unconstrained learned) proves, and read the misses as
     false alarms. This replaces "mean interval width" with a workflow-facing
     precision/soundness readout: how many real assertions survive, and whether a
     learned invariant is unsound (proves a false assertion).

Deterministic, stdlib-only, no external data. Reuses the gate module verbatim so
the existing paper-level PASS verdict is unchanged.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import nonmonotone_interval_gate as G


def memoize(f, universe: list[G.Interval]):
    """Precompute ``{x: f(x)}`` over the universe so law_report / fixpoint do O(1)
    lookups. Without this the envelope (O(|U|) per call) makes law_report's
    O(|U|^2) monotonicity loop O(|U|^3); memoized it is O(|U|^2) like the rest."""
    table = {x: f(x) for x in universe}
    return lambda x: table.get(x, f(x))


def proves_leq(inv: G.Interval, c: int) -> bool:
    """Does invariant ``inv`` entail the assertion ``x <= c``?"""
    if inv.is_bot:
        return True  # unreachable head proves anything (vacuous)
    return inv.hi <= c


def assertion_utility(N: int, K: int, universe: list[G.Interval]) -> dict[str, object]:
    """Assertion-family utility at the loop head for ``while x < K: x := x+1``.

    The reachable head values are ``[0,K]``; a true assertion is ``x <= c`` with
    ``c >= K``. We report, per analysis, the invariant reached, proved-true count,
    false alarms (true assertions not proved), and whether the invariant is
    unsound (proves a false assertion ``x <= c`` with ``c < K``).
    """
    exact_f = lambda x: G.true_loop_function(x, K, N)
    exact_inv = G.iterate_fixpoint(exact_f, G.BOT, max_steps=N + 8)
    # exact reachable head interval is [0,K]
    reach = G.Interval(0, K)
    true_cs = [c for c in range(N + 1) if c >= K]         # assertions x<=c that hold
    false_cs = [c for c in range(N + 1) if c < K]         # assertions x<=c that are false

    def score(name: str, inv: G.Interval, sound_expected: bool) -> dict[str, object]:
        proved_true = sum(1 for c in true_cs if proves_leq(inv, c))
        false_alarms = len(true_cs) - proved_true
        # a *false* assertion x<=c (c<K) that the invariant "proves" => unsound
        unsound_proofs = sum(1 for c in false_cs if proves_leq(inv, c) and not proves_leq(reach, c))
        return {
            "analysis": name,
            "invariant": inv.to_json(),
            "assertions_total": len(true_cs),
            "assertions_proved": proved_true,
            "false_alarms": false_alarms,
            "false_alarm_rate": round(false_alarms / max(1, len(true_cs)), 4),
            "unsound_assertions_proved": unsound_proofs,
            "sound": unsound_proofs == 0,
        }

    # envelope and always-top invariants (envelope memoized: O(|U|) per raw call)
    env = memoize(G.monotone_envelope(G.make_learned_loop(0, K, N), universe), universe)
    env_inv = G.iterate_fixpoint(env, G.BOT, max_steps=N + 8)
    top_inv = G.iterate_fixpoint(G.always_top(N), G.BOT, max_steps=N + 8)
    # one representative learned model (seed 0) — may be unsound / cyclic
    learned = G.make_learned_loop(0, K, N)
    learned_fp = G.iterate_fixpoint(learned, G.BOT, max_steps=N + 8)

    def inv_of(fp: dict) -> G.Interval:
        if fp.get("status") == "converged":
            f = fp["fixpoint"]
            return G.BOT if f.get("kind") == "bottom" else G.Interval(f["lo"], f["hi"])
        return G.Interval(0, N)  # non-convergent: no usable invariant, treat as top-ish

    rows = [
        score("exact", inv_of(exact_inv), True),
        score("monotone_envelope", inv_of(env_inv), True),
        score("always_top", inv_of(top_inv), True),
    ]
    learned_row = score("learned_unconstrained", inv_of(learned_fp), False)
    learned_row["fixpoint_status"] = learned_fp.get("status")
    rows.append(learned_row)
    return {"N": N, "K": K, "reachable_head": reach.to_json(),
            "true_assertion_count": len(true_cs), "rows": rows}


def _table(f, universe: list[G.Interval]) -> list[tuple[int, int, bool]]:
    """Precompute (lo, hi, is_bot) for f over the universe (one eval per element)."""
    out = []
    for x in universe:
        v = f(x)
        out.append((v.lo, v.hi, v.is_bot))
    return out


def lean_law(U: list[tuple[int, int, bool]], F: list[tuple[int, int, bool]],
             T: list[tuple[int, int, bool]], N: int) -> dict[str, object]:
    """Exhaustive law report using precomputed integer tables (no per-cell function
    calls), so the O(|U|^2) monotonicity check stays fast at large N. leq semantics
    mirror the gate module exactly."""
    n = len(U)
    exact = 0
    width_sum = 0
    over = infl = mono = 0
    for i in range(n):
        la, ha, ba = U[i]
        fla, fha, fbi = F[i]
        tla, tha, tbi = T[i]
        width_sum += 0 if fbi else (fha - fla + 1)
        if (fla, fha, fbi) == (tla, tha, tbi):
            exact += 1
        # overapprox: true(x) <= f(x)
        if not (tbi or (not fbi and fla <= tla and tha <= fha)):
            over += 1
        # inflationarity: x <= f(x)
        if not (ba or (not fbi and fla <= la and ha <= fha)):
            infl += 1
    # monotonicity: for all a <= b, f(a) <= f(b)
    for i in range(n):
        la, ha, ba = U[i]
        fla, fha, fbi = F[i]
        for j in range(n):
            lb, hb, bb = U[j]
            # a <= b ?
            aleb = ba or (not bb and lb <= la and ha <= hb)
            if not aleb:
                continue
            flb, fhb, fbj = F[j]
            # f(a) <= f(b) ?
            faleb = fbi or (not fbj and flb <= fla and fha <= fhb)
            if not faleb:
                mono += 1
    return {"exact_rate": exact / n, "mean_width": width_sum / n,
            "mono": mono, "over": over, "infl": infl}


def scaling_point(N: int, K: int, seeds: int = 12) -> dict[str, object]:
    universe = G.intervals(N)
    U = [(iv.lo, iv.hi, iv.is_bot) for iv in universe]
    ordered_pairs = sum(1 for a in U for b in U
                        if a[2] or (not b[2] and b[0] <= a[0] and a[1] <= b[1]))
    exact_f = lambda x: G.true_loop_function(x, K, N)
    Ttab = _table(exact_f, universe)
    t0 = time.process_time()
    exact_rates, monos, overs = [], [], []
    unsound = cyclic = 0
    for s in range(seeds):
        learned = G.make_learned_loop(s, K, N)
        rep = lean_law(U, _table(learned, universe), Ttab, N)
        exact_rates.append(rep["exact_rate"]); monos.append(rep["mono"]); overs.append(rep["over"])
        fp = G.iterate_fixpoint(learned, G.BOT, max_steps=N + 8)
        if fp.get("status") == "converged" and fp.get("fixpoint") != G.Interval(0, K).to_json():
            unsound += 1
        if fp.get("status") == "cycle":
            cyclic += 1
    env = memoize(G.monotone_envelope(G.make_learned_loop(0, K, N), universe), universe)
    env_rep = lean_law(U, _table(env, universe), Ttab, N)
    env_fp = G.iterate_fixpoint(env, G.BOT, max_steps=N + 8)
    top_rep = lean_law(U, _table(G.always_top(N), universe), Ttab, N)
    elapsed = time.process_time() - t0
    util = assertion_utility(N, K, universe)
    mono_min = min(monos); over_min = min(overs); exact_min = min(exact_rates)
    return {
        "N": N, "K": K, "intervals": len(universe),
        "ordered_pairs": ordered_pairs,
        "seeds": seeds,
        "seconds": round(elapsed, 3),
        "learned_exact_rate_min": round(exact_min, 4),
        "learned_monotonicity_violations_min": mono_min,
        "learned_overapprox_violations_min": over_min,
        "unsound_fixpoint_seeds": unsound,
        "cyclic_fixpoint_seeds": cyclic,
        "phenomenon_holds": bool(exact_min >= 0.95 and mono_min > 0 and over_min > 0
                                 and unsound >= 1 and cyclic >= 1),
        "envelope_sound": bool(env_rep["mono"] == 0 and env_rep["over"] == 0
                               and env_rep["infl"] == 0 and env_fp.get("status") == "converged"),
        "envelope_mean_width": round(float(env_rep["mean_width"]), 4),
        "always_top_mean_width": round(float(top_rep["mean_width"]), 4),
        "envelope_width_ratio_vs_top": round(float(env_rep["mean_width"])
                                             / float(top_rep["mean_width"]), 4),
        "utility": util,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="results")
    ap.add_argument("--bounds", default="14,30,50,100",
                    help="comma-separated N sweep; K defaults to round(0.6*N)")
    ap.add_argument("--seeds", type=int, default=12)
    args = ap.parse_args()
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    Ns = [int(x) for x in args.bounds.split(",") if x.strip()]
    points = []
    for N in Ns:
        K = max(3, round(0.6 * N))
        p = scaling_point(N, K, seeds=args.seeds)
        points.append(p)
        print(json.dumps({"N": N, "K": K, "intervals": p["intervals"],
                          "seconds": p["seconds"], "phenomenon_holds": p["phenomenon_holds"],
                          "envelope_sound": p["envelope_sound"]}, sort_keys=True), flush=True)
    doc = {
        "schema_version": "nonmonotone_scaling_v1",
        "idea_id": G.IDEA_ID,
        "description": ("Exhaustive finite-lattice battery over a sweep of interval bounds N, "
                        "with wall-clock time and an assertion-family utility readout "
                        "(proved assertions, false alarms, soundness) replacing mean interval width."),
        "seeds": args.seeds,
        "points": points,
        "all_phenomena_hold": all(p["phenomenon_holds"] for p in points),
        "all_envelopes_sound": all(p["envelope_sound"] for p in points),
    }
    (out / "scaling_metrics.json").write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n",
                                              encoding="utf-8")
    print(json.dumps({"all_phenomena_hold": doc["all_phenomena_hold"],
                      "all_envelopes_sound": doc["all_envelopes_sound"],
                      "out": str(out / "scaling_metrics.json")}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
