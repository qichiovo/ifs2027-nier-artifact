"""Per-model records, the three result classes and the summary of a trained grid.

Reads a result directory written by the main worker (config.lock.json, truth.json,
A/*/result.json, A/*/model.pt). For every model it reloads the checkpoint, replays
joined iteration from the model's own outputs without the oracle, makes the
post-fixpoint check with one call of the exact operator, and builds the envelope.
Every quantity the worker also recorded is compared with the worker's record.
The step of the loop is read from the configuration and defaults to 1.

Run:  python -B evaluate.py --root results/grid --out results/evaluation
Read only with respect to --root.
"""
from __future__ import annotations
import argparse
import csv
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

HERE = Path(__file__).resolve().parent
LEARNED = HERE.parent / 'learned_admission'
sys.dont_write_bytecode = True
sys.path.insert(0, str(LEARNED))
import numpy as np
import torch
from inference import load_model
from core import G, Domain, model_table, envelopes, rules, atomic_json, read_json
from loop import loop_function

torch.set_num_threads(1)
CLASSES = ('sound_accepted', 'sound_rejected', 'unsound')


def state(a):
    return None if a.is_bot else [a.lo, a.hi]


def interval(v):
    return G.BOT if v is None else G.Interval(int(v[0]), int(v[1]))


def rollout(d, table):
    """Joined iteration from bottom over a table of outputs. No oracle is involved."""
    current, seen, trace = G.BOT, set(), []
    for _ in range(d.size + 1):
        if current in seen:
            return {'status': 'cycle', 'final': None, 'trace': trace}
        seen.add(current)
        output = interval(table[d.ids[current]])
        nxt = G.join(current, output)
        trace.append({'state': state(current), 'output': state(output), 'next': state(nxt)})
        if nxt == current:
            return {'status': 'converged', 'final': state(current), 'trace': trace}
        current = nxt
    return {'status': 'step_limit', 'final': None, 'trace': trace}


def relation(output, exact):
    """How a model output relates to the exact one."""
    if output == exact:
        return 'exact'
    return 'wider' if G.leq(exact, output) else 'omission'


def evaluate_model(folder, d, truth, step, expected_envelope_final):
    source = read_json(folder / 'result.json')
    assert source['status'] == 'completed'
    job, split = source['job'], source['split']
    model = load_model(folder / 'model.pt')
    prediction, _, _ = model_table(model, d)
    assert prediction.tolist() == source['predictions'], 'Reloaded outputs differ from the worker\'s record'
    equal = np.all(prediction == truth, axis=1)
    accuracy = {name: {'n': len(ids), 'exact_count': int(equal[ids].sum()), 'exact_rate': float(equal[ids].mean())}
                for name, ids in [('test', split['test']), ('full_domain', list(range(d.size)))]}
    assert accuracy['test']['exact_count'] == source['accuracy']['test']['exact_count']
    assert accuracy['full_domain']['exact_count'] == source['accuracy']['carrier']['exact_count']
    omissions = np.flatnonzero((prediction[:, 0] > truth[:, 0]) | (prediction[:, 1] < truth[:, 1]))
    law = rules(d, prediction, truth)
    assert law['soundness_violations'] == len(omissions) == source['soundness_violations']
    assert law['monotonicity_violations'] == source['monotonicity_violations']

    run = rollout(d, prediction)
    assert run['status'] == source['joined']['status'] and run['final'] == source['joined']['final']
    record = {'model_id': job['model_id'], 'width': job['width'], 'coverage': job['coverage'], 'seed': job['seed'],
              'accuracy': accuracy,
              'pointwise_soundness_rate': 1 - len(omissions) / d.size,
              'omission_inputs': int(len(omissions)), 'monotonicity_violations': int(law['monotonicity_violations']),
              'comparable_pairs': int(law['ordered_pairs']),
              'coverage_pass': len(omissions) == 0,
              'global_pass': len(omissions) == 0 and law['monotonicity_violations'] == 0,
              'joined_status': run['status'], 'joined_terminated': run['status'] == 'converged',
              'final_invariant': run['final'], 'training_seconds': source['training']['seconds'],
              'epochs_run': source['training']['epochs_run']}
    if run['status'] == 'converged':
        final = interval(run['final'])
        image = loop_function(final, d.k, d.n, step)                # the one call of the post-fixpoint check
        sound, accepted = G.leq(G.Interval(0, d.k), final), G.leq(image, final)
        assert accepted == source['joined']['postfixed_exact_F'] and sound == source['joined']['covers_reachable']
        assert sound or not accepted, 'An unsound result was accepted'
        index = d.ids[final]
        record.update({'sound': sound, 'accepted': accepted,
                       'class': 'sound_accepted' if sound and accepted else 'sound_rejected' if sound else 'unsound',
                       'F_of_final': state(image),
                       'at_final': {'input': run['final'], 'model_output': prediction[index].tolist(),
                                    'exact_output': truth[index].tolist(),
                                    'relation': relation(interval(prediction[index]), interval(truth[index])),
                                    'input_in_training_set': index in split['train'],
                                    'input_in_test_set': index in split['test']}})
    else:
        record.update({'sound': False, 'accepted': False, 'class': 'unsound', 'F_of_final': None, 'at_final': None})
    # The path: every state visited, the model's output there and the exact one.
    record['path'] = []
    for entry in run['trace']:
        index = d.ids[interval(entry['state'])]
        record['path'].append({'state': entry['state'], 'model_output': entry['output'], 'exact_output': truth[index].tolist(),
                               'relation': relation(interval(entry['output']), interval(truth[index])),
                               'next': entry['next'], 'in_training_set': index in split['train']})
    record['path_omissions'] = sum(e['relation'] == 'omission' for e in record['path'])
    record['omissions_off_path'] = record['omission_inputs'] - record['path_omissions']

    # Envelope E(a) = join of T(b) over b below a, joined with F(a); its joined iteration.
    envelope, _, _ = envelopes(d, prediction, truth)
    envelope_law = rules(d, envelope, truth)
    assert envelope_law['soundness_violations'] == envelope_law['monotonicity_violations'] == 0, 'Envelope violates a law'
    envelope_run = rollout(d, envelope)
    assert envelope_run['status'] == 'converged'
    envelope_final = interval(envelope_run['final'])
    assert G.leq(G.Interval(0, d.k), envelope_final) and G.leq(loop_function(envelope_final, d.k, d.n, step), envelope_final)
    assert G.leq(interval(expected_envelope_final), envelope_final), 'Envelope result below the exact least solution'
    wider = np.flatnonzero((envelope[:, 1] - envelope[:, 0]) > (truth[:, 1] - truth[:, 0]))
    record['envelope'] = {'final': envelope_run['final'], 'equals_expected': envelope_run['final'] == expected_envelope_final,
                          'inputs_wider_than_exact': int(len(wider))}
    if not record['envelope']['equals_expected']:
        first = next(e for e in envelope_run['trace'] if e['output'] != truth[d.ids[interval(e['state'])]].tolist())
        below = d.subsets[d.ids[interval(first['state'])]]
        cause = int(next(b for b in below if prediction[b, 1] > truth[d.ids[interval(first['state'])], 1]
                         or prediction[b, 0] < truth[d.ids[interval(first['state'])], 0]))
        record['envelope']['first_wider_state'] = {'state': first['state'], 'envelope_output': first['output'],
                                                   'exact_output': truth[d.ids[interval(first['state'])]].tolist(),
                                                   'caused_by_input': d.inputs[cause], 'model_output_there': prediction[cause].tolist()}
    return record


def percent(rate):
    return round(100 * rate, 2)


def summarize(models, d, step, expected_envelope_final, thresholds):
    ranked =sorted(models, key=lambda m: (-m['accuracy']['test']['exact_count'], m['model_id']))
    for position, model in enumerate(ranked, 1):
        model['accuracy_rank'] = 1 + sum(o['accuracy']['test']['exact_count'] > model['accuracy']['test']['exact_count'] for o in ranked)
        model['accuracy_order'] = position
    brief = lambda m: {'model_id': m['model_id'], 'heldout_exact_percent': percent(m['accuracy']['test']['exact_rate']),
                       'heldout_exact': f"{m['accuracy']['test']['exact_count']}/{m['accuracy']['test']['n']}",
                       'full_domain_exact_percent': percent(m['accuracy']['full_domain']['exact_rate']),
                       'accuracy_rank': m['accuracy_rank'], 'omission_inputs': m['omission_inputs'],
                       'monotonicity_violations': m['monotonicity_violations'], 'coverage_pass': m['coverage_pass'],
                       'global_pass': m['global_pass'], 'final_invariant': m['final_invariant'], 'class': m['class'],
                       'at_final': m['at_final'], 'path_omissions': m['path_omissions']}
    count = lambda rows: {c: sum(m['class'] == c for m in rows) for c in CLASSES}
    by_configuration = []
    for width in sorted({m['width'] for m in models}):
        for coverage in sorted({m['coverage'] for m in models}):
            rows = [m for m in models if m['width'] == width and m['coverage'] == coverage]
            rates = [m['accuracy']['test']['exact_rate'] for m in rows]
            by_configuration.append({'width': width, 'coverage_target_percent': int(round(coverage * 100)), 'models': len(rows),
                                     'heldout_exact_percent_median': percent(statistics.median(rates)),
                                     'heldout_exact_percent_min': percent(min(rates)), 'heldout_exact_percent_max': percent(max(rates)),
                                     'coverage_pass': sum(m['coverage_pass'] for m in rows),
                                     'global_pass': sum(m['global_pass'] for m in rows), **count(rows)})
    third = ranked[min(2, len(ranked) - 1)]['accuracy']['test']['exact_count']
    rates = [m['accuracy']['test']['exact_rate'] for m in models]
    return {
        'N': d.n, 'K': d.k, 'step': step, 'inputs': d.size, 'models': len(models),
        'expected_envelope_final': expected_envelope_final,
        'totals': {'coverage_pass': sum(m['coverage_pass'] for m in models), 'global_pass': sum(m['global_pass'] for m in models),
                   'accepted': sum(m['accepted'] for m in models), 'sound': sum(m['sound'] for m in models),
                   'joined_terminated': sum(m['joined_terminated'] for m in models),
                   'accepted_with_law_violation': sum(m['accepted'] and not m['global_pass'] for m in models),
                   'sound_with_law_violation': sum(m['sound'] and not m['global_pass'] for m in models),
                   'unsound_with_global_pass': sum(not m['sound'] and m['global_pass'] for m in models),
                   'heldout_exact_percent_median': percent(statistics.median(rates)),
                   'heldout_exact_percent_min': percent(min(rates)), 'heldout_exact_percent_max': percent(max(rates)),
                   **count(models)},
        'final_invariants': {key: sum(json.dumps(m['final_invariant']) == key for m in models)
                             for key in sorted({json.dumps(m['final_invariant']) for m in models},
                                               key=lambda text: (json.loads(text) or [-1, -1])[::-1])},
        'by_configuration': by_configuration,
        'at_or_above_heldout_threshold': {str(int(round(t * 100))): {
            'models': sum(r >= t for r in rates),
            'with_law_violation': sum(m['accuracy']['test']['exact_rate'] >= t and not m['global_pass'] for m in models),
            'unsound': sum(m['accuracy']['test']['exact_rate'] >= t and not m['sound'] for m in models)} for t in thresholds},
        'primary_sound_but_rejected':[brief(m) for m in ranked if m['class'] == 'sound_rejected'],
        'top_models_by_heldout_accuracy': [brief(m) for m in ranked if m['accuracy']['test']['exact_count'] >= third],
        'models_passing_both_laws': [brief(m) for m in ranked if m['global_pass']],
        'models_passing_coverage': [brief(m) for m in ranked if m['coverage_pass']],
        'unsound_models': [brief(m) for m in ranked if m['class'] == 'unsound'],
        'envelope': {'equal_to_expected': sum(m['envelope']['equals_expected'] for m in models),
                     'others': [{'model_id': m['model_id'], **m['envelope']} for m in ranked if not m['envelope']['equals_expected']]},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=str(HERE / 'results' / 'grid'))
    parser.add_argument('--out', default=str(HERE / 'results' / 'evaluation'))
    args = parser.parse_args()
    start = time.perf_counter()
    root, out = Path(args.root).resolve(), Path(args.out).resolve()
    assert LEARNED not in out.parents, 'Evaluation output must not go under learned_admission'
    cfg = read_json(root / 'config.lock.json')
    step = cfg.get('step', 1)
    d = Domain(cfg['N'], cfg['K'])
    saved = read_json(root / 'truth.json')
    truth = np.array([state(loop_function(a, d.k, d.n, step)) for a in d.states], dtype=np.int64)
    assert saved['outputs'] == truth.tolist() and saved['inputs'] == d.inputs, 'Oracle table differs from the exact operator'
    expected = rollout(d, truth)['final']                       # the exact operator's own joined result
    folders = sorted(p.parent for p in (root / 'A').glob('*/result.json'))
    expected_ids = [f'w{w}_c{int(c*100)}_s{s}' for w in cfg['widths'] for c in cfg['coverages'] for s in cfg['seeds']]
    models = [evaluate_model(folder, d, truth, step, expected) for folder in folders]
    summary = summarize(models, d, step, expected, cfg['thresholds'])
    summary.update({'root': str(root), 'grid_complete': sorted(m['model_id'] for m in models) == sorted(expected_ids),
                    'missing_models': sorted(set(expected_ids) - {m['model_id'] for m in models}),
                    'evaluated_at': datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
                    'evaluation_seconds': time.perf_counter() - start,
                    'evaluate_py_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    'python': sys.version, 'torch': torch.__version__, 'numpy': np.__version__})
    out.mkdir(parents=True, exist_ok=True)
    atomic_json(out / 'models.json', models)
    atomic_json(out / 'summary.json', summary)
    with (out / 'models.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(['model_id', 'width', 'coverage', 'seed', 'heldout_exact', 'heldout_n', 'heldout_rate', 'full_domain_exact',
                         'full_domain_rate', 'pointwise_soundness_rate', 'omission_inputs', 'monotonicity_violations',
                         'coverage_pass', 'global_pass', 'joined_status', 'final_invariant', 'sound', 'accepted', 'class',
                         'accuracy_rank', 'envelope_final'])
        for m in sorted(models, key=lambda m: m['accuracy_order']):
            writer.writerow([m['model_id'], m['width'], m['coverage'], m['seed'], m['accuracy']['test']['exact_count'],
                             m['accuracy']['test']['n'], f"{m['accuracy']['test']['exact_rate']:.6f}",
                             m['accuracy']['full_domain']['exact_count'], f"{m['accuracy']['full_domain']['exact_rate']:.6f}",
                             f"{m['pointwise_soundness_rate']:.6f}", m['omission_inputs'], m['monotonicity_violations'],
                             m['coverage_pass'], m['global_pass'], m['joined_status'], json.dumps(m['final_invariant']),
                             m['sound'], m['accepted'], m['class'], m['accuracy_rank'], json.dumps(m['envelope']['final'])])
    print(json.dumps({k: summary[k] for k in ('models', 'grid_complete', 'totals', 'final_invariants')}, indent=1))
    print('envelope equal to expected', summary['expected_envelope_final'], ':', summary['envelope']['equal_to_expected'], 'of', len(models))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
