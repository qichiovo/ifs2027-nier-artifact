"""Sequential supervised runner with real subprocess timeouts and atomic results."""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import numpy as np
from core import HERE, G, Domain, atomic_json, read_json, digest, code_hash, Oracle, rules, iterate

GIT = Path(r"<local path>")


def prepare(root, config, resume):
    root.mkdir(parents=True, exist_ok=True)
    cfg = read_json(config)
    config_path = root / "config.lock.json"
    if config_path.exists():
        if not resume:
            raise RuntimeError("Existing run; specify --resume or a new --out directory")
        assert read_json(config_path) == cfg, "Configuration hash mismatch"
        assert read_json(root / "preparation.json")["code_hash"] == code_hash(), "Code changed: use new output directory"
        return cfg
    start = time.perf_counter()
    d = Domain(cfg["N"], cfg["K"])
    outputs = [[G.true_loop_function(a, d.k, d.n).lo, G.true_loop_function(a, d.k, d.n).hi] for a in []]
    # Exactly one actual oracle evaluation per carrier state.
    t0 = time.perf_counter()
    outputs = []
    for a in d.states:
        v = G.true_loop_function(a, d.k, d.n)
        assert not v.is_bot
        outputs.append([v.lo, v.hi])
    construction_seconds = time.perf_counter() - t0
    atomic_json(root / "truth.json", {"N": d.n, "K": d.k, "inputs": d.inputs, "outputs": outputs,
                                    "F_evaluations": d.size, "construction_seconds": construction_seconds})
    for seed in cfg["seeds"]:
        ids = np.random.default_rng(seed).permutation(d.size).tolist()
        nt, nv = int(d.size * cfg["test_fraction"]), int(d.size * cfg["validation_fraction"])
        test, validation, pool = ids[:nt], ids[nt:nt + nv], ids[nt + nv:]
        trains = {str(c): pool[:min(int(c * d.size), len(pool))] for c in cfg["coverages"]}
        assert all(not (set(t) & (set(test) | set(validation))) for t in trains.values())
        atomic_json(root / "splits" / f"seed_{seed}.json", {"seed": seed, "test": test,
                    "validation": validation, "pool": pool, "train_by_coverage": trains,
                    "counts": {"carrier": d.size, "test": nt, "validation": nv,
                               "training": {c: len(v) for c, v in trains.items()}},
                    "rounding": "floor all fractions of complete carrier; prefixes of one permuted pool"})
    paper = HERE.parent.parent
    repo = paper.parent.parent
    git = str(GIT) if GIT.exists() else "git"
    def git_output(*args):
        try:
            return subprocess.check_output([git, *args], cwd=repo, text=True, stderr=subprocess.STDOUT).strip()
        except Exception as e:
            return repr(e)
    baseline = {str(p.relative_to(paper)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in paper.rglob("*") if p.is_file() and HERE not in p.parents and "__pycache__" not in p.parts}
    atomic_json(root / "baseline_hashes.json", baseline)
    hardware_cmd = "Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json; Get-CimInstance Win32_OperatingSystem | Select-Object TotalVisibleMemorySize,FreePhysicalMemory | ConvertTo-Json; Get-CimInstance Win32_VideoController | Select-Object Name | ConvertTo-Json"
    hardware = subprocess.run(["powershell", "-NoProfile", "-Command", hardware_cmd], capture_output=True, text=True).stdout if os.name == "nt" else platform.processor()
    versions = {x: importlib.metadata.version(x) for x in ("torch", "numpy", "matplotlib")}
    atomic_json(root / "environment.json", {"python": sys.version, "executable": sys.executable,
                "platform": platform.platform(), "hardware": hardware, "packages": versions,
                "git_commit": git_output("rev-parse", "HEAD"), "git_branch": git_output("branch", "--show-current"),
                "git_status_before": git_output("status", "--short"), "device": "CPU", "threads": 1,
                "branch_decision": "Keep shared branch unchanged to protect concurrent another paper work; no remote actions",
                "timezone_for_reports": "Australia/Sydney", "date": "2026-10-06"})
    atomic_json(config_path, cfg)
    atomic_json(root / "preparation.json", {"code_hash": code_hash(), "config_hash": digest(cfg),
                "F_evaluations": d.size, "F_unique_queries": d.size, "ordered_pairs": len(d.left),
                "carrier_size": d.size, "truth_construction_seconds": construction_seconds,
                "preparation_seconds": time.perf_counter() - start,
                "scope": "reuses original Interval/BOT/leq/join/F exactly; paper envelope differs from legacy code"})
    for filename in ("core.py", "inference.py", "worker.py", "run.py"):
        destination = root / "source_snapshot" / filename
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((HERE / filename).read_bytes())
    return cfg


def supervise(command, cwd, log, limit, deadline):
    env = os.environ.copy()
    env.update({"OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
                "NUMEXPR_NUM_THREADS": "1", "PYTHONHASHSEED": "0", "PYTHONDONTWRITEBYTECODE": "1"})
    start = time.monotonic()
    hard_end = min(start + limit, deadline)
    with Path(log).open("w", encoding="utf-8") as stream:
        child = subprocess.Popen(command, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, env=env)
        heartbeat = start
        try:
            while child.poll() is None:
                now = time.monotonic()
                if now >= hard_end:
                    child.kill()
                    child.wait()
                    return "timeout", time.monotonic() - start
                if now - heartbeat >= 30:
                    print(f"heartbeat pid={child.pid} elapsed={now-start:.0f}s remaining_global={deadline-now:.0f}s", flush=True)
                    heartbeat = now
                time.sleep(min(0.5, max(0.01, hard_end - now)))
        finally:
            if child.poll() is None:
                child.kill()
                child.wait()
    return ("completed" if child.returncode == 0 else "failed"), time.monotonic() - start


def execute_job(root, cfg, job, deadline, resume):
    folder = "B" if job["kind"] == "repair" else "smoke" if job["kind"] == "smoke" else "A"
    out = root / folder / job["model_id"]
    out.mkdir(parents=True, exist_ok=True)
    result = out / "result.json"
    status_path = out / "status.json"
    if resume and result.exists() and status_path.exists():
        saved, status = read_json(result), read_json(status_path)
        if saved.get("status") == status.get("status") == "completed":
            assert saved["config_hash"] == digest(cfg) and saved["code_hash"] == code_hash()
            assert (out / "model.pt").is_file()
            print(f"resume skip {folder}/{job['model_id']}", flush=True)
            return "completed"
    # Failed / interrupted attempts remain intact. Explicit --resume can retry once.
    attempts = read_json(out / "attempts.json") if (out / "attempts.json").exists() else []
    if len(attempts) >= 2:
        print(f"retry cap reached {folder}/{job['model_id']}", flush=True)
        return read_json(status_path)["status"]
    limit = cfg["repair_timeout_seconds"] if folder == "B" else cfg["training_timeout_seconds"]
    if deadline - time.monotonic() < limit:
        atomic_json(status_path, {"status": "not_started_budget", "job": job})
        return "not_started_budget"
    atomic_json(out / "job.json", job)
    if attempts:
        atomic_json(out / f"prior_status_attempt_{len(attempts)}.json", read_json(status_path))
    command = [sys.executable, str(HERE / "worker.py"), "--job", str(out / "job.json"), "--root", str(root)]
    state, elapsed = supervise(command, HERE, out / f"run_{len(attempts) + 1}.log", limit, deadline)
    attempts.append({"status": state, "seconds": elapsed, "command": command,
                     "reason": "initial scheduled attempt" if not attempts else "explicit resume after incomplete prior attempt"})
    atomic_json(out / "attempts.json", attempts)
    if state != "completed":
        atomic_json(status_path, {"status": state, "job": job, "elapsed": elapsed,
                                 "parent_terminated": state == "timeout"})
    print(f"{folder}/{job['model_id']}: {state} ({elapsed:.1f}s)", flush=True)
    return state


def smoke_checks(root, cfg):
    d = Domain(14, 9)
    truth = np.array([[v.lo, v.hi] for v in [G.true_loop_function(a, 9, 14) for a in d.states]])
    reports = {}
    for name, function in [("exact", lambda a: G.true_loop_function(a, 9, 14)), ("top", G.always_top(14)),
                           ("planted_even", G.make_learned_loop(0, 9, 14)), ("planted_odd", G.make_learned_loop(1, 9, 14))]:
        pred = np.array([[v.lo, v.hi] for v in map(function, d.states)])
        new = rules(d, pred, truth)
        old = G.law_report(name, function, lambda a: G.true_loop_function(a, 9, 14), d.states, 14)
        assert new["monotonicity_violations"] == old["monotonicity_violations"]
        assert new["soundness_violations"] == old["overapproximation_violations"]
        assert new["mean_output_width"] == old["mean_output_width"]
        assert new["has_rule_violation"] == name.startswith("planted")
        reports[name] = {"new": new, "old": old, "direct": G.iterate_fixpoint(function, G.BOT)}
    legacy = read_json(HERE / "results" / "legacy_n14" / "metrics.json")
    archived = read_json(HERE.parent / "metrics.json")
    assert legacy == archived, "Legacy rerun differs; investigate without modifying original"
    atomic_json(root / "smoke_checks.json", {"status": "passed", "original_metrics_exactly_reproduced": True,
                "counts": {"carrier_including_bottom": d.size, "ordered_pairs_including_reflexive": len(d.left),
                           "reflexive_pairs": d.size}, "reports": reports,
                "notes": ["width = hi-lo+1; bottom width 0", "steps exclude final stability call; start is bottom",
                          "raw F need not be inflationary; joined update is", "legacy scaling uses round(0.6N), paper says ceil; N14 scaling would use K8, so core smoke explicitly uses K9"],
                "oracle_accounting": "legacy stdlib diagnostic invokes F internally without instrumentation; excluded from core experimental query totals"})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default=str(HERE / "config.json"))
    parser.add_argument("--out", default=str(HERE / "results" / "core"))
    parser.add_argument("--phase", choices=["all", "prepare", "smoke", "train", "repair", "summarize", "verify"], default="all")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--budget-hours", type=float, default=4)
    parser.add_argument("--elapsed-before-seconds", type=float, default=0,
                        help="Charge inspection/setup wall time against the total budget")
    args = parser.parse_args()
    start = time.monotonic()
    end = start + max(0, args.budget_hours * 3600 - args.elapsed_before_seconds)
    root = Path(args.out).resolve()
    cfg = prepare(root, args.config, args.resume)
    task_end = end - cfg["summary_reserve_seconds"]
    phases = ["smoke", "train", "repair", "summarize", "verify"] if args.phase == "all" else [args.phase]
    counts = {}
    atomic_json(root / "runner_status.json", {"status": "running", "pid": os.getpid(), "phase": args.phase,
                "budget_seconds": args.budget_hours * 3600, "charged_setup_seconds": args.elapsed_before_seconds})
    for phase in phases:
        if phase == "smoke":
            smoke_checks(root, cfg)
            job = {"kind": "smoke", "model_id": "w32_c80_s0", "width": 32, "coverage": 0.8, "seed": 0}
            if execute_job(root, cfg, job, task_end, args.resume) != "completed":
                raise RuntimeError("Smoke training failed; formal grid not started")
        elif phase in ("train", "repair"):
            widths = cfg["widths"] if phase == "train" else [cfg["repair_width"]]
            coverages = cfg["coverages"] if phase == "train" else cfg["repair_coverages"]
            for width in widths:
                for coverage in coverages:
                    for seed in cfg["seeds"]:
                        model_id = f"w{width}_c{int(coverage*100)}_s{seed}"
                        job = {"kind": phase, "model_id": model_id, "width": width, "coverage": coverage, "seed": seed}
                        if phase == "repair" and not (root / "A" / model_id / "result.json").exists():
                            atomic_json(root / "B" / model_id / "status.json", {"status": "missing_original", "job": job})
                            state = "missing_original"
                        else:
                            state = execute_job(root, cfg, job, task_end, args.resume)
                        counts[f"{phase}:{state}"] = counts.get(f"{phase}:{state}", 0) + 1
                        atomic_json(root / "runner_progress.json", {"counts": counts,
                                    "elapsed_seconds": time.monotonic() - start,
                                    "remaining_seconds": max(0, end - time.monotonic())})
        elif phase in ("summarize", "verify"):
            script = HERE / ("summarize.py" if phase == "summarize" else "verify.py")
            state, elapsed = supervise([sys.executable, str(script), "--root", str(root)], HERE,
                                       root / f"{phase}.log", 600, end)
            counts[phase] = state
            if state != "completed":
                print(f"{phase} {state}; see {root / (phase+'.log')}", flush=True)
    atomic_json(root / "runner_status.json", {"status": "completed", "counts": counts,
                "elapsed_seconds": time.monotonic() - start, "background_tasks_remaining": False})


if __name__ == "__main__":
    main()
