"""Unit tests of the exact operator with a step parameter. No model is trained here.

Run:  python -B test_loop.py
Writes results/unit_tests.json and exits with status 1 if any property fails.
Properties P1-P3 are the three expected properties of the experiment's instructions;
D1-D2 show that the default step reproduces the main experiments' operator; C1-C3
check the new operator against the written definition and the concrete semantics.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
from loop import G, loop_function

LEARNED = HERE.parent / 'learned_admission'
N, K, STEP = 30, 18, 2


def state(a):
    return None if a.is_bot else [a.lo, a.hi]


def joined_iteration(function):
    current, trace = G.BOT, []
    while True:
        nxt = G.join(current, function(current))
        trace.append(state(nxt))
        if nxt == current:
            return current, trace[:-1]
        current = nxt


def closed_form(a, k, n, step):
    """The written definition in plain integers: a is None (bottom) or (l, u)."""
    if a is None or a[0] > k - 1:
        return [0, 0]
    return [0, min(min(a[1], k - 1) + step, n)]


def reachable(k, step):
    values = set()
    while True:
        nxt = {0} | {x + step for x in values if x < k}
        if nxt == values:
            return sorted(values)
        values = nxt


def main():
    f = lambda a: loop_function(a, K, N, STEP)
    universe = G.intervals(N)
    tests = {}

    # D1: with the default step the function is the main experiments' operator, on three domains.
    same = {}
    for n, k in [(30, 18), (50, 30), (14, 9)]:
        same[f'N{n}_K{k}'] = all(loop_function(a, k, n) == G.true_loop_function(a, k, n) == loop_function(a, k, n, 1)
                                 for a in G.intervals(n))
    tests['D1_default_step_equals_main_operator'] = {'passed': all(same.values()), 'domains': same}

    # D2: with the default step the table equals the archived oracle tables of both main grids.
    archived = {}
    for name, path in [('N30', LEARNED / 'results/core/truth.json'), ('N50', LEARNED / 'confirmation_n50/results/truth.json')]:
        saved = json.loads(path.read_text(encoding='utf-8'))
        table = [state(loop_function(a, saved['K'], saved['N'])) for a in G.intervals(saved['N'])]
        archived[name] = table == saved['outputs']
    tests['D2_default_step_equals_archived_oracle_tables'] = {'passed': all(archived.values()), 'grids': archived}

    # C1: the domain is the main grid's: 497 inputs including bottom.
    tests['C1_domain_size'] = {'passed': len(universe) == 497, 'inputs': len(universe)}

    # C2: F agrees with the written definition on every input.
    wrong = [state(a) for a in universe if state(f(a)) != closed_form(state(a), K, N, STEP)]
    tests['C2_operator_equals_written_definition'] = {'passed': not wrong and state(f(G.BOT)) == [0, 0],
                                                      'F_bottom': state(f(G.BOT)), 'disagreements': wrong}

    # C3: the reachable values are 0, 2, ..., K, so an interval is sound exactly if it contains [0, K].
    values = reachable(K, STEP)
    tests['C3_reachable_set'] = {'passed': values == list(range(0, K + 1, 2)) and [min(values), max(values)] == [0, K],
                                 'reachable': values, 'least_interval_containing_it': [min(values), max(values)]}

    # P1: joined iteration of the exact operator from bottom ends in [0, K + 1].
    final, trace = joined_iteration(f)
    tests['P1_exact_joined_iteration_ends_in_0_K_plus_1'] = {'passed': state(final) == [0, K + 1], 'final': state(final),
                                                             'trace': trace}

    # P2: F([0, K]) = [0, K + 1], which is not below [0, K]: the sound interval [0, K] is rejected.
    image = f(G.Interval(0, K))
    tests['P2_sound_interval_0_K_is_rejected'] = {
        'passed': state(image) == [0, K + 1] and not G.leq(image, G.Interval(0, K)) and G.leq(G.Interval(0, K), G.Interval(0, K)),
        'F_of_0_K': state(image), 'accepted': G.leq(image, G.Interval(0, K))}

    # P3: every [0, u] with u >= K + 1 is accepted.
    accepted = {u: G.leq(f(G.Interval(0, u)), G.Interval(0, u)) for u in range(K + 1, N + 1)}
    tests['P3_intervals_0_u_accepted_for_u_at_least_K_plus_1'] = {'passed': all(accepted.values()),
                                                                 'accepted_by_u': accepted}

    record = {'N': N, 'K': K, 'step': STEP, 'all_passed': all(t['passed'] for t in tests.values()), 'tests': tests,
              'loop_py_sha256': hashlib.sha256((HERE / 'loop.py').read_bytes()).hexdigest(),
              'python': sys.version, 'run_at': datetime.datetime.now().astimezone().isoformat(timespec='seconds')}
    out = HERE / 'results' / 'unit_tests.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    for name, test in tests.items():
        print('PASS' if test['passed'] else 'FAIL', name)
    print('final of exact joined iteration:', state(final), '| F([0, K]):', state(image))
    return 0 if record['all_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
