"""Runner for the loop with a step parameter: the main pipeline with another oracle table.

Each model is trained and evaluated by the unmodified worker of
experiments/learned_admission (worker.py, core.py, inference.py), started and
supervised by the main runner's own execute_job. This file only prepares a new
result directory: the oracle table for the configured step, the data splits by
the main grid's rule, the environment and the hashes. Nothing under
learned_admission is written. No retraining, no planted patterns.

Run:  python -B run_step2.py --config config.json --out results/grid
"""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.metadata
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
LEARNED = HERE.parent / 'learned_admission'
sys.dont_write_bytecode = True
sys.path.insert(0, str(LEARNED))
import numpy as np
from core import Domain, atomic_json, read_json, digest, code_hash
import run as main_runner
from loop import loop_function

REUSED = [LEARNED / name for name in ('inference.py', 'core.py', 'worker.py', 'run.py')] + [HERE.parent / 'nonmonotone_interval_gate.py']
NEW = [HERE / name for name in ('loop.py', 'run_step2.py', 'evaluate.py', 'test_loop.py', 'check_pipeline_step1.py',
                                'config.json', 'config_step1_check.json')]
PLAN = HERE / 'ANALYSIS_PLAN_ZH.md'
EXTRA_KEYS = {'step', 'loop'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec='seconds')


def frozen_inputs():
    """The plan and every script must be exactly what plan_lock.json recorded before any training."""
    lock = read_json(HERE / 'plan_lock.json')
    current = {p.name: sha(p) for p in [PLAN] + NEW}
    assert current == lock['sha256'], 'A frozen file changed after the analysis plan was locked'
    tests = read_json(HERE / 'results' / 'unit_tests.json')
    assert tests['all_passed'] and tests['loop_py_sha256'] == current['loop.py'], 'Unit tests of the operator have not passed'
    return lock


def git(*args):
    try:
        return subprocess.check_output(['git', *args], cwd=HERE, text=True, stderr=subprocess.STDOUT).strip()
    except Exception as error:
        return repr(error)


def prepare(root, cfg, resume):
    main_cfg = read_json(LEARNED / 'config.json')
    assert {k: cfg[k] for k in main_cfg} == main_cfg and set(cfg) - set(main_cfg) == EXTRA_KEYS, \
        'The configuration must be the main grid\'s plus the step'
    lock = frozen_inputs()
    main_preparation = read_json(LEARNED / 'results' / 'core' / 'preparation.json')
    assert code_hash() == main_preparation['code_hash'], 'The reused pipeline differs from the one that produced the main grid'
    root.mkdir(parents=True, exist_ok=True)
    config_path = root / 'config.lock.json'
    if config_path.exists():
        if not resume:
            raise RuntimeError('Existing run; specify --resume or a new --out directory')
        assert read_json(config_path) == cfg, 'Configuration mismatch'
        assert read_json(root / 'preparation.json')['new_code_sha256'] == {p.name: sha(p) for p in NEW}
        return
    start = time.perf_counter()
    d = Domain(cfg['N'], cfg['K'])
    t0 = time.perf_counter()
    outputs = []
    for a in d.states:                                   # exactly one evaluation of the exact operator per input
        v = loop_function(a, d.k, d.n, cfg['step'])
        assert not v.is_bot
        outputs.append([v.lo, v.hi])
    construction_seconds = time.perf_counter() - t0
    atomic_json(root / 'truth.json', {'N': d.n, 'K': d.k, 'step': cfg['step'], 'inputs': d.inputs, 'outputs': outputs,
                                      'F_evaluations': d.size, 'construction_seconds': construction_seconds})
    main_truth = read_json(LEARNED / 'results' / 'core' / 'truth.json')
    assert main_truth['inputs'] == d.inputs
    if cfg['step'] == 1:
        assert main_truth['outputs'] == outputs, 'Default step does not reproduce the main oracle table'
    # Splits: the main runner's rule, statement for statement (run.py, prepare).
    for seed in cfg['seeds']:
        ids = np.random.default_rng(seed).permutation(d.size).tolist()
        nt, nv = int(d.size * cfg['test_fraction']), int(d.size * cfg['validation_fraction'])
        test, validation, pool = ids[:nt], ids[nt:nt + nv], ids[nt + nv:]
        trains = {str(c): pool[:min(int(c * d.size), len(pool))] for c in cfg['coverages']}
        assert all(not (set(t) & (set(test) | set(validation))) for t in trains.values())
        atomic_json(root / 'splits' / f'seed_{seed}.json', {'seed': seed, 'test': test,
                    'validation': validation, 'pool': pool, 'train_by_coverage': trains,
                    'counts': {'carrier': d.size, 'test': nt, 'validation': nv,
                               'training': {c: len(v) for c, v in trains.items()}},
                    'rounding': 'floor all fractions of complete carrier; prefixes of one permuted pool'})
        assert read_json(root / 'splits' / f'seed_{seed}.json') == read_json(LEARNED / 'results' / 'core' / 'splits' / f'seed_{seed}.json'), \
            'Split differs from the main grid\'s split for this seed'
    hardware_cmd = 'Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json; Get-CimInstance Win32_OperatingSystem | Select-Object TotalVisibleMemorySize,FreePhysicalMemory | ConvertTo-Json'
    hardware = subprocess.run(['powershell', '-NoProfile', '-Command', hardware_cmd], capture_output=True, text=True).stdout if os.name == 'nt' else platform.processor()
    atomic_json(root / 'environment.json', {'python': sys.version, 'executable': sys.executable,
                'platform': platform.platform(), 'hardware': hardware,
                'packages': {x: importlib.metadata.version(x) for x in ('torch', 'numpy')},
                'git_commit': git('rev-parse', 'HEAD'), 'git_branch': git('branch', '--show-current'),
                'device': 'CPU', 'threads': 1, 'prepared_at': now()})
    atomic_json(config_path, cfg)
    atomic_json(root / 'preparation.json', {
        'pipeline_code_hash': code_hash(), 'pipeline_code_hash_equals_main_grid': True,
        'reused_source_sha256': {str(p.relative_to(HERE.parent)).replace('\\', '/'): sha(p) for p in REUSED},
        'new_code_sha256': {p.name: sha(p) for p in NEW},
        'analysis_plan_sha256': lock['sha256'][PLAN.name], 'analysis_plan_locked_at': lock['locked_at'],
        'config_hash': digest(cfg), 'step': cfg['step'], 'F_evaluations': d.size, 'carrier_size': d.size,
        'ordered_pairs': len(d.left), 'truth_construction_seconds': construction_seconds,
        'splits_identical_to_main_grid': True, 'preparation_seconds': time.perf_counter() - start,
        'scope': 'main worker, core and inference unmodified; only the oracle table depends on the step'})
    for path in REUSED + NEW + [PLAN, HERE / 'plan_lock.json']:
        destination = root / 'source_snapshot' / path.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(path.read_bytes())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=str(HERE / 'config.json'))
    parser.add_argument('--out', default=str(HERE / 'results' / 'grid'))
    parser.add_argument('--only', nargs='*', default=None, help='model ids to run; default is the whole grid')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--budget-hours', type=float, default=2)
    args = parser.parse_args()
    started, start = now(), time.monotonic()
    root = Path(args.out).resolve()
    assert LEARNED not in root.parents and root != LEARNED, 'Results must not go under learned_admission'
    cfg = read_json(args.config)
    prepare(root, cfg, args.resume)
    deadline = start + args.budget_hours * 3600
    counts, order = {}, []
    atomic_json(root / 'runner_status.json', {'status': 'running', 'pid': os.getpid(), 'started_at': started})
    for width in cfg['widths']:                          # the main runner's order of jobs
        for coverage in cfg['coverages']:
            for seed in cfg['seeds']:
                model_id = f'w{width}_c{int(coverage*100)}_s{seed}'
                if args.only is not None and model_id not in args.only:
                    continue
                job = {'kind': 'train', 'model_id': model_id, 'width': width, 'coverage': coverage, 'seed': seed}
                state = main_runner.execute_job(root, cfg, job, deadline, args.resume)
                counts[state] = counts.get(state, 0) + 1
                order.append([model_id, state])
                atomic_json(root / 'runner_progress.json', {'counts': counts, 'elapsed_seconds': time.monotonic() - start})
    record = {'command': [sys.executable] + sys.argv, 'working_directory': os.getcwd(), 'started_at': started,
              'finished_at': now(), 'elapsed_seconds': time.monotonic() - start, 'counts': counts, 'jobs': order,
              'resume': args.resume, 'output': str(root), 'config': str(Path(args.config).resolve())}
    name = 'resume_record.json' if (root / 'execution_record.json').exists() else 'execution_record.json'
    atomic_json(root / name, record)
    atomic_json(root / 'runner_status.json', {'status': 'completed', 'counts': counts,
                'elapsed_seconds': time.monotonic() - start, 'background_tasks_remaining': False})
    print({'counts': counts, 'elapsed_seconds': round(time.monotonic() - start, 1), 'out': str(root)}, flush=True)
    return 0 if set(counts) == {'completed'} else 1


if __name__ == '__main__':
    raise SystemExit(main())
