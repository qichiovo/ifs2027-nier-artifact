"""Exact interval operator of  x := 0; while x < K do x := x + step.

step defaults to 1, the loop of the paper's main experiments. With step = 1 the
function equals nonmonotone_interval_gate.true_loop_function on every input
(checked in test_loop.py). The interval type, order, join, meet and the shape of
the loop functional are the original ones; only the increment is a parameter.
"""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
if str(HERE.parent) not in sys.path:
    sys.path.insert(0, str(HERE.parent))
import nonmonotone_interval_gate as G


def shift(x, step, top):
    if x.is_bot:
        return G.BOT
    return G.Interval(min(x.lo + step, top), min(x.hi + step, top))


def loop_function(x, k, top, step=1):
    """F(a) = [0, 0] join ((a meet [0, k - 1]) + step); F(bottom) = [0, 0]."""
    return G.make_loop_function(k, lambda y: shift(y, step, top))(x)
