"""Pipeline check with the default step: does this runner reproduce an archived main-grid model?

Trains one model with step = 1 through run_step2.py into results/pipeline_check_step1
and compares it with experiments/learned_admission/results/core/A/<model>: oracle
table, split, weights, outputs on every input, accuracy and joined result. It
touches no step-2 result. Exits with status 1 if anything differs.

Run:  python -B check_pipeline_step1.py
"""
from pathlib import Path
import datetime
import json
import subprocess
import sys

HERE = Path(__file__).resolve().parent
LEARNED = HERE.parent / 'learned_admission'
sys.dont_write_bytecode = True
sys.path.insert(0, str(LEARNED))
import torch
from core import atomic_json, read_json

MODEL = 'w32_c80_s0'          # the configuration the main pipeline used for its own smoke test


def main():
    root = HERE / 'results' / 'pipeline_check_step1'
    command = [sys.executable, '-B', str(HERE / 'run_step2.py'), '--config', str(HERE / 'config_step1_check.json'),
               '--out', str(root), '--only', MODEL]
    if (root / 'config.lock.json').exists():
        command.append('--resume')
    run = subprocess.run(command, cwd=HERE, capture_output=True, text=True)
    print(run.stdout[-600:], run.stderr[-2000:], sep='')
    new, old = root / 'A' / MODEL, LEARNED / 'results' / 'core' / 'A' / MODEL
    checks = {'runner_exit_status_zero': run.returncode == 0}
    if run.returncode == 0:
        a, b = read_json(new / 'result.json'), read_json(old / 'result.json')
        wa = torch.load(new / 'model.pt', map_location='cpu', weights_only=True)['state_dict']
        wb = torch.load(old / 'model.pt', map_location='cpu', weights_only=True)['state_dict']
        checks.update({
            'oracle_table_equal': read_json(root / 'truth.json')['outputs'] == read_json(LEARNED / 'results/core/truth.json')['outputs'],
            'split_equal': a['split'] == b['split'],
            'weights_equal': sorted(wa) == sorted(wb) and all(torch.equal(wa[k], wb[k]) for k in wa),
            'outputs_on_every_input_equal': a['predictions'] == b['predictions'],
            'accuracy_equal': a['accuracy'] == b['accuracy'],
            'law_counts_equal': (a['soundness_violations'], a['monotonicity_violations']) == (b['soundness_violations'], b['monotonicity_violations']),
            'joined_result_equal': {k: a['joined'][k] for k in ('status', 'final', 'steps', 'covers_reachable', 'postfixed_exact_F')}
                                   == {k: b['joined'][k] for k in ('status', 'final', 'steps', 'covers_reachable', 'postfixed_exact_F')},
            'epochs_and_best_epoch_equal': (a['training']['epochs_run'], a['training']['best_epoch']) == (b['training']['epochs_run'], b['training']['best_epoch']),
            'pipeline_code_hash_equal': a['code_hash'] == b['code_hash'],
        })
    record = {'model': MODEL, 'step': 1, 'all_equal': all(checks.values()), 'checks': checks, 'command': command,
              'compared_with': str(old), 'checked_at': datetime.datetime.now().astimezone().isoformat(timespec='seconds')}
    atomic_json(root / 'comparison.json', record)
    print(json.dumps({k: record[k] for k in ('model', 'all_equal', 'checks')}, indent=1))
    return 0 if record['all_equal'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
