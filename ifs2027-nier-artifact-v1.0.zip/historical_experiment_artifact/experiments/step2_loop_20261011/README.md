# Second loop: `x := 0; while x < K do x := x + 2`

Run on 2026-10-11 for the iFS 2027 NIER manuscript, on the author's instructions.
The experiment was implemented and run by Claude Code (Anthropic, Claude Opus 5.5).
It changes no existing code, result or manuscript text. The analysis plan, fixed before
any training: [ANALYSIS_PLAN_ZH.md](ANALYSIS_PLAN_ZH.md) (in Chinese).

## What it does

It trains the primary grid (widths 16, 32, 64; coverage targets 20%, 50%, 80%; seeds
0 to 4; 45 models; N = 30, K = 18) on the exact operator of the loop with increment 2
and records, for every model, accuracy, the two global laws, the joined result, whether
that result is sound, whether the post-fixpoint check accepts it, and the envelope's
result. No retraining and no planted patterns.

Training and evaluation are done by the unmodified `worker.py`, `core.py` and
`inference.py` of `../learned_admission`. The only difference from the primary grid is
the oracle table, which `loop.py` computes with a `step` parameter (default 1, the
paper's loop).

## Files

| File | Purpose |
|---|---|
| `loop.py` | exact operator with a `step` parameter |
| `test_loop.py` | unit tests of the operator; writes `results/unit_tests.json` |
| `config.json` | the primary grid's configuration plus `step: 2` |
| `config_step1_check.json` | the same with `step: 1`, for the pipeline check |
| `run_step2.py` | prepares a result directory and schedules the jobs with the main runner's code |
| `check_pipeline_step1.py` | trains one model with `step = 1` and compares it with the archived one |
| `evaluate.py` | per-model records, the three result classes, the summary |
| `lock_plan.py`, `plan_lock.json` | hashes of the plan, scripts and configurations, recorded before training |
| `report_tables.py` | written after the run; formats the evaluation as tables |

## Commands, in the order they were run

From this directory, with Python 3.14.7, PyTorch 2.14.1+cpu and NumPy 2.5.2:

```powershell
python -B test_loop.py
python -B evaluate.py --root ../learned_admission/results/core --out results/evaluation_check_main_grid
python -B lock_plan.py
python -B check_pipeline_step1.py
python -B run_step2.py --config config.json --out results/grid
python -B evaluate.py --root results/grid --out results/evaluation
python -B report_tables.py
```

`lock_plan.py` refuses to run a second time, and `run_step2.py` refuses to write into an
existing result directory without `--resume`. To repeat the run, use a new `--out`.

## Results

| Path | Contents |
|---|---|
| `results/unit_tests.json` | the three expected properties and five further checks, all passed |
| `results/evaluation_check_main_grid/` | `evaluate.py` applied to the archived primary grid; reproduces the paper's N = 30 rows |
| `results/pipeline_check_step1/` | the `step = 1` model and `comparison.json`: identical to the archived model |
| `results/grid/` | oracle table, splits, environment, hashes, source snapshot, execution record, and `A/<model>/` with each model's checkpoint, `result.json`, log and `attempts.json` |
| `results/evaluation/` | `models.json`, `models.csv`, `summary.json`, `report_tables.md` |

Checkpoints (`*.pt`) are kept locally and excluded from Git, as in `../learned_admission`.

## Outcome in one paragraph

All 45 jobs completed on the first attempt (158.8 s). 24 of 45 joined results are sound
and all 24 are accepted; 21 are unsound and rejected; **no result is sound but rejected**.
4 models pass coverage and 2 pass both global laws; those 2 are the two least accurate
models. The three most accurate models violate the laws and have sound results. All 45
envelopes end in [0, 19]. See the report for the witnesses and for how this differs from
the primary grid.
