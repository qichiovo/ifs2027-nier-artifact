"""Freeze the analysis plan, the scripts and the configurations before any training.

Writes plan_lock.json with the SHA-256 of each file and the time. Refuses to run
twice. run_step2.py compares the files with this record before it trains anything.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
FILES = ['ANALYSIS_PLAN_ZH.md', 'loop.py', 'run_step2.py', 'evaluate.py', 'test_loop.py', 'check_pipeline_step1.py',
         'config.json', 'config_step1_check.json']


def main():
    lock = HERE / 'plan_lock.json'
    assert not lock.exists(), 'The plan is already locked'
    assert not (HERE / 'results' / 'grid').exists() and not (HERE / 'results' / 'pipeline_check_step1').exists(), \
        'Training output exists; the plan must be locked before any training'
    tests = json.loads((HERE / 'results' / 'unit_tests.json').read_text(encoding='utf-8'))
    assert tests['all_passed']
    record = {'locked_at': datetime.datetime.now().astimezone().isoformat(timespec='seconds'),
              'sha256': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in FILES},
              'unit_tests_run_at': tests['run_at'], 'python': sys.version,
              'note': 'No model of this experiment had been trained when this file was written.'}
    lock.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record, indent=1))


if __name__ == '__main__':
    main()
