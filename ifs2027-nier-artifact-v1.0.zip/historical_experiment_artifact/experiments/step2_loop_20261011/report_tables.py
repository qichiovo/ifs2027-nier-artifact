"""Tables for the report, from results/evaluation. Written after the run; it only formats what evaluate.py wrote.

The last block ("supplementary") is not part of the analysis plan: it describes what
the 45 models output at the input [0, K], read from the saved output tables.

Run:  python -B report_tables.py            (prints Markdown; writes results/evaluation/report_tables.md)
"""
from collections import Counter
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
EVAL = HERE / 'results' / 'evaluation'


def iv(v):
    return '⊥' if v is None else f'[{v[0]}, {v[1]}]'


def yes(flag):
    return '是' if flag else '否'


CLASS = {'sound_accepted': '可靠且被接受', 'sound_rejected': '可靠但被拒', 'unsound': '不可靠'}


def model_rows(rows):
    out = ['| 模型 | 留出集准确率 | 名次 | 全域 exact | 遗漏输入 | 单调性违例 | 覆盖 | 两条定律 | 最终不变式 | 类别 | 路径上的遗漏 |',
           '|---|---|---|---|---|---|---|---|---|---|---|']
    for m in rows:
        out.append(f"| {m['model_id']} | {m['heldout_exact_percent']:.1f}%（{m['heldout_exact']}） | {m['accuracy_rank']} | "
                   f"{m['full_domain_exact_percent']:.1f}% | {m['omission_inputs']} | {m['monotonicity_violations']} | "
                   f"{yes(m['coverage_pass'])} | {yes(m['global_pass'])} | {iv(m['final_invariant'])} | {CLASS[m['class']]} | {m['path_omissions']} |")
    return out


def main():
    s = json.loads((EVAL / 'summary.json').read_text(encoding='utf-8'))
    models = json.loads((EVAL / 'models.json').read_text(encoding='utf-8'))
    t, lines = s['totals'], []
    lines += ['## 总计', '',
              f"- 模型 {s['models']} 个，网格完整：{yes(s['grid_complete'])}；joined 迭代终止 {t['joined_terminated']}/{s['models']}",
              f"- 留出集准确率：中位数 {t['heldout_exact_percent_median']:.1f}%，范围 {t['heldout_exact_percent_min']:.1f}%–{t['heldout_exact_percent_max']:.1f}%",
              f"- 覆盖通过 {t['coverage_pass']}/{s['models']}，两条全局定律通过 {t['global_pass']}/{s['models']}",
              f"- 可靠且被接受 {t['sound_accepted']}，可靠但被拒 {t['sound_rejected']}，不可靠 {t['unsound']}",
              f"- 被接受 {t['accepted']}/{s['models']}，其中带定律违例 {t['accepted_with_law_violation']}；可靠但带违例 {t['sound_with_law_violation']}；通过定律却不可靠 {t['unsound_with_global_pass']}",
              '- 最终不变式分布：' + '，'.join(f"{iv(json.loads(k))} × {v}" for k, v in s['final_invariants'].items()), '']
    lines += ['## 各配置', '', '| 宽度 | 覆盖率目标 | 准确率中位数 | 范围 | 覆盖通过 | 全局通过 | 可靠且被接受 | 可靠但被拒 | 不可靠 |', '|---|---|---|---|---|---|---|---|---|']
    for c in s['by_configuration']:
        lines.append(f"| {c['width']} | {c['coverage_target_percent']}% | {c['heldout_exact_percent_median']:.1f}% | "
                     f"{c['heldout_exact_percent_min']:.1f}%–{c['heldout_exact_percent_max']:.1f}% | {c['coverage_pass']}/{c['models']} | "
                     f"{c['global_pass']}/{c['models']} | {c['sound_accepted']} | {c['sound_rejected']} | {c['unsound']} |")
    lines += ['', '## 可靠但被拒的模型', ''] + (model_rows(s['primary_sound_but_rejected']) if s['primary_sound_but_rejected'] else ['无。'])
    lines += ['', '## 准确率最高的模型（第 3 名并列的全部列出）', ''] + model_rows(s['top_models_by_heldout_accuracy'])
    lines += ['', '## 通过两条全局定律的模型', ''] + (model_rows(s['models_passing_both_laws']) if s['models_passing_both_laws'] else ['无。'])
    lines += ['', '## 通过覆盖的模型', ''] + (model_rows(s['models_passing_coverage']) if s['models_passing_coverage'] else ['无。'])
    lines += ['', '## 阈值', ''] + [f"- 留出集准确率 ≥ {k}%：{v['models']} 个（其中违反定律 {v['with_law_violation']}，不可靠 {v['unsound']}）"
                                    for k, v in s['at_or_above_heldout_threshold'].items()]
    lines += ['', '## 包络', '', f"- joined 结果等于 {iv(s['expected_envelope_final'])} 的：{s['envelope']['equal_to_expected']}/{s['models']}；其他：{len(s['envelope']['others'])} 个"]
    lines += ['', '## 不可靠的模型在停下处的输出', '', '| 模型 | 准确率 | 最终不变式 I | T(I) | F(I) | I 在训练集里 | 路径上的遗漏 | 全部遗漏 |', '|---|---|---|---|---|---|---|---|']
    for m in s['unsound_models']:
        a = m['at_final']
        lines.append(f"| {m['model_id']} | {m['heldout_exact_percent']:.1f}% | {iv(m['final_invariant'])} | {iv(a['model_output'])} | {iv(a['exact_output'])} | "
                     f"{yes(a['input_in_training_set'])} | {m['path_omissions']} | {m['omission_inputs']} |")
    lines += ['', '## 可靠的模型：路径和定律', '']
    sound = [m for m in models if m['sound']]
    lines += [f"- 可靠的 {len(sound)} 个里：通过两条定律 {sum(m['global_pass'] for m in sound)}，只通过覆盖 {sum(m['coverage_pass'] and not m['global_pass'] for m in sound)}，有遗漏 {sum(not m['coverage_pass'] for m in sound)}",
              f"- 有遗漏而结果可靠的 {sum(not m['coverage_pass'] for m in sound)} 个里：路径上没有遗漏的 {sum(not m['coverage_pass'] and m['path_omissions'] == 0 for m in sound)} 个，路径上有遗漏的 {sum(not m['coverage_pass'] and m['path_omissions'] > 0 for m in sound)} 个",
              '- 可靠模型的路径（经过的状态序列）：' + '；'.join(f"{' → '.join(iv(e['state']) for e in path)} × {n}" for path, n in
                                                      [(json.loads(p), n) for p, n in Counter(json.dumps(m['path']) for m in sound).most_common()][:0])]
    paths = Counter(' → '.join(iv(e['state']) for e in m['path']) for m in sound)
    lines[-1] = '- 可靠模型经过的状态序列：' + '；'.join(f"{p} × {n}" for p, n in paths.most_common())
    wider_on_path = [m['model_id'] for m in sound if any(e['relation'] == 'wider' for e in m['path'])]
    lines.append(f"- 可靠模型里，路径上有比精确输出更宽的输出的：{len(wider_on_path)} 个")

    # Supplementary, not in the plan: what every model outputs at [0, K] and at [0, K + 1].
    truth = json.loads((HERE / 'results' / 'grid' / 'truth.json').read_text(encoding='utf-8'))
    k = truth['K']
    at_k, at_k1 = truth['inputs'].index([0, k]), truth['inputs'].index([0, k + 1])
    outputs, visits, below = Counter(), 0, []
    for m in models:
        table = json.loads((HERE / 'results' / 'grid' / 'A' / m['model_id'] / 'result.json').read_text(encoding='utf-8'))['predictions']
        out = table[at_k]
        outputs[iv(out)] += 1
        visits += any(e['state'] == [0, k] for e in m['path'])
        if out[0] >= 0 and out[1] <= k:
            below.append((m['model_id'], iv(out), iv(m['final_invariant']), CLASS[m['class']]))
    lines += ['', '## 补充观察（不在分析计划内）：45 个模型在输入 [0, K] 上的输出', '',
              f"- 精确输出 F([0, {k}]) = {iv(truth['outputs'][at_k])}",
              '- 模型输出的分布：' + '，'.join(f"{o} × {n}" for o, n in sorted(outputs.items(), key=lambda kv: -kv[1])),
              f"- 迭代路径经过 [0, {k}] 的模型：{visits} 个",
              f"- 输出落在 [0, {k}] 以内（若迭代到达 [0, {k}] 就会停在那里）的模型：{len(below)} 个" + ('：' + '；'.join(f"{a}（输出 {b}，最终不变式 {c}，{d}）" for a, b, c, d in below) if below else '')]
    text = '\n'.join(lines) + '\n'
    (EVAL / 'report_tables.md').write_text(text, encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
