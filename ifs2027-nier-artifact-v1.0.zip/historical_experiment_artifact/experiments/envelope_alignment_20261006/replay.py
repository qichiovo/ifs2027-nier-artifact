"""Isolated original-battery replay, changing only the envelope when requested.

Original modules are read-only. Their raw-inflation gate verdict is retained,
alongside a separately named verdict for the manuscript's joined-update contract.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE.parent))
import nonmonotone_interval_gate as G
import nonmonotone_scaling as S


def dump(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    tmp.replace(path)


def paper_envelope(f, universe, exact):
    def env(a):
        out = G.BOT
        for b in universe:
            if G.leq(b, a):
                out = G.join(out, f(b))
        return G.join(out, exact(a))
    return env


def closure_by_interval_recursion(f, universe, N):
    """Exact finite join: every proper subinterval lies in a trimmed interval.

    This independent O(N^2) construction is checked against the literal original
    envelope/paper formula on EVERY input visited by the original battery.
    """
    values = {G.BOT: f(G.BOT)}
    for width in range(1, N + 2):
        for lo in range(N + 2 - width):
            a = G.Interval(lo, lo + width - 1)
            v = G.join(values[G.BOT], f(a))
            if width > 1:
                v = G.join(v, values[G.Interval(lo + 1, a.hi)])
                v = G.join(v, values[G.Interval(lo, a.hi - 1)])
            values[a] = v
    assert len(values) == len(universe)
    return values


def analyse_iteration(table, U, K, N, joined):
    fun = (lambda a: G.join(a, table[a])) if joined else table.__getitem__
    run = G.iterate_fixpoint(fun, G.BOT, max_steps=len(U) + 1)
    if run['status'] == 'converged':
        v = run['fixpoint']
        inv = G.BOT if v.get('kind') == 'bottom' else G.Interval(v['lo'], v['hi'])
        run.update(sound=G.leq(G.Interval(0, K), inv),
                   exact_postfixpoint=G.leq(G.true_loop_function(inv, K, N), inv),
                   invariant_width=inv.width(N),
                   false_proof_x_le_K_minus_1=inv.is_bot or inv.hi <= K - 1,
                   true_assertions_proved=sum(inv.is_bot or inv.hi <= c for c in range(K, N + 1)),
                   true_assertions_total=N - K + 1,
                   transformer_calls=len(run['trace']))
    return run


def audit(N, K, seeds, observed, implementation):
    U = G.intervals(N)
    exact = {a: G.true_loop_function(a, K, N) for a in U}
    out = {'N': N, 'K': K, 'seeds': list(range(seeds)), 'inputs': len(U)}
    tables = {'exact': exact, 'top': {a: G.Interval(0, N) for a in U}}
    identities = []
    for seed in range(seeds):
        fun = G.make_learned_loop(seed, K, N)
        raw = {a: fun(a) for a in U}
        closure = closure_by_interval_recursion(fun, U, N)
        old = {a: G.join(a, closure[a]) for a in U}
        paper = {a: G.join(exact[a], closure[a]) for a in U}
        identities.append({'seed': seed,
            'raw_leq_exact_all_inputs': all(G.leq(raw[a], exact[a]) for a in U),
            'paper_equals_exact_all_inputs': paper == exact,
            'legacy_equals_joined_exact_all_inputs': all(old[a] == G.join(a, exact[a]) for a in U),
            'joined_paper_equals_legacy_all_inputs': all(G.join(a, paper[a]) == old[a] for a in U),
            'candidate_table_sha256': hashlib.sha256(json.dumps([raw[a].to_json() for a in U], sort_keys=True).encode()).hexdigest()})
        tables[f'raw_seed_{seed}'] = raw
        if seed == 0:
            tables.update(legacy_envelope=old, paper_envelope=paper)
    target = tables[implementation + '_envelope']
    assert len(observed) == len(U), (len(observed), len(U))
    assert observed == target, 'Literal original-battery envelope differs from independent recursive construction'
    out['literal_vs_independent_all_inputs_equal'] = True
    out['identities_by_seed'] = identities
    out['unique_candidate_tables'] = len({r['candidate_table_sha256'] for r in identities})
    out['analyses'] = {}
    for name, tab in tables.items():
        out['analyses'][name] = {
            'exact_rate': sum(tab[a] == exact[a] for a in U) / len(U),
            'mean_width': sum(tab[a].width(N) for a in U) / len(U),
            'raw_inflation_violations': sum(not G.leq(a, tab[a]) for a in U),
            'joined_inflation_violations': sum(not G.leq(a, G.join(a, tab[a])) for a in U),
            'omission_inputs': sum(not G.leq(exact[a], tab[a]) for a in U),
            'direct': analyse_iteration(tab, U, K, N, False),
            'joined': analyse_iteration(tab, U, K, N, True)}
    out['differing_inputs'] = [a.to_json() for a in U if tables['legacy_envelope'][a] != tables['paper_envelope'][a]]
    a = G.Interval(N, N)
    out['formula_witness'] = {'input': a.to_json(), 'exact': exact[a].to_json(),
        'legacy': tables['legacy_envelope'][a].to_json(), 'paper': tables['paper_envelope'][a].to_json()}
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--kind', choices=['main', 'scaling'], required=True)
    p.add_argument('--implementation', choices=['legacy', 'paper'], required=True)
    p.add_argument('--N', type=int, required=True)
    p.add_argument('--K', type=int, required=True)
    p.add_argument('--seeds', type=int, required=True)
    p.add_argument('--out', type=Path, required=True)
    args = p.parse_args()
    original_env = G.monotone_envelope
    observed = {}
    def builder(f, universe):
        if args.implementation == 'legacy':
            literal = original_env(f, universe)
        else:
            literal = paper_envelope(f, universe, lambda a: G.true_loop_function(a, args.K, args.N))
        def record(a):
            result = literal(a)
            observed[a] = result
            return result
        return record
    G.monotone_envelope = builder
    wall, cpu = time.perf_counter(), time.process_time()
    if args.kind == 'main':
        assert (args.N, args.K, args.seeds) == (14, 9, 30)
        result = G.run_gate('paper')
    else:
        result = S.scaling_point(args.N, args.K, args.seeds)
    original_battery_timing = {'wall_seconds': time.perf_counter() - wall,
                               'cpu_seconds': time.process_time() - cpu}
    args.out.mkdir(parents=True, exist_ok=True)
    dump(args.out / 'original_battery.json', result)
    extra = audit(args.N, args.K, args.seeds, observed, args.implementation)
    rep = result['reports']['envelope'] if args.kind == 'main' else result
    # S only exposes the conjunction (which tests raw inflation). Compute the
    # exact same exhaustive lean_law report again only at N14; at larger N,
    # capture it during the original run (installed below in __main__).
    env_law = CAPTURED_LAWS[-2] if args.kind == 'scaling' else {
        'mono': rep['monotonicity_violations'], 'over': rep['overapproximation_violations'],
        'infl': rep['inflationarity_violations']}
    functional = extra['analyses'][args.implementation + '_envelope']
    extra['original_exhaustive_envelope_law'] = env_law
    extra['manuscript_contract_pass'] = bool(env_law['mono'] == 0 and env_law['over'] == 0
        and functional['joined_inflation_violations'] == 0
        and functional['joined']['status'] == 'converged' and functional['joined']['sound'])
    extra['timing_original_battery'] = original_battery_timing
    extra['timing_whole_worker_wall_seconds'] = time.perf_counter() - wall
    extra['raw_inflation_gate_result_retained_unmodified'] = True
    dump(args.out / 'audit.json', extra)
    if args.kind == 'scaling':
        dump(args.out / 'exhaustive_laws_by_seed_and_controls.json', CAPTURED_LAWS)
    print(json.dumps({'status': 'complete', 'implementation': args.implementation, 'N': args.N,
                      'K': args.K, 'contract_pass': extra['manuscript_contract_pass'],
                      'wall_seconds': extra['timing_whole_worker_wall_seconds']}), flush=True)


CAPTURED_LAWS = []
if __name__ == '__main__':
    lean_original = S.lean_law
    def capturing_law(*args):
        result = lean_original(*args)
        CAPTURED_LAWS.append(result)
        return result
    S.lean_law = capturing_law
    main()
