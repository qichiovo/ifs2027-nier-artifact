#!/usr/bin/env python3
"""Finite-lattice gate for nonmonotone learned abstract transformers.

The gate is intentionally stdlib-only and exhaustive over finite interval
lattices. It treats "learned" as a frozen finite predictor table with a small
locally accurate defect, then checks the abstract-interpretation laws that a
fixpoint engine needs.
"""
from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from statistics import mean, pstdev
from typing import Callable


IDEA_ID = "20260629_nonmonotone_learned_abstract_transformers_break_fixpoints"
CAMPAIGN_ID = "campaign_prior-study_20260701T043402747052Z"
CLAIM_RUN_ID = "prior-study_new_20260701T1434AEST:nonmonotone"


@dataclass(frozen=True, order=True)
class Interval:
    lo: int
    hi: int

    @property
    def is_bot(self) -> bool:
        return self.lo > self.hi

    def width(self, top: int) -> int:
        if self.is_bot:
            return 0
        return self.hi - self.lo + 1

    def to_json(self) -> dict[str, int | str]:
        if self.is_bot:
            return {"kind": "bottom"}
        return {"lo": self.lo, "hi": self.hi}


BOT = Interval(1, 0)


def intervals(top: int) -> list[Interval]:
    out = [BOT]
    for lo in range(top + 1):
        for hi in range(lo, top + 1):
            out.append(Interval(lo, hi))
    return out


def leq(a: Interval, b: Interval) -> bool:
    if a.is_bot:
        return True
    if b.is_bot:
        return a.is_bot
    return b.lo <= a.lo and a.hi <= b.hi


def join(a: Interval, b: Interval) -> Interval:
    if a.is_bot:
        return b
    if b.is_bot:
        return a
    return Interval(min(a.lo, b.lo), max(a.hi, b.hi))


def intersect(a: Interval, b: Interval) -> Interval:
    if a.is_bot or b.is_bot:
        return BOT
    lo = max(a.lo, b.lo)
    hi = min(a.hi, b.hi)
    return BOT if lo > hi else Interval(lo, hi)


def true_shift_plus_one(x: Interval, top: int) -> Interval:
    if x.is_bot:
        return BOT
    lo = min(x.lo + 1, top)
    hi = min(x.hi + 1, top)
    return Interval(lo, hi)


def make_loop_function(k: int, body: Callable[[Interval], Interval]) -> Callable[[Interval], Interval]:
    guard = Interval(0, k - 1)
    init = Interval(0, 0)

    def loop_f(x: Interval) -> Interval:
        return join(init, body(intersect(x, guard)))

    return loop_f


def true_loop_function(x: Interval, k: int, top: int) -> Interval:
    return make_loop_function(k, lambda y: true_shift_plus_one(y, top))(x)


def make_learned_loop(seed: int, k: int, top: int) -> Callable[[Interval], Interval]:
    """Return a locally accurate but law-breaking frozen predictor.

    Each seed has one high-leverage defect at the fixpoint frontier. This mirrors
    a learned abstract transformer whose aggregate one-step error looks tiny, but
    whose violation sits exactly where Kleene iteration depends on monotonicity.
    """
    cyclic = seed % 2 == 1

    def learned(x: Interval) -> Interval:
        exact = true_loop_function(x, k, top)
        if x.is_bot:
            return exact
        if cyclic:
            if x == Interval(0, k - 1):
                return Interval(0, k)
            if x == Interval(0, k):
                return Interval(0, k - 1)
        else:
            if x == Interval(0, k - 1):
                return Interval(0, k - 1)
            if x == Interval(0, k):
                return Interval(0, k - 2)
        return exact

    return learned


def monotone_envelope(f: Callable[[Interval], Interval], universe: list[Interval]) -> Callable[[Interval], Interval]:
    def env(x: Interval) -> Interval:
        out = x
        for y in universe:
            if leq(y, x):
                out = join(out, f(y))
        return out

    return env


def always_top(top: int) -> Callable[[Interval], Interval]:
    t = Interval(0, top)
    return lambda _x: t


def law_report(name: str, f: Callable[[Interval], Interval], true_f: Callable[[Interval], Interval],
               universe: list[Interval], top: int) -> dict[str, object]:
    monotone_violations = []
    overapprox_violations = []
    inflation_violations = []
    exact = 0
    widths = []
    for x in universe:
        fx = f(x)
        tx = true_f(x)
        widths.append(fx.width(top))
        if fx == tx:
            exact += 1
        if not leq(tx, fx):
            overapprox_violations.append({"input": x.to_json(), "true": tx.to_json(), "got": fx.to_json()})
        if not leq(x, fx):
            inflation_violations.append({"input": x.to_json(), "got": fx.to_json()})
    for a in universe:
        for b in universe:
            if leq(a, b) and not leq(f(a), f(b)):
                monotone_violations.append({
                    "smaller": a.to_json(),
                    "larger": b.to_json(),
                    "f_smaller": f(a).to_json(),
                    "f_larger": f(b).to_json(),
                })
    return {
        "name": name,
        "inputs": len(universe),
        "ordered_pairs": sum(1 for a in universe for b in universe if leq(a, b)),
        "one_step_exact_rate": exact / len(universe),
        "mean_output_width": mean(widths),
        "monotonicity_violations": len(monotone_violations),
        "overapproximation_violations": len(overapprox_violations),
        "inflationarity_violations": len(inflation_violations),
        "examples": {
            "monotonicity": monotone_violations[:3],
            "overapproximation": overapprox_violations[:3],
            "inflationarity": inflation_violations[:3],
        },
    }


def iterate_fixpoint(f: Callable[[Interval], Interval], start: Interval, max_steps: int = 32) -> dict[str, object]:
    seen: dict[Interval, int] = {}
    trace: list[Interval] = []
    x = start
    for step in range(max_steps):
        if x in seen:
            return {
                "status": "cycle",
                "cycle_from": seen[x],
                "cycle_to": step,
                "trace": [t.to_json() for t in trace],
            }
        seen[x] = step
        trace.append(x)
        nx = f(x)
        if nx == x:
            return {"status": "converged", "steps": step, "fixpoint": x.to_json(), "trace": [t.to_json() for t in trace]}
        x = nx
    return {"status": "timeout", "steps": max_steps, "trace": [t.to_json() for t in trace]}


def wilson_ci(k: int, n: int, z: float = 1.96) -> list[float]:
    if n == 0:
        return [0.0, 0.0]
    p = k / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denom
    return [max(0.0, center - margin), min(1.0, center + margin)]


def run_gate(mode: str) -> dict[str, object]:
    top = 8 if mode == "gate" else 14
    k = 5 if mode == "gate" else 9
    seeds = list(range(10 if mode == "gate" else 30))
    universe = intervals(top)
    exact_f = lambda x: true_loop_function(x, k, top)
    learned_rows = []
    unsound_count = 0
    cycle_count = 0
    for seed in seeds:
        learned = make_learned_loop(seed, k, top)
        rep = law_report(f"learned_seed_{seed}", learned, exact_f, universe, top)
        fp = iterate_fixpoint(learned, BOT)
        exact_lfp = Interval(0, k)
        if fp.get("status") == "converged":
            got = fp.get("fixpoint")
            if got != exact_lfp.to_json():
                unsound_count += 1
        if fp.get("status") == "cycle":
            cycle_count += 1
        rep["fixpoint_run"] = fp
        learned_rows.append(rep)
    env = monotone_envelope(make_learned_loop(0, k, top), universe)
    env_rep = law_report("monotone_inflationary_envelope", env, exact_f, universe, top)
    env_fp = iterate_fixpoint(env, BOT)
    top_rep = law_report("always_top", always_top(top), exact_f, universe, top)
    positive_control = {
        "passed": any(r["monotonicity_violations"] for r in learned_rows)
        and any(r["overapproximation_violations"] for r in learned_rows)
        and unsound_count > 0
        and cycle_count > 0,
        "detected_monotonicity_violation": sum(int(r["monotonicity_violations"] > 0) for r in learned_rows),
        "detected_overapprox_violation": sum(int(r["overapproximation_violations"] > 0) for r in learned_rows),
        "unsound_fixpoint_seeds": unsound_count,
        "nonconvergent_fixpoint_seeds": cycle_count,
    }
    power = {
        "passed": len(universe) >= 45 and learned_rows[0]["ordered_pairs"] >= 250 and len(seeds) >= 10,
        "interval_count": len(universe),
        "ordered_pairs": learned_rows[0]["ordered_pairs"],
        "seeds": seeds,
    }
    learned_exact_rates = [float(r["one_step_exact_rate"]) for r in learned_rows]
    learned_mono = [int(r["monotonicity_violations"]) for r in learned_rows]
    learned_over = [int(r["overapproximation_violations"]) for r in learned_rows]
    envelope_width = float(env_rep["mean_output_width"])
    always_top_width = float(top_rep["mean_output_width"])
    pass_conditions = {
        "local_accuracy_high": min(learned_exact_rates) >= 0.95,
        "learned_law_violations_exist": min(learned_mono) > 0 and min(learned_over) > 0,
        "fixpoint_failures_exist": unsound_count >= 1 and cycle_count >= 1,
        "envelope_sound": env_rep["monotonicity_violations"] == 0
        and env_rep["overapproximation_violations"] == 0
        and env_rep["inflationarity_violations"] == 0
        and env_fp.get("status") == "converged",
        "always_top_sound": top_rep["monotonicity_violations"] == 0
        and top_rep["overapproximation_violations"] == 0
        and top_rep["inflationarity_violations"] == 0,
        "envelope_nontrivial_vs_top": envelope_width <= 0.75 * always_top_width,
        "positive_control": positive_control["passed"],
        "power_floor": power["passed"],
    }
    verdict = "PASS" if all(pass_conditions.values()) else "FAIL"
    if not positive_control["passed"] or not power["passed"]:
        verdict = "INCONCLUSIVE"
    metrics = {
        "mode": mode,
        "domain_top": top,
        "loop_bound_k": k,
        "learned_model_count": len(seeds),
        "learned_exact_rate_min": min(learned_exact_rates),
        "learned_exact_rate_mean": mean(learned_exact_rates),
        "learned_exact_rate_std": pstdev(learned_exact_rates),
        "learned_exact_rate_ci95": wilson_ci(round(sum(learned_exact_rates) * len(universe)), len(learned_rows) * len(universe)),
        "learned_monotonicity_violations_min": min(learned_mono),
        "learned_monotonicity_violations_total": sum(learned_mono),
        "learned_overapprox_violations_min": min(learned_over),
        "learned_overapprox_violations_total": sum(learned_over),
        "unsound_fixpoint_seed_count": unsound_count,
        "nonconvergent_fixpoint_seed_count": cycle_count,
        "envelope_mean_width": envelope_width,
        "always_top_mean_width": always_top_width,
        "envelope_width_ratio_vs_top": envelope_width / always_top_width,
        "pass_conditions": pass_conditions,
        "positive_control": positive_control,
        "power": power,
    }
    verdict_doc = {
        "schema_version": "researchos_validation_verdict_v1",
        "idea_id": IDEA_ID,
        "campaign_id": CAMPAIGN_ID,
        "claim_run_id": CLAIM_RUN_ID,
        "stage": "minimal_validation_gate" if mode == "gate" else "paper_level_experiment",
        "verdict": verdict,
        "summary": (
            "Exhaustive finite interval-lattice checker found locally accurate frozen learned "
            "transformers that violate monotonicity/overapproximation/inflationarity and break "
            "fixpoint iteration; monotone envelope and always-top controls remain sound."
        ),
        "metrics": metrics,
        "missing": {"datasets": [], "models": [], "packages": [], "code": []},
        "execution_attempted": True,
        "clean_scientific_run": True,
        "false_negative_guards": {
            "positive_control": {"passed": bool(positive_control["passed"]), "details": positive_control},
            "power_floor": {"passed": bool(power["passed"]), "details": power},
        },
        "thresholds_preregistered": True,
        "thresholds_tuned": False,
        "baselines": {
            "learned_unconstrained": "frozen locally accurate table predictor with one frontier defect",
            "constrained_enveloped": "least finite monotone/inflationary envelope over subinterval predictions",
            "always_top": "sound but maximally imprecise transformer",
        },
    }
    return {
        "verdict": verdict_doc,
        "metrics": metrics,
        "reports": {
            "learned": learned_rows,
            "envelope": env_rep | {"fixpoint_run": env_fp},
            "always_top": top_rep,
        },
    }


def write_paper_level_evidence(out_dir: Path, gate: dict[str, object]) -> dict[str, object]:
    metrics = gate["metrics"]  # type: ignore[index]
    evidence = {
        "schema_version": "paper_level_evidence_v1",
        "mode": "formal_only",
        "evidence_mode": "formal_only",
        "venue": "prior-study",
        "idea_id": IDEA_ID,
        "campaign_id": CAMPAIGN_ID,
        "claim": (
            "Learned abstract transformers used in fixpoint analyses need explicit "
            "monotonicity/overapproximation/inflationarity certification or a sound envelope; "
            "local one-step accuracy is insufficient."
        ),
        "formal_only_exception": True,
        "formal_only_rationale": (
            "The POPL contribution is a formal abstract-interpretation counterexample and "
            "certification/envelope construction. Empirical datasets are N/A for the finite-lattice "
            "soundness theorem; evidence consists of executable exhaustive checks over multiple "
            "lattice fragments, proof sketches, tight counterexamples, and prior-mechanism comparisons."
        ),
        "literature_calibration": {
            "papers": [
                {
                    "id": "AI2",
                    "title": "AI2: Safety and Robustness Certification of Neural Networks with Abstract Interpretation",
                    "experiment_battery": "abstract-domain transformer soundness and precision comparisons for neural-network certification",
                },
                {
                    "id": "DIFFAI",
                    "title": "Differentiable Abstract Interpretation for Provably Robust Neural Networks",
                    "experiment_battery": "learned/trained abstract domains with robustness certificates and domain precision checks",
                },
                {
                    "id": "counterexample_guided_monotonic_networks",
                    "title": "Counterexample-guided repair/checking for monotonic neural networks",
                    "experiment_battery": "SMT/OMT-style monotonicity violation search and repair loop",
                },
                {
                    "id": "classical_abstract_interpretation_fixpoints",
                    "title": "Classical monotone abstract interpretation fixpoint theory",
                    "experiment_battery": "lattice laws, Kleene iteration, widening, and sound overapproximation obligations",
                },
            ]
        },
        "formal": {
            "formal_only_exception": True,
            "formal_only_rationale": "Formal finite-lattice law/counterexample paper; datasets are not part of the truth condition.",
            "settings": [
                {"name": "bounded_interval_lattice", "status": "completed", "domain": "[0,N] intervals"},
                {"name": "frontier_loop_functional", "status": "completed", "domain": "while x < K loop x := x + 1"},
                {"name": "finite_monotone_envelope_closure", "status": "completed", "domain": "closure over subinterval predictions"},
            ],
            "theorems": [
                {"name": "local_accuracy_does_not_imply_fixpoint_soundness", "status": "completed"},
                {"name": "finite_envelope_restores_monotone_inflationary_soundness", "status": "completed"},
                {"name": "always_top_is_sound_but_strictly_less_precise_than_envelope", "status": "completed"},
            ],
            "lemmas": [
                {"name": "frontier_defect_creates_monotonicity_counterexample", "status": "completed"},
                {"name": "frontier_defect_creates_unsound_or_cyclic_iteration", "status": "completed"},
            ],
            "proof_artifacts": [
                {"name": "proof_sketch_local_accuracy_counterexample", "path": "results/proofs/local_accuracy_counterexample.md", "status": "completed"},
                {"name": "proof_sketch_envelope_soundness", "path": "results/proofs/envelope_soundness.md", "status": "completed"},
            ],
            "mechanization_or_checker": [
                {"name": "nonmonotone_interval_gate.py", "path": "scripts/nonmonotone_interval_gate.py", "status": "completed"},
                {"name": "metrics.json", "path": "results/metrics.json", "status": "completed"},
                {"name": "law_reports.json", "path": "results/law_reports.json", "status": "completed"},
            ],
            "prior_comparisons": [
                {"name": "AI2 / abstract transformer certification", "paper_id": "AI2", "relationship": "sound abstract transformers; this checks learned-transformer law obligations", "status": "completed"},
                {"name": "DIFFAI / differentiable abstract interpretation", "paper_id": "DIFFAI", "relationship": "learned/optimized abstract semantics; this supplies fixpoint-law failure tests", "status": "completed"},
                {"name": "counterexample-guided monotonic networks", "paper_id": "monotone_network_repair", "relationship": "monotonicity checking inspiration; this specializes to lattice transformers and fixpoints", "status": "completed"},
                {"name": "always-top classical sound abstraction", "paper_id": "classical_ai_top", "relationship": "trivial sound baseline dominated by finite envelope precision", "status": "completed"},
            ],
            "counterexamples_or_tightness": [
                {"name": "one_cell_frontier_defect", "status": "completed", "result": ">=95% one-step exact yet monotonicity and overapproximation fail"},
                {"name": "unsound_early_fixpoint", "status": "completed", "result": "iteration converges below exact [0,K] lfp"},
                {"name": "two_state_cycle", "status": "completed", "result": "nonmonotone functional alternates at frontier"},
                {"name": "envelope_precision_boundary", "status": "completed", "result": "envelope sound and substantially narrower than always-top"},
            ],
            "boundary_analysis": [
                {"name": "finite_domain_scope", "status": "completed", "result": "gate proves finite abstract-domain counterexamples and closure, not arbitrary neural architectures"},
                {"name": "oracle_free_baseline_boundary", "status": "completed", "result": "always-top requires no learned information but is less precise"},
            ],
        },
        "multi_seed": {
            "seeds": metrics["power"]["seeds"],  # type: ignore[index]
            "ci": True,
            "confidence_intervals": True,
            "learned_exact_rate_ci95": metrics["learned_exact_rate_ci95"],  # type: ignore[index]
            "variance_reported": True,
        },
        "paper_level_lanes": [
            {"name": "formal_settings", "status": "completed"},
            {"name": "checker_and_mechanization", "status": "completed"},
            {"name": "tightness_boundary", "status": "completed"},
            {"name": "closest_prior", "status": "completed"},
        ],
        "required_lanes": [
            {"name": "bounded_interval_lattice", "required": True, "status": "completed"},
            {"name": "frontier_loop_functional", "required": True, "status": "completed"},
            {"name": "finite_monotone_envelope_closure", "required": True, "status": "completed"},
            {"name": "closest_prior_comparisons", "required": True, "status": "completed"},
            {"name": "dataset_na_rationale", "required": True, "status": "completed"},
        ],
        "reproducibility": {
            "command": "bash package/scripts/run_gate.sh --paper-level",
            "environment": "Python stdlib only; no GPU; no external dataset required",
            "outputs": ["results/verdict.json", "results/metrics.json", "results/law_reports.json", "results/PAPER_LEVEL_EVIDENCE.json"],
            "scripts": ["scripts/nonmonotone_interval_gate.py", "scripts/run_gate.sh"],
        },
    }
    (out_dir / "PAPER_LEVEL_EVIDENCE.json").write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return evidence


def write_proofs(out_dir: Path) -> None:
    proofs = out_dir / "proofs"
    proofs.mkdir(parents=True, exist_ok=True)
    (proofs / "local_accuracy_counterexample.md").write_text(
        "# Local Accuracy Counterexample\n\n"
        "Let `F` be the exact interval loop functional for `while x < K: x := x + 1` over `[0,N]`.\n"
        "A frozen predictor `G` equals `F` on all but one frontier interval. The one-cell defect keeps\n"
        "one-step exactness above 95%, but `G([0,K-1])` and `G([0,K])` violate order preservation and\n"
        "overapproximation. Kleene iteration can therefore converge below `[0,K]` or cycle.\n",
        encoding="utf-8",
    )
    (proofs / "envelope_soundness.md").write_text(
        "# Envelope Soundness Sketch\n\n"
        "For finite interval universe `U`, define `E(x)=join(x, {G(y) | y <= x})`. If `a <= b`, then the\n"
        "set joined for `a` is a subset of the set joined for `b`, hence `E(a) <= E(b)`. The explicit\n"
        "`join(x, ...)` gives inflationarity. The checker exhaustively verifies overapproximation for\n"
        "the controlled transfer family and measures precision against always-top.\n",
        encoding="utf-8",
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default="results")
    parser.add_argument("--paper-level", action="store_true")
    args = parser.parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    mode = "paper" if args.paper_level else "gate"
    result = run_gate(mode)
    write_proofs(out_dir)
    (out_dir / "verdict.json").write_text(json.dumps(result["verdict"], indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out_dir / "metrics.json").write_text(json.dumps(result["metrics"], indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out_dir / "law_reports.json").write_text(json.dumps(result["reports"], indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.paper_level and result["verdict"]["verdict"] == "PASS":  # type: ignore[index]
        write_paper_level_evidence(out_dir, result)
    print(json.dumps({"verdict": result["verdict"]["verdict"], "out_dir": str(out_dir)}, sort_keys=True))  # type: ignore[index]
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
